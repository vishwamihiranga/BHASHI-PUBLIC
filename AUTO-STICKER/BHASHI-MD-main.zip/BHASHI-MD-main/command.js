/*

 ██████╗ ██╗  ██╗ █████╗ ███████╗██╗  ██╗██╗    ███╗   ███╗██████╗       ██████╗  ██████╗ ██████╗ ██╗  ██╗ 
 ██╔══██╗██║  ██║██╔══██╗██╔════╝██║  ██║██║    ████╗ ████║██╔══██╗      ╚════██╗██╔═████╗╚════██╗██║  ██║
 ██████╔╝███████║███████║███████╗███████║██║    ██╔████╔██║██║  ██║       █████╔╝██║██╔██║ █████╔╝███████║  
 ██╔══██╗██╔══██║██╔══██║╚════██║██╔══██║██║    ██║╚██╔╝██║██║  ██║      ██╔═══╝ ████╔╝██║██╔═══╝ ╚════██║
 ██████╔╝██║  ██║██║  ██║███████║██║  ██║██║    ██║ ╚═╝ ██║██████╔╝      ███████╗╚██████╔╝███████╗     ██║ 
 ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝    ╚═╝     ╚═╝╚═════╝       ╚══════╝ ╚═════╝ ╚══════╝     ╚═╝ 
                                                                   
    Project Name : Bhashi Multi Device Whatsapp Bot
    Version : 1.0
    Year : 2024
    Author : Vishwa Mihiranga & Bhashitha
    This File Last Update Date : 2024.09.27

*/



(function(_0x337ed5,_0x3d506e){var _0x4e7eb1=_0x589e,_0x177dfc=_0x337ed5();while(!![]){try{var _0x2a7b78=parseInt(_0x4e7eb1(0x1c5))/0x1+-parseInt(_0x4e7eb1(0x1c3))/0x2+-parseInt(_0x4e7eb1(0x1ce))/0x3+parseInt(_0x4e7eb1(0x1c8))/0x4+-parseInt(_0x4e7eb1(0x1cc))/0x5+-parseInt(_0x4e7eb1(0x1ca))/0x6+-parseInt(_0x4e7eb1(0x1c9))/0x7*(-parseInt(_0x4e7eb1(0x1cb))/0x8);if(_0x2a7b78===_0x3d506e)break;else _0x177dfc['push'](_0x177dfc['shift']());}catch(_0x17322e){_0x177dfc['push'](_0x177dfc['shift']());}}}(_0x563f,0xbefb3));var commands=[];function _0x589e(_0x400e9a,_0x132ec1){var _0x563f98=_0x563f();return _0x589e=function(_0x589eb4,_0x5f2fb3){_0x589eb4=_0x589eb4-0x1c1;var _0x5b7d70=_0x563f98[_0x589eb4];return _0x5b7d70;},_0x589e(_0x400e9a,_0x132ec1);}function cmd(_0x402742,_0x9b5ef6){var _0xbd80cd=_0x589e,_0x5bd03a=_0x402742;_0x5bd03a[_0xbd80cd(0x1c2)]=_0x9b5ef6;if(!_0x5bd03a[_0xbd80cd(0x1cf)])_0x5bd03a[_0xbd80cd(0x1cf)]=![];if(!_0x402742[_0xbd80cd(0x1c7)])_0x402742[_0xbd80cd(0x1c7)]='';if(!_0x5bd03a[_0xbd80cd(0x1c4)])_0x5bd03a[_0xbd80cd(0x1c4)]=![];if(!_0x402742['category'])_0x5bd03a['category']=_0xbd80cd(0x1cd);if(!_0x402742[_0xbd80cd(0x1c1)])_0x5bd03a[_0xbd80cd(0x1c1)]=_0xbd80cd(0x1c6);return commands['push'](_0x5bd03a),_0x5bd03a;}function _0x563f(){var _0x3c079a=['1253723VauNrg','Not\x20Provided','desc','893660UobDfZ','6146yJscCP','2873262ttQdjF','17256ujMBfD','2313680cVcyEG','misc','2191599HHOMKG','dontAddCommandList','filename','function','1833158EXEkgi','fromMe'];_0x563f=function(){return _0x3c079a;};return _0x563f();}module['exports']={'cmd':cmd,'AddCommand':cmd,'Function':cmd,'Module':cmd,'commands':commands};