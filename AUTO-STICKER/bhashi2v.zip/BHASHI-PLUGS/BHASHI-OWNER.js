const {readEnv,updateEnv} = require('../BHASHI-DB/settingsdb2')
const {cmd , commands} = require('../commands')
const fs = require('fs');
const { sleep } = require('../BHASHI-DB/mainfun');
const path = require('path');
const axios = require('axios')
const { exec } = require("child_process");
const EnvVar = require('../BHASHI-DB/envdb');
const messages = {
    EN: {
        joinSuccess: "✅ Successfully joined the group!",
        joinFail: "❌ Failed to join the group. Please check the invite link.",
        joinError: "❗ An error occurred while trying to join the group.",
        leaveError: "❗ An error occurred while trying to leave the group.",
        hidetagGroupOnly: "❌ This command can only be used in a group.",
        hidetagNoMessage: "❗ Please provide a message to send.",
        restartMessage: "𝗕𝗵𝗮𝘀𝗵𝗶 𝗠𝗗 𝗥𝗲𝘀𝘁𝗮𝗿𝘁𝗶𝗻𝗴...",
        upgradeStart: "🔄 Redeploying the bot...",
        upgradeSuccess: "✅ Bot redeployment successful.",
        upgradeFail: "❌ Error occurred during redeployment.",
        broadcastNoMessage: "❗ Please provide a message to broadcast.",
        broadcastSuccess: "✅ Broadcast sent to {0} chats successfully!",
        banNotOwner: "❌ You are not the owner!",
        banNoUser: "❗ Please provide a valid user number to ban or quote a user.",
        banSuccess: "🚫 User {0} has been banned from using the bot.",
        banAlready: "❗ User is already banned.",
        unbanSuccess: "✅ User {0} has been unbanned.",
        unbanNotBanned: "❗ User is not in the blacklist.",
        setNameNoName: "❗ Please provide a new name for the bot.",
        setNameSuccess: "✅ Bot's name has been changed to: *{0}*",
        setBioNoBio: "❗ Please provide a new bio for the bot.",
        setBioSuccess: "✅ Bot's bio has been changed to: *{0}*",
        blockSuccess: "🚫 User {0} has been blocked.",
        unblockSuccess: "✅ User {0} has been unblocked.",
        setppNoMedia: "❗ No image or video found.",
        setppSuccess: "✅ Profile picture has been updated.",
        setppFail: "❗ Failed to update profile picture.",
        autoBioEnabled: "🛠️ AutoBIO feature has been *enabled*! 🔄",
        autoBioDisabled: "🛠️ AutoBIO feature has been *disabled*! 🚫",
        invalidChat: "Please provide a valid chat ID.",
        archiveSuccess: "*✅ Chat has been archived successfully.*",
        archiveFail: "*⚠️ Failed to archive the chat. Please try again.*",
        archiveError: "⚠️ An error occurred while archiving the chat.",
        starSuccess: "*✅ Message has been starred successfully.*",
        starFail: "*⚠️ Failed to star the message. Please try again.*",
        starError: "⚠️ An error occurred while starring the message.",
        unstarSuccess: "*✅ Message has been unstarred successfully.*",
        unstarFail: "*⚠️ Failed to unstar the message. Please try again.*",
        unstarError: "⚠️ An error occurred while unstarring the message."
    },
    SI: {
        joinSuccess: "✅ සාර්ථකව සමූහයට එක්විය!",
        joinFail: "❌ සමූහයට එක්වීමට අසමත් විය. කරුණාකර ආරාධනා සබැඳිය පරීක්ෂා කරන්න.",
        joinError: "❗ සමූහයට එක්වීමට උත්සාහ කිරීමේදී දෝෂයක් ඇති විය.",
        leaveError: "❗ සමූහයෙන් ඉවත් වීමට උත්සාහ කිරීමේදී දෝෂයක් ඇති විය.",
        hidetagGroupOnly: "❌ මෙම විධානය සමූහයක පමණක් භාවිතා කළ හැකිය.",
        hidetagNoMessage: "❗ කරුණාකර යැවීමට පණිවිඩයක් සපයන්න.",
        restartMessage: "𝗕𝗵𝗮𝘀𝗵𝗶 𝗠𝗗 නැවත ආරම්භ වෙමින්...",
        upgradeStart: "🔄 බොට් නැවත යෙදවීම...",
        upgradeSuccess: "✅ බොට් නැවත යෙදවීම සාර්ථකයි.",
        upgradeFail: "❌ නැවත යෙදවීමේදී දෝෂයක් සිදු විය.",
        broadcastNoMessage: "❗ කරුණාකර විකාශනය කිරීමට පණිවිඩයක් සපයන්න.",
        broadcastSuccess: "✅ විකාශනය සාර්ථකව චැට් {0}කට යවන ලදී!",
        banNotOwner: "❌ ඔබ හිමිකරු නොවේ!",
        banNoUser: "❗ කරුණාකර තහනම් කිරීමට වලංගු පරිශීලක අංකයක් සපයන්න හෝ පරිශීලකයෙකු උපුටා දක්වන්න.",
        banSuccess: "🚫 පරිශීලක {0} බොට් භාවිතයෙන් තහනම් කර ඇත.",
        banAlready: "❗ පරිශීලකයා දැනටමත් තහනම් කර ඇත.",
        unbanSuccess: "✅ පරිශීලක {0}ගේ තහනම ඉවත් කර ඇත.",
        unbanNotBanned: "❗ පරිශීලකයා අසාදු ලේඛනයේ නොමැත.",
        setNameNoName: "❗ කරුණාකර බොට් සඳහා නව නමක් සපයන්න.",
        setNameSuccess: "✅ බොට්ගේ නම වෙනස් කර ඇත: *{0}*",
        setBioNoBio: "❗ කරුණාකර බොට් සඳහා නව ජීව දත්තයක් සපයන්න.",
        setBioSuccess: "✅ බොට්ගේ ජීව දත්ත වෙනස් කර ඇත: *{0}*",
        blockSuccess: "🚫 පරිශීලක {0} අවහිර කර ඇත.",
        unblockSuccess: "✅ පරිශීලක {0}ගේ අවහිරය ඉවත් කර ඇත.",
        setppNoMedia: "❗ රූපයක් හෝ වීඩියෝවක් හමු නොවීය.",
        setppSuccess: "✅ පැතිකඩ පින්තූරය යාවත්කාලීන කර ඇත.",
        setppFail: "❗ පැතිකඩ පින්තූරය යාවත්කාලීන කිරීමට අසමත් විය.",
        autoBioEnabled: "🛠️ ස්වයංක්‍රීය ජීව දත්ත විශේෂාංගය *සක්‍රීය* කර ඇත! 🔄",
        autoBioDisabled: "🛠️ ස්වයංක්‍රීය ජීව දත්ත විශේෂාංගය *අක්‍රීය* කර ඇත! 🚫",
        invalidChat: "කරුණාකර වලංගු කතාබස් හැඳුනුම්පතක් ලබා දෙන්න.",
        archiveSuccess: "*✅ කතාබස් සාර්ථකව ආරක්ෂිත කර ඇත.*",
        archiveFail: "*⚠️ කතාබස් ආරක්ෂා කිරීමට අසමත් විය. කරුණාකර නැවත උත්සාහ කරන්න.*",
        archiveError: "⚠️ කතාබස් ආරක්ෂා කිරීමේදී දෝෂයක් සිදු විය.",
        starSuccess: "*✅ පණිවිඩය සාර්ථකව තාරකාව ලැබී ඇත.*",
        starFail: "*⚠️ පණිවිඩය තාරකාව ලැබීමට අසමත් විය. කරුණාකර නැවත උත්සාහ කරන්න.*",
        starError: "⚠️ පණිවිඩය තාරකාව ලබා ගැනීමට දෝෂයක් ඇති විය.",
        unstarSuccess: "*✅ පණිවිඩය සාර්ථකව තාරකාව ඉවත් කර ඇත.*",
        unstarFail: "*⚠️ පණිවිඩය තාරකාව ඉවත් කිරීමට අසමත් විය. කරුණාකර නැවත උත්සාහ කරන්න.*",
        unstarError: "⚠️ පණිවිඩය තාරකාව ඉවත් කිරීමට දෝෂයක් ඇති විය."
    }
};
cmd({
    pattern: "clearchats",
    desc: "Clear all chats from the bot.",
    category: "owner",
    use: '.clearchats',
    react: "🧹",
    filename: __filename
},
async (conn, mek, m, { from, isOwner, reply }) => {
    if (!isOwner) return reply("❌ You are not the owner!");
    try {
        const chats = conn.chats.all();
        for (const chat of chats) {
            await conn.modifyChat(chat.jid, 'delete');
        }
        reply("🧹 All chats cleared successfully!");
    } catch (error) {
        reply(`❌ Error clearing chats: ${error.message}`);
    }
});
cmd({
    pattern: 'ssave',
    desc: 'Saves media from a status or message to your device.',
    category: 'owner',
    react: '💾',
    filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Multi-language support: Detect user language
        const language = config.LANGUAGE === 'SI' ? 'SI' : 'EN';

        const messages = {
            EN: {
                noPermission: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!",
                blacklisted: "🚫 You are blacklisted. Access denied.",
                noReply: "Please reply to a status or message with media that you want to save.",
                unsupportedMedia: "The replied message does not contain supported media. Please reply to an image, video, audio, or document.",
                downloadFailed: "Failed to download the media.",
                mediaSaved: "*✅ Status Saved*",
                error: "⚠️ An error occurred while saving the media."
            },
            SI: {
                noPermission: "😢 ඔබට මෙම විධානය භාවිතා කිරීමේ අවසරය නොමැත. 🎁 බොට් ක්‍රමය වෙනස් කරන්න!",
                blacklisted: "🚫 ඔබ කළු ලැයිස්තුවට ඇතුළත් කර ඇත. ප්‍රවේශය අත්හැරීම.",
                noReply: "කරුණාකර ඔබට සුරැකීමට අවශ්‍ය මාධ්‍ය සමඟ තත්ත්වයකට හෝ පණිවිඩයකට ප්‍රතිචාර දක්වන්න.",
                unsupportedMedia: "ප්‍රතිචාර දැක්වූ පණිවිඩය සහය දක්වන මාධ්‍ය අඩංගු නැත. කරුණාකර රූපයක, වීඩියෝවක, ශ්‍රව්‍යයක හෝ ලේඛනයකට ප්‍රතිචාර දැක්වන්න.",
                downloadFailed: "මාධ්‍යය බාගැනීමට අසමත් විය.",
                mediaSaved: "*✅ තත්වය සුරැකී ඇත*",
                error: "⚠️ මාධ්‍යය සුරැකීමේදී දෝෂයක් ඇතිවිය."
            }
        };

        const lang = messages[language];
        // Check if a message is quoted
        if (!m.quoted) {
            return reply(lang.noReply);
        }
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }
        // Get the quoted message
        const quotedMsg = m.quoted;

        // Check for different types of media
        const mediaType = quotedMsg.type || quotedMsg.mtype;
        let mediaData;
        let fileExtension = '';
        let mimeType = '';

        switch (mediaType) {
            case 'imageMessage':
                mediaData = await quotedMsg.download() || await conn.downloadMediaMessage(quotedMsg);
                fileExtension = 'jpg';
                mimeType = 'image/jpeg';
                break;
            case 'videoMessage':
                mediaData = await quotedMsg.download() || await conn.downloadMediaMessage(quotedMsg);
                fileExtension = 'mp4';
                mimeType = 'video/mp4';
                break;
            case 'audioMessage':
                mediaData = await quotedMsg.download() || await conn.downloadMediaMessage(quotedMsg);
                fileExtension = 'ogg';
                mimeType = 'audio/ogg';
                break;
            case 'documentMessage':
                mediaData = await quotedMsg.download() || await conn.downloadMediaMessage(quotedMsg);
                fileExtension = quotedMsg.fileName ? quotedMsg.fileName.split('.').pop() : 'bin';
                mimeType = quotedMsg.mimetype || 'application/octet-stream';
                break;
            default:
                return reply(lang.unsupportedMedia);
        }

        if (!mediaData) {
            return reply(lang.downloadFailed);
        }

        // Ensure media directory exists
        const mediaDir = path.join(__dirname, 'media');
        if (!fs.existsSync(mediaDir)) {
            fs.mkdirSync(mediaDir);
        }

        // Generate a unique filename
        const filename = `ʙʜᴀꜱʜɪ ᴍᴅ 2024™️| ${Date.now()}.${fileExtension}`;

        // Save the media to a file
        const filePath = path.join(mediaDir, filename);
        fs.writeFileSync(filePath, mediaData);

        // Send the saved file back to the user
        await conn.sendMessage(from, { document: fs.readFileSync(filePath), mimetype: mimeType, fileName: filename }, { quoted: m });

        reply(`${lang.mediaSaved} ${filename}\n\nʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛$`);
        console.log('Media saved successfully');
    } catch (e) {
        console.error('Error executing media saver command:', e);
        reply(lang.error);
    }
});

cmd({
    pattern: "setvar",
    alias: ["updatevar"],
    react: "⚙️",
    desc: "Check and update environment variables",
    category: "owner",
    filename: __filename,
},
async (conn, mek, m, { from, q, reply, isOwner,isDev }) => {
    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }

    if (!q) {
        return reply("🙇‍♂️ *Please provide the environment variable and its new value.* \n\nExample: `.update ALIVE_MSG: hello i am prabath kumara`");
    }

    // Find the position of the first colon or comma
    const colonIndex = q.indexOf(':');
    const commaIndex = q.indexOf(',');

    // Ensure we have a valid delimiter index
    const delimiterIndex = colonIndex !== -1 ? colonIndex : commaIndex;
    if (delimiterIndex === -1) {
        return reply("🫠 *Invalid format. Please use the format:* `.update KEY:VALUE`");
    }

    // Extract key and value
    const key = q.substring(0, delimiterIndex).trim();
    const value = q.substring(delimiterIndex + 1).trim();

    // Extract mode if provided
    const parts = value.split(/\s+/).filter(part => part.trim());
    const newValue = value; // Use the full value as provided by the user
    const mode = parts.length > 1 ? parts.slice(1).join(' ').trim() : '';

    const validModes = ['public', 'private', 'groups', 'inbox'];
    const finalMode = validModes.includes(mode) ? mode : '';

    if (!key || !newValue) {
        return reply("🫠 *Invalid format. Please use the format:* `.update KEY:VALUE`");
    }

    // Specific checks for MODE, ALIVE_IMG, and AUTO_READ_STATUS
    if (key === 'MODE' && !validModes.includes(newValue)) {
        return reply(`😒 *Invalid mode. Valid modes are: ${validModes.join(', ')}*`);
    }

    if (key === 'ALIVE_IMG' && !newValue.startsWith('https://')) {
        return reply("😓 *Invalid URL format. PLEASE GIVE ME IMAGE URL*");
    }

    if (key === 'AUTO_READ_STATUS' && !['true', 'false'].includes(newValue)) {
        return reply("😓 *Invalid value for AUTO_READ_STATUS. Please use `true` or `false`.*");
    }

    try {
        // Check if the environment variable exists
        const envVar = await EnvVar.findOne({ key: key });

        if (!envVar) {
            // If the variable does not exist, fetch and list all existing env vars
            const allEnvVars = await EnvVar.find({});
            const envList = allEnvVars.map(env => `${env.key}: ${env.value}`).join('\n');
            return reply(`❌ *The environment variable ${key} does not exist.*\n\n*Here are the existing environment variables:*\n\n${envList}`);
        }

        // Update the environment variable
        await updateEnv(key, newValue, finalMode);
        reply(`✅ *Environment variable updated.*\n\n🗃️ *${key}* ➠ ${newValue} ${finalMode ? `\n*Mode:* ${finalMode}` : ''}`);

    } catch (err) {
        console.error('Error updating environment variable:' + err.message);
        reply("🙇‍♂️ *Failed to update the environment variable. Please try again.*" + err);
    }
});
//==================================================================
cmd({
    pattern: "getvars",
    alias: ["vars"],
    react: "⚙️",
    desc: "Get all current environment variables",
    category: "owner",
    filename: __filename,
}, async (conn, mek, m, { reply, isOwner, isDev }) => {
    // Permission check for owner and IsDev
    if (!isOwner && !isDev) {
        return reply("❌ *You do not have permission to use this command.*");
    }

    try {
        // Fetch all existing environment variables
        const allEnvVars = await EnvVar.find({});

        if (allEnvVars.length === 0) {
            return reply("🔍 *No environment variables found.*");
        }

        // Create a list of environment variables
        const envList = allEnvVars
            .map(env => `🌐 *${env.key}*: _${env.value}_`)
            .join('\n\n');

        // Formatting the output message with emojis and bold text
        reply(`🧰 *Current Environment Variables* ⚙️

Here are the currently configured environment variables:

${envList}

*Total Variables:* ${allEnvVars.length} 🌍`);

    } catch (err) {
        console.error('Error fetching environment variables:' + err.message);
        reply("🙇‍♂️ *Failed to retrieve the environment variables. Please try again later.*");
    }
});
//==================================================================
cmd({
    pattern: "remvar",
    alias: ["removevar"],
    react: "❌",
    desc: "Remove a specific environment variable.",
    category: "owner",
    filename: __filename,
}, async (conn, mek, m, { reply, isOwner, isDev, text }) => {
    // Permission check for owner and IsDev
    if (!isOwner && !isDev) {
        return reply("❌ *You do not have permission to use this command.*");
    }

    // Check if the user provided a variable key to remove
    if (!text) {
        return reply("🔍 *Please provide the key of the environment variable to remove.*\nExample: .remvar API_KEY");
    }

    try {
        // Find the environment variable by its key
        const envVar = await EnvVar.findOne({ key: text });

        if (!envVar) {
            return reply(`🚫 *No environment variable found with the key: ${text}.*`);
        }

        // Remove the environment variable
        await EnvVar.deleteOne({ key: text });

        // Send a confirmation message
        reply(`✅ *Environment variable '${text}' has been successfully removed.*`);

    } catch (err) {
        console.error('Error removing environment variable:', err.message);
        reply("🙇‍♂️ *Failed to remove the environment variable. Please try again later.*");
    }
});

//=================================================================
cmd({
    pattern: "remallvars",
    alias: ["removeallvars"],
    desc: "Remove all environment variables",
    category: "owner",
    filename: __filename,
},
async (conn, mek, m, { from, q, reply, isOwner,isDev }) => {
    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }

    try {
        // Check if any environment variables exist
        const envVars = await EnvVar.find();

        if (envVars.length === 0) {
            return reply("❌ *No environment variables found to remove.*");
        }

        // Remove all environment variables
        await EnvVar.deleteMany({});
        reply("✅ *All environment variables have been removed successfully.*");

    } catch (err) {
        console.error('Error removing all environment variables:' + err.message);
        reply("🙇‍♂️ *Failed to remove all environment variables. Please try again.*" + err);
    }
});

//==================================================================
cmd({
    pattern: "removevar",
    alias: ["remvar"],
    desc: "Remove an environment variable",
    category: "owner",
    filename: __filename,
},
async (conn, mek, m, { from, q, reply, isOwner,isDev}) => {
    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }

    if (!q) {
        return reply("🙇‍♂️ *Please provide the environment variable key to remove.* \n\nExample: `.removeconfig ALIVE_MSG`");
    }

    try {
        // Check if the environment variable exists
        const envVar = await EnvVar.findOne({ key: q.trim() });

        if (!envVar) {
            return reply(`❌ *The environment variable ${q} does not exist.*`);
        }

        // Remove the environment variable
        await EnvVar.deleteOne({ key: q.trim() });
        reply(`✅ *Environment variable ${q} has been removed successfully.*`);

    } catch (err) {
        console.error('Error removing environment variable:' + err.message);
        reply("🙇‍♂️ *Failed to remove the environment variable. Please try again.*" + err);
    }
});
//=================================================================
cmd({
    pattern: "getabout",
    desc: "Fetch WhatsApp status (about) of a quoted user.",
    react: 'ℹ️',
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { from, reply,isOwner,isDev }) => {
    try {
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }
        if (!m.quoted) {
            return reply("Please reply to a user's message to get their 'about' status.");
        }

        // Get the WhatsApp number from the quoted message
        const quotedUserJID = m.quoted.sender;

        // Fetch the status (about) of the quoted user
        const status = await conn.fetchStatus(quotedUserJID);
        console.log("User status: " + status.status);

        // Send the status back to the chat
        reply(`*✅ The 'About' status of ${quotedUserJID} :* "${status.status}"`);
    } catch (error) {
        console.log(error);
        reply("An error occurred: " + error.message);
    }
});
//=================================================================
cmd({
    pattern: "getbusiness",
    desc: "ℹ️ Get the business profile description and category of a user.",
    fromMe: true,
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { args, reply,isOwner,isDev }) => {
    try {
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }
        const targetJID = (m.quoted ? m.quoted.sender : args[0]?.replace(/[^0-9]/g, "") + "@s.whatsapp.net") || "";

        // Check if a valid JID is provided
        if (!targetJID) return reply("❗ Please provide a valid user or reply to a user's message.");

        // Fetch the business profile
        const profile = await conn.getBusinessProfile(targetJID);

        // Log the business profile for debugging purposes
        console.log("Fetched profile:", profile);

        // Check if the profile is available
        if (!profile) {
            return reply("🔍 No business profile found for this user.");
        }

        // Construct the response message
        const responseMessage = `*🌟 Business Profile of ${targetJID}:*\n` +
            `📝 *Description:* ${profile.description || "No description available."}\n` +
            `🏷️ *Category:* ${profile.category || "No category available."}\n` +
            `📅 *Account Type:* ${profile.isBusiness ? "Business Account" : "Personal Account"}\n` +
            `📞 *Contact Info:* ${profile.contactNumber || "No contact info available."}\n` +
            `🌐 *Website:* ${profile.website || "No website available."}\n`;

        // Send the response back to the chat
        reply(responseMessage);
    } catch (error) {
        console.error("Error fetching business profile:", error);
        // Distinguish between different error types
        if (error.message.includes("not found")) {
            reply("🚫 The business profile could not be found for this user.");
        } else {
            reply("⚠️ An error occurred while fetching the business profile: " + error.message);
        }
    }
});
//=================================================================
cmd({
    pattern: "join",
    fromMe: true,
    desc: "Make the bot join a group using an invite link.",
    category: "owner",
    react: "🌀",
    filename: __filename
}, async (conn, mek, m, { q, reply, isOwner, isDev }) => {
    try {
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";

        // Define the lang function outside the try block for scope access
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];

        // Check if user has permission to use the command
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }

        // Validate the invite link
        if (!q || !q.includes("chat.whatsapp.com")) {
            return await reply("❌ Please provide a valid WhatsApp group invite link.");
        }

        // Extract the invite code from the link
        const inviteCode = q.split("chat.whatsapp.com/")[1];
        if (!inviteCode) {
            return await reply("❌ Invalid invite link. Could not extract the invite code.");
        }

        // Attempt to join the group
        const response = await conn.groupAcceptInvite(inviteCode);
        if (response) {
            await reply(lang("joinSuccess"));
        } else {
            await reply(lang("joinFail"));
        }
    } catch (e) {
        console.error("Error while joining group:", e);

        // Ensure lang is available here
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];

        await reply(lang("joinError"));
    }
});

//=================================================================
cmd({
    pattern: "left",
    fromMe: true,
    desc: "Make the bot leave the group.",
    category: "owner",
    react: "👋",
    filename: __filename
}, async (conn, mek, m, { from, isGroup,isOwner,isDev }) => {
    try {
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }
        if (!isGroup) {
            return await reply(lang("hidetagGroupOnly"));
        }
        await conn.groupLeave(from);
        console.log(`Bot left the group: ${from}`);
    } catch (e) {
        console.error("Error while leaving group:", e);
        await reply(lang("leaveError"));
    }
});
//=================================================================
cmd({
    pattern: "hidetag",
    fromMe: true,
    desc: "Send a message with hidden tags to all group members.",
    category: "owner",
    react: "🔍",
    filename: __filename
}, async (conn, mek, m, { from, isGroup, q, participants, reply,isOwner,isDev }) => {
    try {
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }
        if (!isGroup) {
            return await reply(lang("hidetagGroupOnly"));
        }
        if (!q) {
            return await reply(lang("hidetagNoMessage"));
        }
        const participantIds = participants.map((participant) => participant.id);
        await conn.sendMessage(from, { 
            text: q, 
            mentions: participantIds 
        });
        console.log("Hidetag message sent to all group members.");
    } catch (e) {
        console.error("Error while sending hidetag message:", e);
        await reply(lang("hidetagError"));
    }
});
//=================================================================
cmd({
    pattern: "restart",
    desc: "restart the bot",
    category: "owner",
    use: '.restart',
    react: "☣",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(!isOwner) return reply(`only for owner`);
const {exec} = require("child_process")
reply("*BHASHI-MD-v2 RESTARTING....*")
await sleep(1500)
exec("npm restart")
}catch(e){
console.log(e)
reply(`${e}`)
}
});
cmd({
    pattern: "restart2",
    desc: "restart the bot",
    category: "owner",
    use: '.restart',
    react: "☣",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(!isOwner) return reply(`only for owner`);
const {exec} = require("child_process")
reply("*BHASHI-MD-v2 RESTARTING....*")
await sleep(1500)
exec("pm2 restart all")
}catch(e){
console.log(e)
reply(`${e}`)
}
});
//=================================================================
cmd({
    pattern: "upgrade",
    fromMe: true,
    desc: "Redeploy the bot.",
    category: "owner",
    react: "🔄",
    filename: __filename
}, async (conn, mek, m, { isOwner, reply ,isDev}) => {
    try {
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];

        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }
        await reply(lang("upgradeStart"));
        exec('bash redeploy.sh', (error, stdout, stderr) => {
            if (error) {
                console.error(`Error: ${error}`);
                return reply(lang("upgradeFail"));
            }
            if (stderr) {
                console.error(`stderr: ${stderr}`);
                return reply(`${lang("upgradeFail")} ${stderr}`);
            }
            console.log(`stdout: ${stdout}`);
            reply(lang("upgradeSuccess"));
        });
    } catch (e) {
        console.error(e);
        reply(`${lang("upgradeFail")} ${e}`);
    }
});
//=================================================================
cmd({
    pattern: "broadcast",
    fromMe: true,
    desc: "📢 Broadcast a message to all chats",
    react: "📢",
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { args, reply,isDev }) => {
    const config = await readEnv();
    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }
    const LANGUAGE = config.LANGUAGE || "EN";
    const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
    const message = args.join(" ");
    if (!message) return reply(lang("broadcastNoMessage"));

    const chats = await conn.getAllChats();
    let successCount = 0;

    for (let chat of chats) {
        try {

            if (!isOwner) return reply(banNotOwner);
            await conn.sendMessage(chat.id, { text: `📢 *BROADCAST MESSAGE*\n\n${message}` });
            successCount++;
        } catch (error) {
            console.error(`Failed to send broadcast to ${chat.id}:`, error);
        }
    }

    reply(lang("broadcastSuccess").replace("{0}", successCount));
});
//=================================================================
cmd({
    pattern: "ban",
    fromMe: true,
    desc: "🚫 Ban a user from using the bot or quoted user",
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { args, reply, isOwner,isDev }) => {
    const config = await readEnv();
    const LANGUAGE = config.LANGUAGE || "EN";
    const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }

    const userToBan = (m.quoted ? m.quoted.sender : args[0])?.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    if (!userToBan) return reply(lang("banNoUser"));

    const blacklistPath = path.join(__dirname, '../BHASHI-DB/blacklist.json');
    let blacklistData;

    try {
        blacklistData = JSON.parse(fs.readFileSync(blacklistPath, 'utf8'));
    } catch (err) {
        console.error("Error reading blacklist:", err);
        return reply(lang("banError"));
    }

    // Ban the user by adding them to the BLACKLISTED_USERS array
    if (!blacklistData.BLACKLISTED_USERS.includes(userToBan)) {
        blacklistData.BLACKLISTED_USERS.push(userToBan);
        fs.writeFileSync(blacklistPath, JSON.stringify(blacklistData, null, 2), 'utf8');
        reply(lang("banSuccess").replace("{0}", userToBan));
    } else {
        reply(lang("banAlready"));
    }
});
//=================================================================
cmd({
    pattern: "unban",
    desc: "✅ Unban a user or quoted user",
    fromMe: true,
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { args, reply, isOwner,isDev }) => {
    const config = await readEnv();
    const LANGUAGE = config.LANGUAGE || "EN";
    const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }

    const userToUnban = (m.quoted ? m.quoted.sender : args[0])?.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    if (!userToUnban) return reply(lang("banNoUser"));

    const blacklistPath = path.join(__dirname, '../BHASHI-DB/blacklist.json');
    let blacklistData;

    try {
        blacklistData = JSON.parse(fs.readFileSync(blacklistPath, 'utf8'));
    } catch (err) {
        console.error("Error reading blacklist:", err);
        return reply(lang("unbanError"));
    }

    // Unban the user by removing them from the BLACKLISTED_USERS array
    if (blacklistData.BLACKLISTED_USERS.includes(userToUnban)) {
        blacklistData.BLACKLISTED_USERS = blacklistData.BLACKLISTED_USERS.filter(user => user !== userToUnban);
        fs.writeFileSync(blacklistPath, JSON.stringify(blacklistData, null, 2), 'utf8');
        reply(lang("unbanSuccess").replace("{0}", userToUnban));
    } else {
        reply(lang("unbanNotBanned"));
    }
});
//=================================================================
    cmd({
        pattern: "setbotname",
        desc: "✏️ Change the bot's name",
        fromMe: true,
        category: "owner",
        filename: __filename
    }, async (conn, mek, m, { args, reply, isOwner,isDev }) => {
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }

        const newName = args.join(" ");
        if (!newName) return reply(lang("setNameNoName"));

        await conn.updateProfileName(newName);
        reply(lang("setNameSuccess").replace("{0}", newName));
    });
//=================================================================
    cmd({
        pattern: "setbotbio",
        desc: "✏️ Change the bot's bio",
        fromMe: true,
        category: "owner",
        filename: __filename
    }, async (conn, mek, m, { args, reply, isOwner,isDev }) => {
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }

        const newBio = args.join(" ");
        if (!newBio) return reply(lang("setBioNoBio"));

        await conn.updateProfileStatus(newBio);
        reply(lang("setBioSuccess").replace("{0}", newBio));
    });

//=================================================================
cmd({
    pattern: "block",
    desc: "🚫 Block a user or quoted user",
    fromMe: true,
    react:"🚫",
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { args, reply, isOwner,isDev }) => {
    const config = await readEnv();
    const LANGUAGE = config.LANGUAGE || "EN";
    const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];

    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }

    // Get the user to block (either quoted or passed in arguments)
    const userToBlock = (m.quoted ? m.quoted.sender : args[0])?.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Check if a valid user is provided
    if (!userToBlock) return reply(lang("banNoUser"));

    try {
        reply(lang("blockSuccess").replace("{0}", userToBlock));
        await conn.updateBlockStatus(userToBlock, "block");
    } catch (error) {
        console.error("Error blocking user:", error);
        reply(lang("blockError"));
    }
});
//=================================================================
cmd({
    pattern: "unblock",
    desc: "✅ Unblock a user or quoted user",
    fromMe: true,
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { args, reply, isOwner,isDev }) => {
    const config = await readEnv();
    const LANGUAGE = config.LANGUAGE || "EN";
    const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
    if (!isOwner && !isDev) {
        return reply("❌ You do not have permission to use this command.");
    }

    // Get the user to unblock (either quoted or passed in arguments)
    const userToUnblock = (m.quoted ? m.quoted.sender : args[0])?.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Check if a valid user is provided
    if (!userToUnblock) return reply(lang("banNoUser"));

    try {
        reply(lang("unblockSuccess").replace("{0}", userToUnblock));
        await conn.updateBlockStatus(userToUnblock, "unblock");
    } catch (error) {
        console.error("Error unblocking user:", error);
        reply(lang("unblockError"));
    }
});
//=================================================================
    cmd({
        pattern: "setpp",
        desc: "🖼️ Set bot's profile picture",
        fromMe: true,
        category: "owner",
        filename: __filename
    }, async (conn, mek, m, { reply, isOwner,isDev }) => {
        const config = await readEnv();
        const LANGUAGE = config.LANGUAGE || "EN";
        const lang = (key) => messages[LANGUAGE][key] || messages["EN"][key];
        if (!isOwner && !isDev) {
            return reply("❌ You do not have permission to use this command.");
        }

        const media = m.message?.imageMessage || m.message?.videoMessage;
        if (!media || !media.url) return reply(lang("setppNoMedia"));

        try {
            const buffer = await conn.downloadMediaMessage(m);
            await conn.updateProfilePicture(buffer);
            reply(lang("setppSuccess"));
        } catch (error) {
            console.error("Failed to update profile picture:", error);
            reply(lang("setppFail"));
        }
    });
//===================================================================
cmd({
  on: "body"
},    
async (conn, mek, m, { from, body }) => {
    const fileUrl = 'https://raw.githubusercontent.com/vishwamihiranga/BHASHI-PUBLIC/refs/heads/main/auto_voice.json';

    try {
        // Fetch the JSON data from the URL
        const response = await axios.get(fileUrl);
        const data = response.data;

        for (const text in data) {
            if (body.toLowerCase() === text.toLowerCase()) {
                const config = await readEnv();
                if (config.AUTO_VOICE === 'true') {
                    await conn.sendPresenceUpdate('recording', from);
                    await conn.sendMessage(from, { audio: { url: data[text] }, mimetype: 'audio/mpeg', ptt: true }, { quoted: mek });
                }
            }
        }
    } catch (error) {
        console.error('Error fetching or processing auto_voice.json:', error);
        // Do nothing visible to the user
    }
});

//===================================================================
cmd({
  on: "body"
},    
async (conn, mek, m, { from, body }) => {
    const fileUrl = 'https://raw.githubusercontent.com/vishwamihiranga/BHASHI-PUBLIC/refs/heads/main/AUTO-STICKER/auto_sticker.json';

    try {
        // Fetch the JSON data from the URL
        const response = await axios.get(fileUrl);
        const data = response.data;

        for (const text in data) {
            if (body.toLowerCase() === text.toLowerCase()) {
                const config = await readEnv();
                if (config.AUTO_STICKER === 'true') {
                    await conn.sendPresenceUpdate('composing', from);
                    await conn.sendMessage(from, { sticker: { url: data[text] },package:'BHASHI-MD-V2' }, { quoted: mek });
                }
            }
        }
    } catch (error) {
        console.error('Error fetching or processing auto_sticker.json:', error);
        // Do nothing visible to the user
    }
});
//===================================================================
cmd({
  on: "body"
},    
async (conn, mek, m, { from, body }) => {
    const fileUrl = 'https://raw.githubusercontent.com/vishwamihiranga/BHASHI-PUBLIC/refs/heads/main/auto_reply.json';

    try {
        // Fetch the JSON data from the URL
        const response = await axios.get(fileUrl);
        const data = response.data;

        // Read the language configuration
        const config = await readEnv();
        const language = config.LANGUAGE || 'EN'; // Default to English (EN)

        if (data[language]) {
            for (const text in data[language]) {
                if (body.toLowerCase() === text.toLowerCase()) {
                    if (config.AUTO_REPLY === 'true') {
                        await m.reply(data[language][text]);
                    }
                }
            }
        } else {
            console.error(`Language "${language}" not found in auto_reply.json.`);
        }
    } catch (error) {
        console.error('Error fetching or processing auto_reply.json:', error);
        // Do nothing visible to the user
    }
});
//===================================================================
/*
cmd({
  on: "body"
}, async (conn, mek, m, { from, body, quoted }) => {
    // Check if the message is a reply to another message (quoted message)
    if (quoted) {
        try {
            // Fetch the configuration for AUTO_AI_CHAT
            const config = await readEnv();
            const AUTO_AI_CHAT = config.AUTO_AI_CHAT === 'true'; // Ensure it's true to trigger AI response

            // Check if AI chat is enabled
            if (AUTO_AI_CHAT) {
                // Construct the API URL for AI response
                const apiUrl = `https://www.dark-yasiya-api.site/ai/chatgpt?q=${encodeURIComponent(body)}`;

                // Fetch the AI response from the API
                const response = await axios.get(apiUrl);
                const data = response.data;

                if (data.status) {
                    // Send AI response to the user
                    await m.reply(data.result);
                } else {
                    // Handle case where AI API doesn't return a valid result
                    console.error("AI API returned no valid result.");
                    await m.reply('Sorry, I couldn’t fetch an AI response at the moment.');
                }
            }
        } catch (error) {
            // Catch any unexpected errors (API issues, network errors, etc.)
            console.error('Error during AI response:', error);
            await m.reply('Sorry, there was an error while fetching the AI response.');
        }
    }
});
*/
//===================================================================