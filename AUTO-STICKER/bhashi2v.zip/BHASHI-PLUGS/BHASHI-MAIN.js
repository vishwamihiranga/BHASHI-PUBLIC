const axios = require('axios');
const os = require('os');
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson } = require('../BHASHI-DB/mainfun')
const { cmd, commands } = require('../commands');
const {readEnv,updateEnv} = require('../BHASHI-DB/settingsdb2')
const path = require('path');
const fetch = require('node-fetch');
const { Buffer } = require('buffer'); 
const fs = require('fs');
const EnvVar = require('../BHASHI-DB/envdb');
const botimg = 'https://i.ibb.co/WDHqtHH/image.png'
const botimg2 = 'https://scontent.fcmb4-2.fna.fbcdn.net/v/t39.30808-6/468003476_1098693631878195_3930999150535138549_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=833d8c&_nc_ohc=6ecL5i4gGb4Q7kNvgGLSZGI&_nc_zt=23&_nc_ht=scontent.fcmb4-2.fna&_nc_gid=AxklAtucXTVxJXA99daeX6m&oh=00_AYA1Wo1nOLQT5DLP5JmtCJK3ntbmKRLgTgdYMqXF2V7HTg&oe=674645FE'
const readmore = "\u200B".repeat(4000); 
const mono = "`"
const NineGag = require('9gag');
const Scraper = NineGag.Scraper;
const { tiktokdl } = require('tiktokdl')
let vishwa;
(async () => {
    try {
        let vishwaGet = await fetchJson('https://raw.githubusercontent.com/vishwamihiranga/BHASHI-PUBLIC/refs/heads/main/vishwa.json');
        vishwa = vishwaGet.api; 
    } catch (error) {
        console.error('Error fetching base URL:', error);
    }
})();
const https = require('https')
const yts = require('yt-search');
const qrcode = require('qrcode');
const {Sticker, createSticker, StickerTypes} = require("wa-sticker-formatter");
const vishwa2 = `https://vishwa-api-78d69c95453f.herokuapp.com`
const math = require('mathjs');
const dns = require('dns');
const whois = require('whois')
const crypto = require('crypto');
const cheerio = require('cheerio');
const { File } = require('megajs'); // Ensure 'megajs' is installed
//=================================================================


//======================- RANDOM COMMANDS -=======================
cmd({
    pattern: "randommeme",
    react: "🤣",
    desc: "Get a random meme to laugh at.",
    category: "random",
    use: ".randommeme",
    filename: __filename
},
async (conn, mek, m, { from, reply }) => {
    try {
        const memeAPI = "https://api.imgflip.com/get_memes";
        const response = await axios.get(memeAPI);

        // Ensure the response has valid data
        if (response.data.success && response.data.data.memes.length > 0) {
            const memes = response.data.data.memes;
            const randomMeme = memes[Math.floor(Math.random() * memes.length)];
            const memeImageUrl = randomMeme.url;

            // Send the meme as an image with a caption
            await conn.sendMessage(from, { 
                image: { url: memeImageUrl }, 
                caption: "🤣 *Here is your random meme!*" 
            });
        } else {
            throw new Error("No memes found in API response.");
        }
    } catch (error) {
        // Handle errors gracefully
        await reply("❌ *Failed to fetch a random meme.* Please try again later.");
        console.error("Random Meme Error:", error);
    }
});


//=================================================================
cmd({
    pattern: "rvideo",
    alias: ["randomvideo"],
    desc: "Fetch and send a random video from Pexels.",
    category: "ramdom",
    react: "🎥",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Multi-language support: Detect user language
        const language = config.LANGUAGE === 'SI' ? 'SI' : 'EN';

        const messages = {
            EN: {
                noPermission: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!",
                blacklisted: "🚫 You are blacklisted. Access denied.",
                downloading: "⏳ *Please wait, your video is downloading...* ⏳",
                noVideo: "❌ No video files found.",
                error: "❌ Error: "
            },
            SI: {
                noPermission: "😢 ඔබට මෙම විධානය භාවිතා කිරීමේ අවසරය නොමැත. 🎁 බොට් ක්‍රමය වෙනස් කරන්න!",
                blacklisted: "🚫 ඔබ කළු ලැයිස්තුවට ඇතුළත් කර ඇත. ප්‍රවේශය අත්හැරීම.",
                downloading: "⏳ *කරුණාකර රැඳී සිටින්න, ඔබගේ වීඩියෝව බාගත වෙමින් පවතී...* ⏳",
                noVideo: "❌ වීඩියෝ ගොනු සොයා ගත නොහැක.",
                error: "❌ දෝෂය: "
            }
        };

        const lang = messages[language];

        // Check access permissions
        if (!checkAccess(senderNumber, isGroup)) {
            if (blacklistedJIDs.includes(senderNumber)) {
                return reply(lang.blacklisted);
            } else {
                return reply(lang.noPermission);
            }
        }

        // Notify the user that the video is being downloaded
        await conn.sendMessage(from, { text: lang.downloading }, { quoted: mek });

        // Pexels API request to fetch a random video
        const apiUrl = `https://api.pexels.com/videos/search?query=random&per_page=1&page=${Math.floor(Math.random() * 100) + 1}`;
        const response = await axios.get(apiUrl, { headers: { Authorization: config.PEXELS_API_KEY } });

        // Check if video data exists
        const video = response.data.videos[0];
        if (!video || !video.video_files || video.video_files.length === 0) {
            return reply(lang.noVideo);
        }

        // Get the video file link
        const videoUrl = video.video_files[0].link;
        const videoTitle = video.title || 'Random Video';

        // Download the video
        const videoPath = path.join(__dirname, 'tempVideo.mp4'); // Temporary path for the video
        const writer = fs.createWriteStream(videoPath);

        const responseVideo = await axios.get(videoUrl, { responseType: 'stream' });
        responseVideo.data.pipe(writer);

        // Await the completion of file download
        await new Promise((resolve, reject) => {
            writer.on('finish', resolve); // Resolve when writing finishes
            writer.on('error', reject); // Reject if an error occurs
        });

        // Notify the user and send the video after download
        await conn.sendMessage(from, { video: { url: videoPath }, caption: `🎥 *Random Pexels Video* 🎥\n\nTitle: ${videoTitle}\n\n> ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ ㋛` }, { quoted: mek });

        // Clean up the downloaded video file
        fs.unlinkSync(videoPath);

    } catch (e) {
        console.log(e);
        reply(`${lang.error}${e.message}`);
    }
});
//=================================================================
cmd({
    pattern: "dogbreed",
    desc: "Get information about a random dog breed",
    category: "random",
    react: "🐶",
    filename: __filename
}, async (conn, mek, m, { reply }) => {
    const config = await readEnv();
    // Define language preference (SI for Sinhala, EN for English)
    const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

    try {
        const response = await fetch('https://dog.ceo/api/breeds/image/random');
        const data = await response.json();
        const breed = data.message.split('/')[4];

        // Localized messages
        const breedInfo = {
            SI: `🐶 සයුරුවා: ${breed.charAt(0).toUpperCase() + breed.slice(1)}\n\nමෙය ${breed} සයුරුවාගේ අහම්බෙන් ඇති අඳුනකි.`,
            EN: `🐶 Breed: ${breed.charAt(0).toUpperCase() + breed.slice(1)}\n\nThis is a random image of a ${breed}.`
        };

        await conn.sendMessage(m.chat, { image: { url: data.message }, caption: breedInfo[language] });
    } catch (error) {
        console.error(error);
        const errorMsg = {
            SI: "⚠️ සයුරුවා තොරතුරු ලබා ගැනීමේදී දෝෂයක් සිදු විය.",
            EN: "⚠️ An error occurred while fetching dog breed information."
        };
        await reply(errorMsg[language]);
    }
});

//=================================================================
cmd({
    pattern: "cocktail",
    desc: "Get a random cocktail recipe",
    category: "random",
    react: "🍹",
    filename: __filename
}, async (conn, mek, m, { reply }) => {
    const config = await readEnv();
    // Define language preference (SI for Sinhala, EN for English)
    const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

    try {
        const response = await fetch('https://www.thecocktaildb.com/api/json/v1/1/random.php');
        const data = await response.json();
        const drink = data.drinks[0];
        let ingredients = '';

        for (let i = 1; i <= 15; i++) {
            if (drink[`strIngredient${i}`]) {
                ingredients += `${drink[`strIngredient${i}`]} - ${drink[`strMeasure${i}`] || (language === 'SI' ? 'ඇවිලෙන තරමට' : 'To taste')}\n`;
            }
        }

        const replyText = {
            SI: `*🍹 අහම්බෙන් තේරූ කෝක්ටේල්:* ${drink.strDrink}\n\n*අවශ්‍ය ද්‍රව්‍ය:*\n${ingredients}*ඉතිරි කරුණු:*\n${drink.strInstructions}`,
            EN: `*🍹 Random Cocktail:* ${drink.strDrink}\n\n*Ingredients:*\n${ingredients}*Instructions:*\n${drink.strInstructions}`
        };

        await reply(replyText[language]);
    } catch (error) {
        console.error(error);
        const errorMsg = {
            SI: "⚠️ කෝක්ටේල් නිපැයුම් තොරතුරු ලබා ගැනීමට දෝෂයක් සිදුවිය.",
            EN: "⚠️ An error occurred while fetching a cocktail recipe."
        };
        await reply(errorMsg[language]);
    }
});
//=================================================================
cmd({
    pattern: 'rcoffee',
    desc: "Animal image.",
    react: '☕',
    category: "other",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {

    try {
        const config = await readEnv();
        const langs = ['EN', 'SI'].includes(config.LANGUAGE) ? config.LANGUAGE : 'EN';
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Check access permissions
        if (!checkAccess(senderNumber, isGroup)) {
            if (blacklistedJIDs.includes(senderNumber)) {
                return reply(messages[langs].blacklisted);
            } else {
                return reply(messages[langs].accessDenied);
            }
        }

        const sendRandomCoffee = async () => {
            const coffeeUrl = "https://coffee.alexflipnote.dev/random";
            const messageText = messages[langs].randomCoffee;

            return await conn.sendMessage(from, {
                image: { url: coffeeUrl },
                caption: messageText
            }, { quoted: mek });
        };

        const handleUserResponse = async (sentMessage) => {
            conn.ev.once('messages.upsert', async (messageUpsert) => {
                const msg = messageUpsert.messages[0];
                if (!msg.message || !msg.message.extendedTextMessage) return;

                const userReply = msg.message.extendedTextMessage.text.trim();
                const messageContext = msg.message.extendedTextMessage.contextInfo;

                if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                    if (userReply === '1') {
                        const newSentMessage = await sendRandomCoffee();
                        handleUserResponse(newSentMessage);
                    } else {
                        reply(messages[langs].invalidInput);
                    }
                } else {
                    handleUserResponse(sentMessage); 
                }
            });
        };

        const sentMessage = await sendRandomCoffee();
        handleUserResponse(sentMessage);

    } catch (error) {
        console.log(error);
        reply(messages[langs].errorOccurred + error.message);
    }
});

//===================================================================
cmd({
    pattern: "rimgs",
    desc: "Random image.",
    react: '🪄',
    category: "random",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN'; // Fallback to 'EN' if LANGUAGE is not set
        const messages = {
            EN: {
                blacklisted: "You are blacklisted.",
                accessDenied: "You don't have access to this feature.",
                randomImage: "Here is a random image for you!",
                invalidInput: "Invalid input, please reply with '1' to get another image.",
                errorOccurred: "An error occurred: "
            },
            SI: {
                blacklisted: "ඔබ කළු ලිස්තුවේ වේ.",
                accessDenied: "ඔබට මෙම විශේෂාංගය භාවිතා කිරීමට අවසර නැත.",
                randomImage: "ඔබට යමක් සදහා පින්තූරයකි!",
                invalidInput: "වැරදි ආදානයක්, වෙනත් පින්තූරයක් ලබා ගැනීමට '1' යන්නෙන් පිළිතුරු දෙන්න.",
                errorOccurred: "දෝෂයක් සිදු විය: "
            }
        };

        // Check access permissions
        if (!checkAccess(senderNumber, isGroup)) {
            if (blacklistedJIDs.includes(senderNumber)) {
                return reply(messages[lang].blacklisted);
            } else {
                return reply(messages[lang].accessDenied);
            }
        }

        const sendRandomImage = async () => {
            const imageUrl = "https://random-image-pepebigotes.vercel.app/api/random-image";
            const messageText = messages[lang].randomImage;

            return await conn.sendMessage(from, {
                image: { url: imageUrl },
                caption: messageText
            }, { quoted: mek });
        };

        let sentMessage = await sendRandomImage();

        conn.ev.on('messages.upsert', async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                if (userReply === '1') {
                    sentMessage = await sendRandomImage();
                } else {
                    reply(messages[lang].invalidInput);
                }
            }
        });

    } catch (error) {
        console.log(error);
        reply(messages[lang].errorOccurred + error.message);
    }
});

//=================================================================
cmd({
    pattern: 'rcolor',
    desc: 'Get a random color with its name and image.',
    category: 'random',
    react: '🎨',
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const messages2 = {
        EN: {
            accessDenied: "*😢 Access denied. You don't have permission to use this command. 🎁 Change Bot Mode!*",
            randomColor: `💌 *This Is Your Random Color* 💫
    ✨ *Color Name:* {name}
    🎉 *Color Code:* {code}

    1 | *Get Another One*
`,
            invalidInput: "⚠️ *Invalid input. Reply with 1 to get another random color.*",
            errorOccurred: "⚠️ An error occurred while fetching the random color."
        },
        SI: {
            accessDenied: "*😢 ප්‍රවේශය අකාර්යයි. ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත. 🎁 බොට් ආකාරය වෙනස් කරන්න!*",
            randomColor: `💌 *මෙන්න ඔබේ රන්ඩම් වර්ණය* 💫
    ✨ *වර්ණ නාමය:* {name}
    🎉 *වර්ණ කේතය:* {code}

    1 | *තවත් එකක් ගන්න*
`,
            invalidInput: "⚠️ *අවලංගු ආදාන. තවත් රන්ඩම් වර්ණයක් ලබා ගැනීමට 1 එකක් ප්‍රතිචාර දිය යුතුයි.*",
            errorOccurred: "⚠️ රන්ඩම් වර්ණය ලබා ගැනීමේදී දෝෂයක් සිදු විය."
        }
    };
    try {
        const config = await readEnv();
        const lang3 = ['EN', 'SI'].includes(config.LANGUAGE) ? config.LANGUAGE : 'EN'; // Set default language
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;


        // Function to fetch and send random color
        const sendRandomColor = async () => {
            const response = await axios.get('https://api.popcat.xyz/randomcolor');
            const color = response.data;

            // Construct the message
            const messageText = messages2[lang3].randomColor
                .replace("{name}", color.name)
                .replace("{code}", color.hex);

            // Send the color code, name, and image to the user
            return await conn.sendMessage(from, {
                image: { url: color.image },
                caption: messageText
            }, { quoted: mek });
        };

        // Recursive function to handle user requests for new colors
        const handleUserResponse = async (sentMessage) => {
            conn.ev.once('messages.upsert', async (messageUpsert) => {
                const msg = messageUpsert.messages[0];
                if (!msg.message || !msg.message.extendedTextMessage) return;

                const userReply = msg.message.extendedTextMessage.text.trim();
                const messageContext = msg.message.extendedTextMessage.contextInfo;

                // Check if the reply is to the previously sent random color message
                if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                    if (userReply === '1') {
                        // User requested another random color
                        const newSentMessage = await sendRandomColor();
                        handleUserResponse(newSentMessage); // Call the function again for the next response
                    } else {
                        reply(messages2[lang3].invalidInput);
                        // You can also terminate the session here if needed
                    }
                } else {
                    // If the reply is not to the random color message, just listen again
                    handleUserResponse(sentMessage); 
                }
            });
        };

        // Send the first random color and start listening for replies
        const sentMessage = await sendRandomColor();
        handleUserResponse(sentMessage);

    } catch (e) {
        console.error('Error fetching random color:', e);
        reply(messages2[lang3].errorOccurred);
    }
});
//=================================================================
cmd({
    pattern: "dog",
    alias: ["rdog"],
    desc: "Fetch a random dog image.",
    category: "random",
    react: "🐶",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Get the language preference
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Multi-language messages
        const accessDeniedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
        const accessDeniedGeneral = lang === 'SI' ? "*😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!*" : "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*";
        const errorFetchingText = lang === 'SI' ? '🐶  සුරතල් බල්ලාගේ පින්තූරයක් ලබා ගැනීමට දෝෂයක් ඇතිවිය.' : '🐶 Error fetching dog image.';

        const apiUrl = `https://dog.ceo/api/breeds/image/random`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        await conn.sendMessage(from, {
            image: { url: data.message },
            caption: lang === 'SI' 
                ? '🐶 *යූනික් අන්දුනේ සුරතල් බල්ලා* 🐶\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}' 
                : `🐶 *Random Dog Image* 🐶\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`
        }, { quoted: mek });

    } catch (e) {
        console.log(e);
        reply(errorFetchingText);
    }
});
//=================================================================







//===========================- NEWS COMMANDS -=====================

//=================================================================
cmd({
    pattern: "technews",
    alias: ["androidwadakarayo"],
    desc: "Get the latest Android Wedakarayo tech news.",
    category: "news",
    react: "📰",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, reply }) => {
    const config = await readEnv();
    try {
        await conn.sendMessage(from, { text: '📰 *Fetching latest tech news...*' }, { quoted: mek });

        // Fetch the list of tech news articles from the API
        const newsApiUrl = `${vishwa2}/misc/androidwadakarayo?limit=50&apikey=key1`;
        const response = await axios.get(newsApiUrl);

        if (response.data.status !== "success" || !response.data.data || response.data.data.length === 0) {
            const noNewsMessage = {
                SI: "❌ *වර්තමාන වශයෙන් තාක්ෂණික පුවත් නොමැත.*",
                EN: "❌ *No tech news available at the moment.*"
            };
            return reply(noNewsMessage[config.LANGUAGE]);
        }

        // Generate a message containing the list of articles
        let newsMessage = {
            SI: `📰 *Android Wedakarayo අලුත්ම තාක්ෂණික පුවත්:*\n\n`,
            EN: `📰 *Android Wedakarayo Latest Tech News:*\n\n`
        };

        response.data.data.forEach((article, index) => {
            newsMessage[config.LANGUAGE] += `*${index + 1}.* 📌 *${article.title}*\n`;
            newsMessage[config.LANGUAGE] += `   🗓️ *ප්‍රකාශිත වේලාව >* ${article.publishedTime}\n`; // Sinhala
            newsMessage[config.LANGUAGE] += `   🗓️ *Published >* ${article.publishedTime}\n`; // English
            newsMessage[config.LANGUAGE] += `   📃 *කියවීමේ කාලය >* ${article.readTime}\n`; // Sinhala
            newsMessage[config.LANGUAGE] += `   📃 *Read Time >* ${article.readTime}\n\n`; // English
            newsMessage[config.LANGUAGE] += `   🔔 *ශ्रेණිය >* ${article.category}\n\n`; // Sinhala
            newsMessage[config.LANGUAGE] += `   🔔 *Category >* ${article.category}\n\n`; // English
        });

        newsMessage[config.LANGUAGE] += "➤ *අයදුම්පතක් තෝරා ගැනීම සඳහා එක් අංකයක් පිළිතුරු කරන්න.*"; // Sinhala
        newsMessage[config.LANGUAGE] += "➤ *Reply with a number to read more about the selected article.*"; // English

        const sentMessage = await conn.sendMessage(from, { text: newsMessage[config.LANGUAGE] }, { quoted: mek });

        // Listen for replies with article selection
        conn.ev.on("messages.upsert", async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                const index = parseInt(userReply) - 1;

                if (isNaN(index) || index < 0 || index >= response.data.data.length) {
                    const invalidSelectionMessage = {
                        SI: "❌ *වැරදි තෝරා ගැනීම. කරුණාකර වලංගු අංකයක් පිළිතුරු කරන්න.*",
                        EN: "❌ *Invalid selection. Please reply with a valid number.*"
                    };
                    return reply(invalidSelectionMessage[config.LANGUAGE]);
                }

                // Fetch detailed article info for the selected article
                const selectedArticle = response.data.data[index];
                const articleInfoUrl = `${vishwa2}/misc/article-info?url=${encodeURIComponent(selectedArticle.link)}&apikey=key1`;

                const articleInfoResponse = await axios.get(articleInfoUrl);
                if (articleInfoResponse.data.status !== "success" || !articleInfoResponse.data.data) {
                    const fetchErrorMessage = {
                        SI: "❌ *කථාව පිළිබඳ විස්තර ලබා ගැනීමට අසාර්ථකයි.*",
                        EN: "❌ *Failed to retrieve article information.*"
                    };
                    return reply(fetchErrorMessage[config.LANGUAGE]);
                }

                const articleDetails = articleInfoResponse.data.data;

                // Send article details to the user
                let articleMessage = {
                    SI: `📰 *${articleDetails.title}*\n\n`,
                    EN: `📰 *${articleDetails.title}*\n\n`
                };

                articleMessage[config.LANGUAGE] += `📖 *සාරාංශය:*\n${articleDetails.content}\n\n`; // Sinhala
                articleMessage[config.LANGUAGE] += `📖 *Summary:*\n${articleDetails.content}\n\n`; // English
                articleMessage[config.LANGUAGE] += `🔗 *ඉදිරියට කියවන්න >* ${articleDetails.source}\n`; // Sinhala
                articleMessage[config.LANGUAGE] += `🔗 *Read more >* ${articleDetails.source}\n`; // English
                articleMessage[config.LANGUAGE] += `🗓️ *ප්‍රකාශිත වේලාව >* ${articleDetails.writtenDate}\n`; // Sinhala
                articleMessage[config.LANGUAGE] += `🗓️ *Published on >* ${articleDetails.writtenDate}\n`; // English
                articleMessage[config.LANGUAGE] += `✍️ *ලේඛකය >* ${articleDetails.writerName}\n`; // Sinhala
                articleMessage[config.LANGUAGE] += `✍️ *Author >* ${articleDetails.writerName}\n`; // English
                articleMessage[config.LANGUAGE] += `⏳ *කියවීමේ කාලය >* ${articleDetails.readTime}\n\n`; // Sinhala
                articleMessage[config.LANGUAGE] += `⏳ *Read Time >* ${articleDetails.readTime}\n\n`; // English
                articleMessage[config.LANGUAGE] += `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;
                 await conn.sendMessage(m.chat, { react: { text: "♻", key: msg.key } });
                await conn.sendMessage(from, { text: articleMessage[config.LANGUAGE] }, { quoted: mek });
                 await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
            }
        });
    } catch (e) {
        console.log(e);
        const errorMessage = {
            SI: `❌ *දෝෂයක් සිදු විය:* ${e.message}`,
            EN: `❌ *Error:* ${e.message}`
        };
        reply(errorMessage[config.LANGUAGE]);
    }
});
//=================================================================
cmd({
  pattern: "hackernews",
  alias: ["hn"],
  desc: "Search for the latest articles on The Hacker News and get details.",
  react: "📰",
  category: "search",
  filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
  try {
      const config = await readEnv();
    const apiKey = "key1"; // Your provided API key
    const apiUrl = `${vishwa2}/misc/the-hacker-news-list?apikey=key1`;
    const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'

    const response = await axios.get(apiUrl);
    const articlesData = response.data;

    // Check if the response contains articles
    if (!articlesData.data || articlesData.data.length === 0) {
      const noArticlesMessage = {
        SI: "❌ කිසිදු ලිපියක් නොමැත.",
        EN: "❌ No articles found."
      };
      return reply(noArticlesMessage[language]);
    }

    // Message display
    let resultMessage = {
      SI: `*[ 📰 THE HACKER NEWS ARTICLES ]*:\n` +
          `\n> මෙම ලිපි පිළිබඳ වැඩිදුර කියවීමට ලිපි අංකය ආපහු පිළිතුරු දෙන්න.\n\n`,
      EN: `*[ 📰 THE HACKER NEWS ARTICLES ]*:\n` +
          `\n> Reply with the number of the article you want to read in detail.\n\n`
    };

    // Displaying article details with indexing
    articlesData.data.forEach((article, index) => {
      resultMessage[language] += `📰 *${index + 1}.* ${article.title}\n` +
                                   `   🕒 Published: ${article.date}\n\n`;
    });

    resultMessage[language] += `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ `;

    // Send the initial article list with the external ad promotion
    const sentMessage = await conn.sendMessage(from, {
      text: resultMessage[language],
      externalAdReply: {
        title: `⚜️ ʙʜᴀꜱʜɪ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ ᴡᴀ ʙᴏᴛ 2024™️`,
        body: `⚜️ ʙʜᴀꜱʜɪ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ ᴡᴀ ʙᴏᴛ 2024™️ | ©️ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴠɪꜱʜᴡᴀ ᴍɪʜɪʀᴀɴɢᴀ ᴀɴᴅ ʙʜᴀꜱʜɪᴛʜᴀ | ᴛᴇᴀᴍ ʙʜʀᴋ ᴢᴏɴᴇ`,
        thumbnailUrl: 'https://scontent.xx.fbcdn.net/v/t39.30808-6/462764198_1069447598136132_2931618262689600288_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=833d8c&_nc_eui2=AeHF_DdTFVKCMk4o9b4moBmBfO2n9KL2AN187af0ovYA3S3rE6-rviTKj0Xs3E2cDLPFIUL9Qempb874fyKOG9SS&_nc_ohc=mhCTkQH4HkoQ7kNvgEIPxAj&_nc_ht=scontent.xx&_nc_gid=AdAH9nyr7KupSEtPvuZ6p5q&oh=00_AYDDfmktwQmVzMPqB5v7E0rmaz0Jy1Vo27yDRm1BzgAURg&oe=670ED604', // Add your actual thumbnail URL here
        sourceUrl: 'https://example.com/song-downloader', // Add your actual source URL here
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }, { quoted: mek });

    // Function to handle user replies for article selection
    const handleUserReply = async (messageUpsert) => {
      const msg = messageUpsert.messages[0];
      if (!msg.message || !msg.message.extendedTextMessage) return;

      const userReply = msg.message.extendedTextMessage.text.trim();
      const messageContext = msg.message.extendedTextMessage.contextInfo;

      // Check if the reply matches the original context
      if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
        if (userReply.toLowerCase() === 'done') {
          conn.ev.off("messages.upsert", handleUserReply);
          return reply(language === 'SI' ? "ආයුබෝවන්! Hacker News සෙවීම නිමාවට පත් විය." : "Thank you for using The Hacker News search. Search ended.");
        }

        const articleIndex = parseInt(userReply) - 1;

        // Validate selected article index
        if (articleIndex >= 0 && articleIndex < articlesData.data.length) {
          const selectedArticle = articlesData.data[articleIndex];

          // Check if URL exists before making the detailed API call
          if (!selectedArticle.link) {
            return reply(language === 'SI' ? "❌ මෙම ලිපියට වලංගු URL එකක් නොමැත." : "❌ This article has no valid URL.");
          }

          // Fetch detailed article information
          const detailsApiUrl = `${vishwa2}/misc/the-hacker-news-info?url=${selectedArticle.link}&apikey=key1`;

          try {
            const detailsResponse = await axios.get(detailsApiUrl);
            const articleDetails = detailsResponse.data;

            // Prepare detailed article message
            let detailsMessage = `📰 *${articleDetails.data.title}*\n\n`;
            detailsMessage += `🕒 *Published:* ${articleDetails.data.date}\n`;
            detailsMessage += `👤 *Author:* ${articleDetails.author}\n`;
            detailsMessage += `🔗 *Link:* ${articleDetails.data.link}\n\n`;
            detailsMessage += `📝 *Description:* ${articleDetails.data.content.replace(/Found this article interesting\\? Follow us on Twitter  and LinkedIn to read more exclusive content we post\\./, '')}\n\n`;
            detailsMessage += `🖼️ *Tags:* ${articleDetails.data.tags}\n\n`;

            // Send image if available
            if (articleDetails.data.image && articleDetails.data.image.link) {
                await conn.sendMessage(m.chat, { react: { text: "♻", key: msg.key } });
              await conn.sendMessage(from, {
                caption: detailsMessage,
                image: { url: articleDetails.data.image.link },
                quoted: msg,
                externalAdReply: {
                  title: `⚜️ ʙʜᴀꜱʜɪ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ ᴡᴀ ʙᴏᴛ 2024™️`,
                  body: `⚜️ ʙʜᴀꜱʜɪ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ ᴡᴀ ʙᴏᴛ 2024™️ | ©️ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴠɪꜱʜᴡᴀ ᴍɪʜɪʀᴀɴɢᴀ ᴀɴᴅ ʙʜᴀꜱʜɪᴛʜᴀ | ᴛᴇᴀᴍ ʙʜʀᴋ ᴢᴏɴᴇ`,
                  thumbnailUrl: articleDetails.data.image.link, // Add your actual thumbnail URL here
                  sourceUrl: articleDetails.data.link, // Add your actual source URL here
                  mediaType: 1,
                  renderLargerThumbnail: false
                }
              });
            } else {
              // Send only text if no image, with the external ad reply
              await conn.sendMessage(from, {
                text: detailsMessage,
                quoted: msg,
                externalAdReply: {
                  title: `⚜️ ʙʜᴀꜱʜɪ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ ᴡᴀ ʙᴏᴛ 2024™️`,
                  body: `Click here to explore our song downloader!`,
                  thumbnailUrl: 'https://example.com/thumbnail.jpg', // Add your actual thumbnail URL here
                  sourceUrl: 'https://example.com/song-downloader', // Add your actual source URL here
                  mediaType: 1,
                  renderLargerThumbnail: false
                }
              });
                await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
            }

          } catch (detailsError) {
            console.error(`Error fetching detailed article info: ${detailsError.message}`);
            return reply(language === 'SI' ? "🚨 ලිපි විස්තර ලබා ගැනීමට දෝෂයක් විය." : "🚨 An error occurred while fetching article details.");
          }

        } else {
          // Error handling for invalid article numbers
          reply(language === 'SI' ? `❌ අපේක්ෂිත ලිපි අංකයක් තෝරන්න. 1 සහ ${articlesData.data.length} අතර අංකයක් තෝරන්න.` : `❌ Invalid article number. Please choose a number between 1 and ${articlesData.data.length}.`);
        }
      }
    };

    // Add listener to capture user reply for article selection
    conn.ev.on("messages.upsert", handleUserReply);

  } catch (error) {
    // Error handling for API request failures
    console.error(`Error in The Hacker News search: ${error.response ? error.response.data : error.message}`);
    reply(language === 'SI' ? `🚨 ලිපි ලබා ගැනීමට දෝෂයක් විය: ${error.message}` : `🚨 An error occurred while fetching articles: ${error.message}`);
  }
});


//=================================================
cmd({
  pattern: "sirasa",
  alias: ["sirasalist", "sirasanews"],
  desc: "Get the latest news from Sirasa.",
  react: "📰",
  category: "search",
  filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
  try {
      const config = await readEnv();
    const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'
    const apiUrl = `${vishwa2}/misc/sirasa-latest-list-news?limit=20&multipage=true&apikey=key1`;

    // Fetch the latest news articles
    const response = await fetch(apiUrl);
    const data = await response.json();

    // Check for successful response and valid data array
    if (!data || !data.data || data.data.length === 0) {
      const noNewsMessage = {
        SI: "❌ නවතම වාර්තා සොයාගැනීමට ගැටලුවක් ඇති විය.",
        EN: "❌ No news articles found."
      };
      return reply(noNewsMessage[language]);
    }

    let resultMessage = {
      SI: "*📰 සිරස ප්‍රවෘත්ති ලැයිස්තුව 📰*:\n\n",
      EN: "*📰 SIRASA NEWS LIST 📰*:\n\n"
    };

    const articles = data.data;

    articles.forEach((article, index) => {
      resultMessage[language] += `📅 *${index + 1}.* ${article.title || "Untitled Article"}\n` +
                                  `*${article.date}*\n\n`;
    });

    resultMessage[language] += `\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

    // Send the news articles as a message
    const sentMessage = await conn.sendMessage(from, {
      text: resultMessage[language],
      contextInfo: {
        externalAdReply: {
          title: "BHASHI-MD Sirasa Latest News",
          body: "Stay updated with the latest news.",
          sourceUrl: "https://www.sirasa.lk/"
        }
      }
    }, { quoted: mek });

    // Listen for user replies to the message
    conn.ev.on("messages.upsert", async (messageUpsert) => {
      const msg = messageUpsert.messages[0];
      if (!msg.message || !msg.message.extendedTextMessage) return;

      const userReply = msg.message.extendedTextMessage.text.trim();
      const messageContext = msg.message.extendedTextMessage.contextInfo;

      if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
        const index = parseInt(userReply) - 1;

        // Check if the index is valid
        if (index >= 0 && index < articles.length) {
          const article = articles[index];
          const articleDetails = `📰 *${article.title || "Untitled Article"}*\n` +
            `📅 *Date:* ${article.date}\n` +
            `📜 *Excerpt:* ${article.excerpt}\n`;

          // Fetch article details for the selected article
          const articleDetailsUrl = `${vishwa2}/misc/sirasa-article-details?url=${encodeURIComponent(article.link)}&apikey=key1`;
          const articleDetailsResponse = await fetch(articleDetailsUrl);
          const articleDetailData = await articleDetailsResponse.json();

          if (articleDetailData.status === "success") {
            const fullArticle = articleDetailData.data;
            const detailedMessage = {
              SI: `📰 *${fullArticle.title}*\n\n` +
                  `📜 *අන්තර්ගතය:* ${fullArticle.content}\n` +
                  `📅 *ප්‍රකාශිත දිනය:* ${fullArticle.publishedDate}\n` +
                  `\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
              EN: `📰 *${fullArticle.title}*\n\n` +
                  `📜 *Content:* ${fullArticle.content}\n` +
                  `📅 *Published:* ${fullArticle.publishedDate}\n` +
                  `\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            };

              await conn.sendMessage(m.chat, { react: { text: "♻", key: msg.key } });
            await conn.sendMessage(from, { text: detailedMessage[language] }, { quoted: msg });
              await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
          } else {
            const fetchErrorMessage = {
              SI: "❌ ලිපි විස්තර ලබා ගැනීමට අසාර්ථක විය.",
              EN: "❌ Failed to fetch article details."
            };
            reply(fetchErrorMessage[language]);
          }
        } else {
          const invalidIndexMessage = {
            SI: "❌ කරුණාකර වලංගු ලිපි අංකයක් ලබා දෙන්න.",
            EN: "❌ Please provide a valid article number."
          };
          reply(invalidIndexMessage[language]);
        }
      }
    });

  } catch (e) {
    console.error(e);
    const errorMessage = {
      SI: `🚨 නවතම ප්‍රවෘත්ති ලබා ගැනීමේදී දෝෂයක් ඇති විය: ${e.message}`,
      EN: `🚨 An error occurred while fetching the latest news: ${e.message}`
    };
    reply(errorMessage[language]);
  }
});
//=================================================================
cmd({
  pattern: "esana",
  alias: ['newslist', 'listnews'],
  desc: "Get a list of recent news from Esana.",
  category: "darkqueen",
  react: '📋',
  filename: __filename
}, async (conn, m, { text, reply }) => {
  try {
      const config = await readEnv();
    const senderNumber = m.sender;
    const isGroup = m.isGroup || false;
    const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'

    // Check access permissions
    if (!checkAccess(senderNumber, isGroup)) {
      const accessDeniedMessage = {
        SI: "*🚫 ඔබ බ්ලැක් ලිස්ටු කර තිබේ. ප්‍රවේශය අකාරය.*",
        EN: "*🚫 You are blacklisted. Access denied.*"
      };
      return reply(accessDeniedMessage[language]);
    }

    // Fetch the news list from the API
    const newsList = await api.list();

    // Multi-language support for the news list intro
    const listMessage = {
      SI: "*👩🏻‍🎨 BHASHI-MD ESANA ප්‍රවෘත්ති ලැයිස්තුව 🗞️*\n\n> ඔබ කියවීමට අවශ්‍ය ප්‍රවෘත්තියේ අංකය පිළිතුරු දෙන්න.\n",
      EN: "*👩🏻‍🎨 BHASHI-MD ESANA NEWS LIST 🗞️*\n\n> Reply with the number of the news you want to read.\n"
    };

    let messageContent = listMessage[language];
    newsList.results.forEach((news, index) => {
      messageContent += `*${index + 1}. ${news.title}*\n`;  // Use `title`
      messageContent += `*ID*: ${news.id}\n\n`;             // Use `id`
    });

    messageContent += `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

    // Send the list message
    const sentMessage = await conn.sendMessage(m.chat, { text: messageContent }, { quoted: m });

    // React to the sent message with 📰 emoji
    await conn.sendMessage(m.chat, {
      react: {
        text: '📰',
        key: sentMessage.key
      }
    });

    // Wait for the user's reply
    conn.ev.on("messages.upsert", async (messageUpsert) => {
      const msg = messageUpsert.messages[0];
      if (!msg.message || !msg.message.extendedTextMessage) return;

      const userReply = msg.message.extendedTextMessage.text.trim();
      const messageContext = msg.message.extendedTextMessage.contextInfo;

      // Check if the reply is to the previously sent message
      if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
        const index = parseInt(userReply) - 1; // Convert to zero-based index

        // Validate index
        if (index < 0 || index >= newsList.results.length) {
          const invalidIndexMessage = {
            SI: "❗ වැරදි අංකයකි. කරුණාකර වලංගු අංකයක් සපයන්න.",
            EN: "❗ Invalid index number. Please reply with a valid index."
          };
          return await conn.sendMessage(m.chat, { text: invalidIndexMessage[language] }, { quoted: msg });
        }

        try {
          const newsID = newsList.results[index].id; // Get the news ID using the index

          // Fetch detailed news by ID
          const newsData = await api.news(newsID);
          const newsResults = newsData.results;

          // Multi-language support for news details
          const newsDetails = {
            SI: `*${newsResults.TITLE}*\n
📃 *දිනය*: ${newsResults.PUBLISHED || 'දිනය නොමැත'}
📃 *URL*: ${newsResults.URL || 'URL එක නොමැත'}
📃 *විස්තරය*: ${newsResults.DESCRIPTION || 'විස්තර නොමැත'}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            EN: `*${newsResults.TITLE}*\n
📃 *Date* : ${newsResults.PUBLISHED || 'No date available'}
📃 *URL* : ${newsResults.URL || 'No URL available'}
📃 *Description* : ${newsResults.DESCRIPTION || 'No description available'}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
          };

          // Send cover image if available, otherwise send only text
          if (newsResults.COVER) {
              await conn.sendMessage(m.chat, { react: { text: "♻", key: msg.key } });
            await conn.sendMessage(m.chat, { image: { url: newsResults.COVER }, caption: newsDetails[language] }, { quoted: msg });
              await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
          } else {
              await conn.sendMessage(m.chat, { react: { text: "♻", key: msg.key } });
            await conn.sendMessage(m.chat, { text: newsDetails[language] }, { quoted: msg });
              await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
          }

        } catch (error) {
          console.log(error);
          await conn.sendMessage(m.chat, { text: `❗ Error fetching news: ${error.message}` }, { quoted: msg });
        }
      }
    });

  } catch (error) {
    console.log(error);
    const errorMessage = {
      SI: "❗ ප්‍රවෘත්ති ලැයිස්තුව ලබා ගැනීමේදී දෝෂයක් ඇතිවිය: ",
      EN: "❗ An error occurred while fetching the news list: "
    };
    m.reply(errorMessage[language] + error.message);
  }
});
//=================================================================
cmd({
    pattern: "animenews",
    desc: "Get the latest anime news articles with an image.",
    react: "📰",
    category: "information",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const API_URL = 'https://newsapi.org/v2/everything?q=Anime%20News%20Today&domains=techcrunch.com,animenewsnetwork.com,myanimelist.net,comingsoon.net,crunchyroll.com&language=en&sortby=publishedAt&apikey=cd4116be09ef4a0caceedf21b6258460&pageSize=8';

    const config = await readEnv();
    const lang = config.LANGUAGE ? config.LANGUAGE.toUpperCase() : 'EN'; // Fallback to 'EN' if not set

    // Define multilingual messages
    const messages = {
        noNewsFound: {
            SI: "🪄 මෙම විට පවතින පුවත් කිසිවක් සොයාගත නොහැක.",
            EN: "🪄 No anime news found at the moment."
        },
        errorFetching: {
            SI: "😔 දෝෂයක් ඇති විය: ",
            EN: "😔 An error occurred: "
        },
        randomNews: {
            SI: "📰 *${title}*\n📰 *මූලාශ්‍රය*: ${source}\n✍️ *කතුවරයා*: ${author}\n📅 *ප්‍රකාශිත දිනය*: ${published}\n🔗 *නැරඹුම් URL*: ${url}\n📝 *විස්තරය*: ${description}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
            EN: "📰 *${title}*\n📰 *Source*: ${source}\n✍️ *Author*: ${author}\n📅 *Published On*: ${published}\n🔗 *View URL*: ${url}\n📝 *Description*: ${description}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
        }
    };

    try {
        const response = await fetch(API_URL);
        const newsData = await response.json();

        if (!newsData.articles || newsData.articles.length === 0) {
            return reply(messages.noNewsFound[lang]);
        }

        // Get a random article from the available results
        const randomIndex = Math.floor(Math.random() * newsData.articles.length);
        const news = newsData.articles[randomIndex];

        // Prepare the news message
        const newsMessage = messages.randomNews[lang]
            .replace('${title}', news.title)
            .replace('${source}', news.source.name || "Unknown")
            .replace('${author}', news.author || "Unknown")
            .replace('${published}', new Date(news.publishedAt).toLocaleDateString() || "N/A")
            .replace('${url}', news.url || "N/A")
            .replace('${description}', news.description || "No description available");

        // Send the news along with the image if available
        if (news.urlToImage) {
            await conn.sendMessage(from, {
                caption: newsMessage,
                image: { url: news.urlToImage }
            }, { quoted: mek });
        } else {
            await conn.sendMessage(from, { text: newsMessage }, { quoted: mek });
        }

    } catch (e) {
        console.log(e);
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});
//=================================================================
cmd({
    pattern: "news2",
    desc: "Get a random news article with an image.",
    react: "📰",
    category: "news",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        const config = await readEnv();
const API_URL = 'https://api.polygon.io/v2/reference/news';
const API_KEY = 'Y4iTYoJANwppB8I3Bm4QVWdV5oXlvc45';
        const lang = config.LANGUAGE ? config.LANGUAGE.toUpperCase() : 'EN';

        // Define multilingual messages
        const messages = {
            blacklisted: {
                SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
                EN: "*🚫 You are blacklisted. Access denied.*"
            },
            accessDenied: {
                SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
                EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
            },
            noNewsFound: {
                SI: "🪄 මෙම විට පවතින පුවත් කිසිවක් සොයාගත නොහැක.",
                EN: "🪄 No news found at the moment."
            },
            errorFetching: {
                SI: "😔 දෝෂයක් ඇති විය: ",
                EN: "😔 An error occurred: "
            },
            randomNews: {
                SI: "📰 *${title}*\n📰 *මූලාශ්‍රය*: ${source}\n🔗 *මූලාශ්‍ර වෙබ් පිටුව*: ${homepage}\n✍️ *කතුවරයා*: ${author}\n📅 *ප්‍රකාශිත දිනය*: ${published}\n🔗 *ඇටිකලය URL*: ${url}\n📝 *විස්තරය*: ${description}\n🔑 *කීවර්ඩ්*: ${keywords}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                EN: "📰 *${title}*\n📰 *Source*: ${source}\n🔗 *Publisher Homepage*: ${homepage}\n✍️ *Author*: ${author}\n📅 *Published On*: ${published}\n🔗 *Article URL*: ${url}\n📝 *Description*: ${description}\n🔑 *Keywords*: ${keywords}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            }
        };

        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Fetch news data
        const response = await fetch(`${API_URL}?apiKey=${API_KEY}`);
        const newsData = await response.json();

        if (!newsData.results || newsData.results.length === 0) {
            return reply(messages.noNewsFound[lang]);
        }

        // Get a random article
        const randomIndex = Math.floor(Math.random() * newsData.results.length);
        const news = newsData.results[randomIndex];

        // Prepare the news message
        const newsMessage = messages.randomNews[lang]
            .replace('${title}', news.title)
            .replace('${source}', news.publisher?.name || "N/A")
            .replace('${homepage}', news.publisher?.homepage_url || "N/A")
            .replace('${author}', news.author || "Unknown")
            .replace('${published}', news.published_utc || "N/A")
            .replace('${url}', news.article_url || "N/A")
            .replace('${description}', news.description || "No description available")
            .replace('${keywords}', news.keywords ? news.keywords.join(', ') : "None");

        // Send the news along with the image if available
        if (news.image_url) {
            await conn.sendMessage(from, {
                caption: newsMessage,
                image: { url: news.image_url }
            }, { quoted: mek });
        } else {
            await conn.sendMessage(from, { text: newsMessage }, { quoted: mek });
        }
    } catch (e) {
        console.log(e);
        const lang = config?.LANGUAGE?.toUpperCase() || 'EN';  // Ensure lang is defined in the catch block
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "lankadeepa",
    desc: "Get the latest news from Lankadeepa",
    isGroup: true,
    category: "news",
    react: "📰",
    filename: __filename
}, async (conn, mek, m, { from, isGroup }) => {
    try {
        // Fetching data from the external Lankadeepa news API
        const response = await axios.get("https://www.dark-yasiya-api.site/news/lankadeepa");
        const news = response.data;

        if (news.status) {
            const newsItem = news.result;

            // Check if the description or image is available and set default values if not
            const description = newsItem.desc || "No description available."; // Fallback description
            const imageUrl = newsItem.image || "https://example.com/default-image.jpg"; // Fallback image

            // Message content with emojis and caption
            const message = `📰 *${newsItem.title}* 📰\n\n🔹 *Description:* ${description}\n\n📲 *Read more:* [Full Article](${newsItem.url})\n\n🔗 *Stay updated with the latest news!* \n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

            // Sending the message with image and caption
            await conn.sendMessage(from, {
                image: { url: imageUrl },
                caption: message
            });

        } else {
            await conn.sendMessage(from, { text: "⚠️ Error fetching news. Please try again later." });
        }

    } catch (error) {
        console.error(`Error fetching news: ${error.message}`);
        await conn.sendMessage(from, { text: "❌ Failed to retrieve the latest news. Please try again later." });
    }
});
//=================================================================
cmd({
    pattern: "ada",
    desc: "Get the latest news from ADA",
    isGroup: true,
    category: "news",
    react: "📰",
    filename: __filename
}, async (conn, mek, m, { from, isGroup }) => {
    try {
        // Fetching data from the external API
        const response = await axios.get("https://www.dark-yasiya-api.site/news/ada");
        const news = response.data;

        if (news.status) {
            const newsItem = news.result;

            // Message content with emojis and caption
            const message = `🗞️ *${newsItem.title}* 🗞️\n\n🔹 *Description:* ${newsItem.desc}\n\n📲 *Read more:* ${newsItem.url}\n\n🔗 *Stay updated with the latest news!* \n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

            // Sending the message with image and caption
            await conn.sendMessage(from, {
                image: { url: newsItem.image },
                caption: message
            });

        } else {
            await conn.sendMessage(from, { text: "⚠️ Error fetching news. Please try again later." });
        }

    } catch (error) {
        console.error(`Error fetching news: ${error.message}`);
        await conn.sendMessage(from, { text: "❌ Failed to retrieve the latest news. Please try again later." });
    }
});
//=================================================================
cmd({
    pattern: "dailymirror",
    desc: "Get the latest news from Daily Mirror",
    isGroup: true,
    category: "news",
    react: "📰",
    filename: __filename
}, async (conn, mek, m, { from, isGroup }) => {
    try {
        // Fetching data from the external API
        const response = await axios.get("https://www.dark-yasiya-api.site/news/dailymirror");
        const news = response.data;

        if (news.status) {
            const newsItem = news.result;

            // Message content with emojis and caption
            const message = `🗞️ *${newsItem.title}* 🗞️\n\n🔹 *Description:* ${newsItem.desc}\n\n📲 *Read more:* ${newsItem.url}\n\n🔗 *Stay updated with the latest news!* \n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

            // Sending the message with image and caption
            await conn.sendMessage(from, {
                image: { url: newsItem.image },
                caption: message
            });

        } else {
            await conn.sendMessage(from, { text: "⚠️ Error fetching news. Please try again later." });
        }

    } catch (error) {
        console.error(`Error fetching news: ${error.message}`);
        await conn.sendMessage(from, { text: "❌ Failed to retrieve the latest news. Please try again later." });
    }
});
//=================================================================
cmd({
    pattern: "gagana",
    desc: "Get the latest news on Kurunegala district election results",
    isGroup: true,
    category: "news",
    react: "📰",
    filename: __filename
}, async (conn, mek, m, { from, isGroup }) => {
    try {
        // Fetching data from the external API
        const response = await axios.get("https://www.dark-yasiya-api.site/news/gagana");
        const news = response.data;

        if (news.status) {
            const newsItem = news.result;

            // Message content with emojis and caption
            const message = `🗳️ *${newsItem.title}* 🗳️\n\n🔹 *Description:* ${newsItem.desc}\n\n📲 *Read more:* ${newsItem.url}\n\n🔗 *Stay informed with us!*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

            // Sending the message with image and caption
            await conn.sendMessage(from, {
                image: { url: newsItem.image },
                caption: message
            });

        } else {
            await conn.sendMessage(from, { text: "⚠️ Error fetching news. Please try again later." });
        }

    } catch (error) {
        console.error(`Error fetching news: ${error.message}`);
        await conn.sendMessage(from, { text: "❌ Failed to retrieve the latest news. Please try again later." });
    }
});
//=================================================================





//=====================- ANIME COMMANDS -==========================
//=================================================================
cmd({
    pattern: "upcominganime",
    desc: "Fetch information about upcoming anime releases.",
    category: "anime",
    react: "📅",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const messages = {
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත. 🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command. 🎁 Change Bot Mode!*"
        },
        noUpcomingAnime: {
            SI: "😔 නවතම ඇනිමේ නිකුත් කිරීම් කිසිවක් හමු නොවීය.",
            EN: "😔 No upcoming anime releases found."
        },
        upcomingAnimeTitle: {
            SI: "📅 *නවතම ඇනිමේ නිකුත් කිරීම්*\n\n",
            EN: "📅 *Upcoming Anime Releases*\n\n"
        },
        errorFetching: {
            SI: "😓 නවතම ඇනිමේ නිකුත් කිරීම් ලබා ගැනීමේ දෝෂයක් ඇති විය: ",
            EN: "😓 Error fetching upcoming anime releases: "
        },
        animeDetails: {
            SI: "📺 *ඇනිමේ විස්තර:*",
            EN: "📺 *Anime Details:*"
        },
        watchTrailer: {
            SI: "🎥 *ට්‍රේලර් බැලීමට සොයා ගන්න:*",
            EN: "🎥 *Watch Trailer:*"
        }
    };

    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = (config.LANGUAGE && (config.LANGUAGE.toUpperCase() === 'SI' || config.LANGUAGE.toUpperCase() === 'EN')) ? config.LANGUAGE.toUpperCase() : 'EN';
        console.log("Current Language:", lang); // Debugging line

         // Fetch upcoming anime releases from the API
        const apiUrl = `https://api.jikan.moe/v4/seasons/upcoming`;
        const response = await axios.get(apiUrl);
        const data = response.data;
        if (!data.data || !data.data.length) {
            return reply(messages.noUpcomingAnime[lang]);
        }

        // Format the details of upcoming anime
        let upcomingAnimeDetails = `${messages.upcomingAnimeTitle[lang]}`;
        for (const anime of data.data) {
            const { titles, images, synopsis, trailer, url } = anime;

            const title = titles.find(t => t.type === "Default")?.title || anime.title; // Get default title
            const imageUrl = images.jpg.image_url || images.webp.image_url; // Use JPG or WEBP image
            const trailerUrl = trailer.url || ''; // Use trailer URL if available

            upcomingAnimeDetails += `📺 *${title}*\n🔗 ${url}\n📜 *Synopsis:* ${synopsis}\n${trailerUrl ? `${messages.watchTrailer[lang]} ${trailerUrl}` : ''}\n\n`;
        }

        // Send the upcoming anime list
        await conn.sendMessage(from, { text: upcomingAnimeDetails }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});
//=================================================================
cmd({
    pattern: "topanime",
    desc: "Fetch a list of top-rated anime based on user ratings.",
    category: "anime",
    react: "⭐",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
    // Define multilingual messages
    const messages = {
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        noTopAnime: {
            SI: "😞 නවතම ඇනිමේ සොයා ගැනීමේදී කිසිවක් හමු නොවීය.",
            EN: "😞 No top-rated anime found."
        },
        topAnimeTitle: {
            SI: "⭐ *ඉහලින් අගය කළ ඇනිමේ*\n\n",
            EN: "⭐ *Top Rated Anime*\n\n"
        },
        errorFetching: {
            SI: "😓 ඉහලින් අගය කළ ඇනිමේ ලබා ගැනීමේ දෝෂයක් ඇති විය: ",
            EN: "😓 Error fetching top-rated anime: "
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys

        // Fetch top-rated anime from the API
        const apiUrl = `https://api.jikan.moe/v4/top/anime`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (!data.data || !data.data.length) {
            return reply(messages.noTopAnime[lang]);
        }

        // Format the list of top-rated anime with details
        const topAnimeList = data.data.map(anime => {
            const title = anime.title;
            const score = anime.score ? `${anime.score}` : "N/A";
            const members = anime.members ? `${anime.members}` : "N/A";
            const genres = anime.genres.map(g => `${g.name}`).join(", ");
            const synopsis = anime.synopsis ? `${anime.synopsis.length > 100 ? anime.synopsis.slice(0, 97) + '...' : anime.synopsis}` : " No synopsis available.";
            const link = anime.url;

            return `📺 *Title:* ${title}\n⭐ *Score:* ${score}\n👥 *Members:* ${members}\n🌀 *Genres:* ${genres}\n📜 *Synopsis:* ${synopsis}\n🔗 *Link:* ${link}`;
        }).join('\n\n');

        const topAnimeDetails = `${messages.topAnimeTitle[lang]}${topAnimeList}\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`;

        // Send the top-rated anime list
        await conn.sendMessage(from, { text: topAnimeDetails }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});
//===============================================================
cmd({
    pattern: "anime",
    desc: "Fetch information about an anime.",
    category: "anime",
    react: "📺",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();

    // Define multilingual messages
    const messages = {
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        noAnimeProvided: {
            SI: "📖 කරුණාකර ඇනිමේ නම සපයන්න.",
            EN: "📖 Please provide the name of the anime."
        },
        noAnimeFound: {
            SI: "😞 එම නමින් ඇනිමේ කවදාවත් හමු නොවීය.",
            EN: "😞 No anime found with that name."
        },
        animeInfoTitle: {
            SI: "📜 _*BHASHI-MD ඇනිමේ තොරතුරු*_ 📺",
            EN: "📜 _*BHASHI-MD ANIME INFORMATION*_ 📺"
        },
        errorFetching: {
            SI: "😔 ඇනිමේ තොරතුරු ලබා ගැනීමේ දෝෂයක් ඇති විය: ",
            EN: "😔 Error fetching anime information: "
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys

 
        // Get the anime name from arguments
        const q = args.join(" ");
        if (!q) {
            return reply(messages.noAnimeProvided[lang]);
        }

        // Fetch anime information from the API
        const apiUrl = `https://api.jikan.moe/v4/anime?q=${encodeURIComponent(q)}&limit=1`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (!data.data.length) {
            return reply(messages.noAnimeFound[lang]);
        }

        // Extract anime details
        const anime = data.data[0];
        const trailerUrl = anime.trailer?.url || ""; // Get trailer URL if available
        const animeDetails = `${messages.animeInfoTitle[lang]}\n\n` +
            `📚 *Title:* _${anime.title}_\n` +
            `🎬 *Type:* _${anime.type}_\n` +
            `🎥 *Episodes:* _${anime.episodes || 'N/A'}_\n` +
            `⭐ *Score:* _${anime.score || 'N/A'}_\n` +
            `👥 *Members:* _${anime.members || 'N/A'}_\n` +
            `🧩 *Genres:* _${anime.genres.map(g => g.name).join(', ')}_\n` +
            `📜 *Synopsis:* _${anime.synopsis || 'N/A'}_\n` +
            (trailerUrl ? `📺 *Trailer:* _${trailerUrl}_\n` : "") +
            `🔗 *URL:* _${anime.url}_\n`;

        // Default image if not available
        const animeImage = anime.images?.jpg?.image_url || 'https://via.placeholder.com/300'; // Replace with ALIVE_IMG if defined

        // Send message with anime image and details
        await conn.sendMessage(from, { image: { url: animeImage }, caption: `${animeDetails}\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}` }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});
//================================================================
cmd({
    pattern: "topanimechar",
    desc: "Fetch top anime characters information.",
    category: "anime",
    react: "👤",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const config = await readEnv();

    // Define multilingual messages
    const messages = {
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        errorFetching: {
            SI: "😔 ඇනිමේ චරිත තොරතුරු ලබා ගැනීමේ දෝෂයක් ඇති විය: ",
            EN: "😔 Error fetching anime character information: "
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys


        // Fetch top anime characters information from the API
        const apiUrl = `https://api.jikan.moe/v4/top/characters`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (!data.data.length) {
            return reply(messages.errorFetching[lang] + "No data available.");
        }

        // Extract character details
        const characters = data.data.slice(0, 5); // Fetch top 5 characters
        let charDetails = `📜 _*BHASHI-MD TOP ANIME CHARACTERS*_ 👤\n\n`;
        characters.forEach((char, idx) => {
            const charInfo = `👤 *${idx + 1}. ${char.name}*\n` +
                `⭐ *Favorites:* _${char.favorites || 'N/A'}_\n` +
                `📝 *About:* _${char.about.substring(0, 500)}..._\n\n`+
                `🔗 *More Info:* _${char.url}_\n\n`;
            charDetails += charInfo;
        });

        // Default image if not available
        const charImage = characters[0]?.images?.jpg?.image_url || 'https://via.placeholder.com/300';

        // Send message with top character image and details
        await conn.sendMessage(from, { image: { url: charImage }, caption: `${charDetails}\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}` }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});
//================================================================
cmd({
    pattern: "topvoiceactors",
    desc: "Fetch detailed information about top anime voice actors.",
    category: "anime",
    react: "🎤",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();

    // Define multilingual messages
    const messages = {
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        errorFetching: {
            SI: "😔 දෝෂයක් ඇති විය: ",
            EN: "😔 Error occurred: "
        },
        topVoiceActorsTitle: {
            SI: "🎤 _*BHASHI-MD ප්‍රමුඛතම කථානායකයන් විස්තර*_ 🎬",
            EN: "🎤 _*BHASHI-MD TOP VOICE ACTORS DETAILS*_ 🎬"
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys
        // Fetch top voice actors from the API
        const apiUrl = `https://api.jikan.moe/v4/top/people`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        // Check if data exists
        if (!data.data || !data.data.length) {
            return reply(`${messages.errorFetching[lang]} No data found.`);
        }

        // Prepare the detailed voice actor information
        let details = `${messages.topVoiceActorsTitle[lang]}\n\n`;
        data.data.slice(0, 5).forEach((person, index) => {
            details += `🎤 *Name:* _${person.name}_\n`;
            details += `🔗 *More Info:* ${person.url}\n`;
            details += `🎉 *Birthday:* ${new Date(person.birthday).toLocaleDateString()}\n`;
            details += `💬 *Alternate Names:* ${person.alternate_names.join(", ") || "N/A"}\n`;
            details += `⭐ *Favorites:* ${person.favorites.toLocaleString()}\n`;
            details += `📖 *About:* ${person.about ? person.about.split('\n').slice(0, 2).join('\n') : "No information available."}\n\n`; // Show a short bio (first two lines)
        });

        // Send the details to the user
        await conn.sendMessage(from, { text: details }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});
//===========================================================
cmd({
    pattern: "topmanga",
    desc: "Fetch detailed information about top manga.",
    category: "anime",
    react: "📚",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();

    // Define multilingual messages
    const messages = {
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        errorFetching: {
            SI: "😔 දෝෂයක් ඇති විය: ",
            EN: "😔 Error occurred: "
        },
        topMangaTitle: {
            SI: "📚 _*BHASHI-MD ප්‍රමුඛතම මංගා විස්තර*_ 🎬",
            EN: "📚 _*BHASHI-MD TOP MANGA DETAILS*_ 🎬"
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys

    
        // Fetch top manga from the API
        const apiUrl = `https://api.jikan.moe/v4/top/manga`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        // Check if data exists
        if (!data.data || !data.data.length) {
            return reply(`${messages.errorFetching[lang]} No data found.`);
        }

        // Prepare the detailed manga information
        let details = `${messages.topMangaTitle[lang]}\n\n`;
        data.data.slice(0, 30).forEach((manga, index) => {
            details += `📖 *Title:* _${manga.title}_\n`;
            details += `🔗 *More Info:* ${manga.url}\n`;
            details += `📅 *Published:* ${manga.published.string}\n`;
            details += `⭐ *Score:* ${manga.score} (by ${manga.scored_by.toLocaleString()} users)\n`;
            details += `🎖️ *Rank:* ${manga.rank}\n`;
            details += `🧑‍🤝‍🧑 *Popularity:* ${manga.popularity}\n`;
            details += `📜 *Synopsis:* ${manga.synopsis ? manga.synopsis.split('\n').slice(0, 2).join('\n') : "No synopsis available."}\n`;
            details += `📚 *Genres:* ${manga.genres.map(genre => genre.name).join(', ') || "N/A"}\n`;
            details += `🏷️ *Themes:* ${manga.themes.map(theme => theme.name).join(', ') || "N/A"}\n`;
            details += `✍️ *Authors:* ${manga.authors.map(author => author.name).join(', ') || "N/A"}\n\n\n`;
        });

        // Send the details to the user
        await conn.sendMessage(from, { text: details }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.errorFetching[lang]}${e.message}`);
    }
});
//================================================================






//====================- MOVIEW COMMAND -===========================
//=================================================================
//===============================================================
cmd({
    pattern: '1377x',
    desc: 'Search and fetch torrents for a movie from 1377x',
    category: 'MOVIE',
    react: '🎬',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const query = args.join(' ');

        if (!query) {
            return reply('⚠️ *Please provide a movie name to search for torrents*, e.g., *!torrent Mission*');
        }

        // API URL for fetching torrent details from 1377x
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/1377x?query=${encodeURIComponent(query)}&page=1&apikey=key1`;

        // Fetch torrent data from the 1377x API
        const response = await axios.get(apiUrl);
        const torrents = response.data.searchResults.torrents;

        if (!torrents || torrents.length === 0) {
            return reply('❌ *No torrents found for your search query*. Please try again with a different movie name.');
        }

        // Format the torrent details and send them as a message
        let torrentDetails = '🎥 *Torrent Search Results:* 🎬\n\n';

        torrents.forEach((torrent, index) => {
            torrentDetails += `
✨ *Title:* ${torrent.title}
📅 *Date Added:* ${torrent.date}
📦 *Size:* ${torrent.size}
🌱 *Seeds:* ${torrent.seeds}
👥 *Leeches:* ${torrent.leeches}
📝 *Uploader:* ${torrent.uploader}

🔗 *Link:* [Download Torrent](${torrent.contentLink})

────────────────────────────────────────────
            `;
        });

        // Send the torrent details to the user
        await conn.sendMessage(from, {
            text: torrentDetails,
            caption: `🎬 *Movie Search Results for:* *${query}* 🎥`,
        }, { quoted: mek });

    } catch (error) {
        console.error("Error fetching torrent data from 1377x:", error.message);
        reply("❌ Failed to retrieve torrent details. *Please try again later.*");
    }
});

//=================================================================
cmd({
    pattern: 'ytsmx',
    desc: 'Search movies from YTS (YTS.mx) and display details',
    category: 'MOVIE',
    react: '🎥',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const query = args.join(' ');

        if (!query) {
            return reply('🎬 *Please provide a movie name to search*, e.g., *!yts Mission*');
        }

        // API URL for fetching movie details from YTS API
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/ytsmx2?query=${encodeURIComponent(query)}&apikey=key1`;

        // Fetch movie data from the YTS API
        const response = await axios.get(apiUrl);
        const movieData = response.data.movieData;

        if (!movieData || movieData.length === 0) {
            return reply('❌ *No movies found for your search query*. Please try again with a different movie name.');
        }

        // Loop through the movie data and format the message
        let movieDetails = '🎥 *Movie Search Results*:\n\n';

        movieData.forEach((movie, index) => {
            movieDetails += `
✨ *Title:* ${movie.title_english} (${movie.year}) 
⭐ *Rating:* ${movie.rating} / 10 
🎬 *Genres:* ${movie.genres.join(', ')} 
⏳ *Runtime:* ${movie.runtime} minutes 
🌍 *Language:* ${movie.language.toUpperCase()} 
🎥 *IMDB Code:* ${movie.imdb_code} 
🔗 *Link:* [${movie.title_english}](${movie.url})

🎞️ *Torrent Quality and Size:* 
${movie.torrents.map(torrent => `📽️ ${torrent.quality} (${torrent.size})`).join('\n')}

🖼️ *Cover Image:* 
![Cover Image](${movie.large_cover_image})

🔽 *Download Now*: 
${movie.torrents.map(torrent => `🔗 [Download ${torrent.quality} version](https://yts.mx/torrent/download/${torrent.hash})`).join('\n')}

            `;
        });

        // Send the movie details to the user
        await conn.sendMessage(from, {
            text: movieDetails,
            caption: `🎥 *Movie Search Results for*: *${query}*`,
        }, { quoted: mek });

    } catch (error) {
        console.error("Error fetching movie data from YTS:", error.message);
        reply("❌ *Failed to retrieve movie details*. Try again later.");
    }
});

//=================================================================
//=================================================================
cmd({
    pattern: "trending",
    desc: "Get a list of trending movies.",
    category: "MOVIE",
    react: "🔥",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const apiKey = '76cb7f39'; // Replace with your OMDb API key
    const query = 'popular'; // Query term to simulate trending movies
    const apiUrl = `http://www.omdbapi.com/?s=${query}&apikey=${apiKey}`;

    try {
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.Response === "False") {
            return reply("🚫 No trending movies found.");
        }

        const trendingMovies = data.Search
            .slice(0, 10) // Get top 10 results
            .map((movie, index) => `${index + 1}. *${movie.Title}* (${movie.Year})`)
            .join('\n');

        reply(`🔥 *Trending Movies* 🔥\n\n${trendingMovies}`);
    } catch (e) {
        console.error(e);
        reply(`🚫 Error fetching trending movies: ${e.message}`);
    }
});
//=================================================================

//=================================================================
cmd({
    pattern: "genres",
    desc: "Get a list of popular movie genres.",
    category: "MOVIE",
    react: "🎭",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        const genres = [
            "Action",
            "Adventure",
            "Comedy",
            "Drama",
            "Horror",
            "Science Fiction",
            "Fantasy",
            "Thriller",
            "Romance",
            "Mystery",
            "Animation",
            "Documentary"
        ];

        const genreList = genres.map((genre, index) => `${index + 1}. ${genre}`).join('\n');
        reply(`🎭 *Popular Movie Genres* 🎭\n\n${genreList}`);
    } catch (e) {
        console.error(e);
        reply(`🚫 Error: ${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "nowplaying",
    desc: "Get a list of movies currently playing in theaters.",
    category: "MOVIE",
    react: "🎥",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const apiKey = '76cb7f39';
    const apiUrl = `http://www.omdbapi.com/?s=now&apikey=${apiKey}`;

    try {
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.Response === "False") {
            return reply("🚫 No currently playing movies found.");
        }

        const nowPlayingMovies = data.Search.map(movie => `🎥 *Title:* ${movie.Title} (${movie.Year})`).join('\n');
        reply(`🎥 *Now Playing in Theaters* 🎥\n\n${nowPlayingMovies}`);
    } catch (e) {
        console.error(e);
        reply(`🚫 Error: ${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "toprated",
    desc: "Get a list of top-rated movies.",
    category: "MOVIE",
    react: "⭐",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const apiKey = '76cb7f39';
    const apiUrl = `http://www.omdbapi.com/?s=top&apikey=${apiKey}`;

    try {
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.Response === "False") {
            return reply("🚫 No top-rated movies found.");
        }

        const topMovies = data.Search.map(movie => `⭐ *Title:* ${movie.Title} (${movie.Year})`).join('\n');
        reply(`⭐ *Top Rated Movies* ⭐\n\n${topMovies}`);
    } catch (e) {
        console.error(e);
        reply(`🚫 Error: ${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "newreleases",
    desc: "Get information about the latest movie releases.",
    category: "MOVIE",
    react: "🎬",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const apiKey = '76cb7f39'; // Replace with your OMDb API key
    const apiUrl = `http://www.omdbapi.com/?s=new&apikey=${apiKey}`;

    try {
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.Response === "False") {
            return reply("🚫 No new releases found.");
        }

        let movieList = data.Search.map(movie => `🎥 *Title:* ${movie.Title} (${movie.Year})`).join('\n\n');
        reply(`🎬 *New Releases* 🎬\n\n${movieList}`);
    } catch (e) {
        console.error(e);
        reply(`🚫 Error: ${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "popularmovies",
    desc: "Get popular movies.",
    category: "MOVIE",
    react: "🎥",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const apiKey = '76cb7f39';  // Replace with your OMDb API key
    const apiUrl = `http://www.omdbapi.com/?s=popular&apikey=${apiKey}`;

    try {
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.Response === "False") {
            return reply("🚫 No popular movies found.");
        }

        const randomMovie = data.Search[Math.floor(Math.random() * data.Search.length)];
        const movieInfo = `
🎥 *Popular Movie Recommendation* 🎬
🎥 *Title:* ${randomMovie.Title}
🌏 *Year:* ${randomMovie.Year}
`;

        const imageUrl = randomMovie.Poster !== 'N/A' ? randomMovie.Poster : 'https://via.placeholder.com/500x750';

        await conn.sendMessage(from, {
            image: { url: imageUrl },
            caption: `${movieInfo}\nEnjoy your movie!`
        }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`🚫 Error: ${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "randommovie",
    desc: "Get a random movie recommendation.",
    category: "MOVIE",
    react: "🎲",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
    // Define multilingual messages
    const messages = {
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        noMoviesFound: {
            SI: "🚫 කිසිදු චිත්‍රපටයක් සොයා ගැනිය නොහැකි විය.",
            EN: "🚫 No movies found for the random recommendation."
        },
        randomMovieHeader: {
            SI: "🎥 *රැඳී සිටින චිත්‍රපටය* 🎬\n",
            EN: "🎥 *Random Movie Recommendation* 🎬\n"
        },
        movieTitle: {
            SI: "🎥 *මාතෘකාව:* ",
            EN: "🎥 *Title:* "
        },
        movieYear: {
            SI: "🌏 *වසර:* ",
            EN: "🌏 *Year:* "
        },
        fetchError: {
            SI: "🚫 දෝෂයක් ඇති විය: ",
            EN: "🚫 An error occurred: "
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys


        const apiUrl = `http://www.omdbapi.com/?s=random&apikey=76cb7f39`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.Response === "False") {
            return reply(messages.noMoviesFound[lang]);
        }

        const randomMovie = data.Search[Math.floor(Math.random() * data.Search.length)];
        const randomMovieInfo = `
${messages.randomMovieHeader[lang]}
${messages.movieTitle[lang]}${randomMovie.Title}
${messages.movieYear[lang]}${randomMovie.Year}
`;

        const imageUrl = randomMovie.Poster && randomMovie.Poster !== 'N/A' ? randomMovie.Poster : config.ALIVE_IMG;

        await conn.sendMessage(from, {
            image: { url: imageUrl },
            caption: `${randomMovieInfo}\n${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`
        }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.fetchError[lang]}${e.message} 😓`);
    }
});
//=================================================================
cmd({
    pattern: "movie",
    desc: "Fetch detailed information about a movie.",
    category: "MOVIE",
    react: "🎬",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
    // Define multilingual messages
    const messages = {
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        noMovieName: {
            SI: "📽️ කරුණාකර චිත්‍රපටයේ නම ලබා දෙන්න.",
            EN: "📽️ Please provide the name of the movie."
        },
        movieNotFound: {
            SI: "🚫 චිත්‍රපටය හමු නොවීය.",
            EN: "🚫 Movie not found."
        },
        movieDetails: {
            SI: (data) => `
*☘️ ${data.Title} (${data.Year})*

📆 *අවසන් වූ දිනය:* ${data.Released}
⏳ *කාලය:* ${data.Runtime}
🎭 *වර්ගය:* ${data.Genre}
🎬 *අධ්‍යක්ෂ:* ${data.Director || 'N/A'}
💁‍♀️ *රංගන ශිල්පීන්:* ${data.Actors}
📡 *භාෂාව:* ${data.Language}
🇺🇸 *රට:* ${data.Country}
🏆 *සම්මාන:* ${data.Awards || 'N/A'}
⭐ *IMDb වර්ගය:* ${data.imdbRating || 'N/A'}
            `,
            EN: (data) => `
*☘️ ${data.Title} (${data.Year})*

📆 *Released:* ${data.Released}
⏳ *Runtime:* ${data.Runtime}
🎭 *Genre:* ${data.Genre}
🎬 *Director:* ${data.Director || 'N/A'}
💁‍♀️ *Actors:* ${data.Actors}
📡 *Language:* ${data.Language}
🇺🇸 *Country:* ${data.Country}
🏆 *Awards:* ${data.Awards || 'N/A'}
⭐ *IMDb Rating:* ${data.imdbRating || 'N/A'}
            `
        },
        fetchError: {
            SI: "❌ දෝෂයක් ඇති විය: ",
            EN: "❌ Error: "
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys

        // Ensure movie name is provided
        const movieName = args.join(" ");
        if (!movieName) {
            return reply(messages.noMovieName[lang]);
        }

        const apiUrl = `http://www.omdbapi.com/?t=${encodeURIComponent(movieName)}&apikey=76cb7f39`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.Response === "False") {
            return reply(messages.movieNotFound[lang]);
        }

        // Constructing the movie details message using a function
        const movieInfo = messages.movieDetails[lang](data);

        const imageUrl = data.Poster && data.Poster !== 'N/A' ? data.Poster : config.ALIVE_IMG;

        await conn.sendMessage(from, {
            image: { url: imageUrl },
            caption: `${movieInfo}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply(`${messages.fetchError[lang]}${e.message}`);
    }
});

//=================================================================
cmd({
  pattern: "dl2",
  alias: ["dlf", "fastdl"],
  desc: "Download files from direct links. Can send to specific JID using |",
  category: "MOVIE",
  react: "📥",
  filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {

  // Split input to get URL and target JID
  const fullInput = args.join(" ");
  const [url, targetJid] = fullInput.split('|').map(str => str.trim());
  const destinationJid = targetJid || from;

  if (!url) {
      await m.react("❌");
      return reply("*Please provide a valid download link*\n\n*Usage:*\n*.dl2 [url]*\n*.dl2 [url] | [jid]*\n\n*Example:*\n*.dl2 https://example.com/file.pdf*\n*.dl2 https://example.com/file.pdf | 1234567890@g.us*");
  }

  // Validate JID if provided
  if (targetJid && !targetJid.includes('@')) {
      await m.react("❌");
      return reply("❌ Invalid JID format. Use: url | JID (e.g., https://example.com/file.pdf | 123456789@g.us)");
  }

  try {
      // Send initial processing message
      await m.react("⏳");
      await reply(`*⏳ Processing your download request...*${targetJid ? `\n*🎯 Sending to:* ${targetJid}` : ''}`);

      // Configure headers for the request
      const headers = {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': '*/*',
          'Accept-Encoding': 'gzip, deflate, br',
          'Connection': 'keep-alive'
      };

      // First make a HEAD request to get content type and size
      const headResponse = await axios.head(url, { headers });
      const contentType = headResponse.headers['content-type'] || 'application/octet-stream';
      const contentDisposition = headResponse.headers['content-disposition'];

      // Extract filename from content-disposition, URL, or generate one
      let fileName = '';
      if (contentDisposition) {
          const matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(contentDisposition);
          if (matches && matches[1]) {
              fileName = matches[1].replace(/['"]/g, '');
          }
      }

      // If no filename from content-disposition, try to get from URL
      if (!fileName) {
          const urlParts = url.split('/');
          fileName = urlParts[urlParts.length - 1].split('?')[0]; // Remove query parameters
          fileName = decodeURIComponent(fileName); // Decode URL-encoded characters
          fileName = fileName.replace(/[/\\?%*:|"<>]/g, '-'); // Remove invalid characters
      }

      // If still no filename, generate one
      if (!fileName || fileName === '') {
          fileName = 'downloaded_file';
      }

      // Add appropriate extension based on content type if filename doesn't have one
      if (!fileName.includes('.')) {
          const ext = getExtensionFromMimeType(contentType);
          fileName = `${fileName}.${ext}`;
      }

      // Download and send file
      await conn.sendMessage(destinationJid, {
          document: { url: url },
          fileName: fileName,
          mimetype: contentType,
          caption: `*📁 File:* ${fileName}${targetJid ? '\n*📤 Forwarded by:* ' + pushname : '\n*💫 Downloaded by:* ' + pushname}\n\n*> ${footer}`
      }, { quoted: m });

      // React to success
      await m.react("✅");

      // If sent to different JID, notify sender
      if (targetJid) {
          await reply(`*✅ File sent successfully to:* ${targetJid}`);
      }

  } catch (error) {
      console.error("Error in dl2 command:", error);
      await reply("❌ Failed to download file. Please make sure the link is valid and accessible.");
      await m.react("❌");
  }
});

// Helper function to get file extension from MIME type
function getExtensionFromMimeType(mimeType) {
  const mimeToExt = {
      'application/pdf': 'pdf',
      'application/msword': 'doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
      'application/vnd.ms-excel': 'xls',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
      'application/vnd.ms-powerpoint': 'ppt',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
      'application/zip': 'zip',
      'application/x-rar-compressed': 'rar',
      'application/x-7z-compressed': '7z',
      'video/mp4': 'mp4',
      'video/x-matroska': 'mkv',
      'video/x-msvideo': 'avi',
      'audio/mpeg': 'mp3',
      'audio/wav': 'wav',
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/gif': 'gif',
      'image/webp': 'webp',
      'text/plain': 'txt',
      'text/csv': 'csv',
      'application/json': 'json',
      'application/vnd.android.package-archive': 'apk'
  };

  return mimeToExt[mimeType] || 'bin';
}
//================================================================
cmd({
  pattern: "dl",
  alias: ["direct", "file"],
  desc: "Send any type of file directly. Can send to specific JID using |",
  category: "MOVIE",
  react: "🎥",
  filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {

  // Split input to get URL and target JID
  const fullInput = args.join(" ");
  const [url, targetJid] = fullInput.split('|').map(str => str.trim());
  const destinationJid = targetJid || from;

  if (!url) {
      await m.react("❌");
      return reply("*Please provide a direct file URL*\n\n*Usage:*\n*.dl [url]*\n*.dl [url] | [jid]*\n\n*Example:*\n*.dl https://example.com/file.pdf*\n*.dl https://example.com/file.pdf | 1234567890@g.us*");
  }

  // Validate JID if provided
  if (targetJid && !targetJid.includes('@')) {
      await m.react("❌");
      return reply("❌ Invalid JID format. Use: url | JID (e.g., https://example.com/file.pdf | 123456789@g.us)");
  }

  try {
      // Send initial processing message
      await m.react("⏳");
      await reply(`*⏳ Processing your request...*${targetJid ? `\n*🎯 Sending to:* ${targetJid}` : ''}`);

      // Detect file type from URL
      const fileType = getFileTypeFromUrl(url);
      const fileName = getFileNameFromUrl(url);

      // Download and send file
      await conn.sendMessage(destinationJid, {
          document: { url: url },
          fileName: fileName,
          mimetype: fileType,
          caption: `*📁 File :* ${fileName}${targetJid ? '\n*📤 Forwarded by:* ' + pushname : ''}\n\n> ${footer}`
      }, { quoted: m });

      // React to success
      await m.react("✅");

      // If sent to different JID, notify sender
      if (targetJid) {
          await reply(`*✅ File sent successfully to:* ${targetJid}`);
      }

  } catch (error) {
      console.error("Error in dl command:", error);
      await reply("❌ Failed to process file. Please ensure the URL is valid and accessible.");
      await m.react("❌");
  }
});

// Helper function to get file type from URL
function getFileTypeFromUrl(url) {
  const extension = url.split('.').pop().toLowerCase();
  const mimeTypes = {
      'pdf': 'application/pdf',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'xls': 'application/vnd.ms-excel',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'ppt': 'application/vnd.ms-powerpoint',
      'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'zip': 'application/zip',
      'rar': 'application/x-rar-compressed',
      '7z': 'application/x-7z-compressed',
      'mp4': 'video/mp4',
      'mkv': 'video/x-matroska',
      'avi': 'video/x-msvideo',
      'mp3': 'audio/mpeg',
      'wav': 'audio/wav',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'webp': 'image/webp',
      'txt': 'text/plain',
      'csv': 'text/csv',
      'json': 'application/json',
      'apk': 'application/vnd.android.package-archive'
  };
  return mimeTypes[extension] || 'application/octet-stream';
}

// Helper function to get filename from URL
function getFileNameFromUrl(url) {
  try {
      const urlParts = url.split('/');
      let fileName = urlParts[urlParts.length - 1];
      // Remove query parameters if present
      fileName = fileName.split('?')[0];
      // Decode URL-encoded characters
      fileName = decodeURIComponent(fileName);
      // Replace invalid filename characters
      fileName = fileName.replace(/[/\\?%*:|"<>]/g, '-');
      return fileName || 'downloaded_file';
  } catch (error) {
      return 'downloaded_file';
  }
}
//=================================================================





//=========================- LOGO COMMAND ========================
//================================================================
cmd({
    pattern: 'funplaylogo',
    desc: 'Generate a Fun and Play-themed logo',
    category: 'logo',
    react: '🎉',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🎉 Please provide the text for the Fun and Play Logo, e.g., *!funplaylogo YourText*");
        }

        // API URL for generating the Fun and Play text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=fun-and-play-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Fun and Play Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Fun and Play logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🎉 Here is your Fun and Play Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Fun and Play Logo:", error.message);
        reply("❌ Failed to create Fun and Play Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'wildlogo',
    desc: 'Generate a Design-Wild-themed logo',
    category: 'logo',
    react: '🦁',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🦁 Please provide the text for the Wild Logo, e.g., *!wildlogo YourText*");
        }

        // API URL for generating the Design-Wild text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=wild-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Wild Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Wild logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🦁 Here is your Design-Wild Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Wild Logo:", error.message);
        reply("❌ Failed to create Wild Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'popsiclelogo',
    desc: 'Generate a Design-Popsicle-themed logo',
    category: 'logo',
    react: '🍧',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🍧 Please provide the text for the Popsicle Logo, e.g., *!popsiclelogo YourText*");
        }

        // API URL for generating the Design-Popsicle text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=popsicle-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Popsicle Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Popsicle logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🍧 Here is your Design-Popsicle Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Popsicle Logo:", error.message);
        reply("❌ Failed to create Popsicle Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'silverlogo',
    desc: 'Generate a Design-Silver-themed logo',
    category: 'logo',
    react: '✨',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("✨ Please provide the text for the Silver Logo, e.g., *!silverlogo YourText*");
        }

        // API URL for generating the Design-Silver text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=silver-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Silver Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Silver logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `✨ Here is your Design-Silver Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Silver Logo:", error.message);
        reply("❌ Failed to create Silver Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'romanlogo',
    desc: 'Generate a Design-Roman-themed logo',
    category: 'logo',
    react: '🏛️',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🏛️ Please provide the text for the Roman Logo, e.g., *!romanlogo YourText*");
        }

        // API URL for generating the Design-Roman text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=roman-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Roman Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Roman logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🏛️ Here is your Design-Roman Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Roman Logo:", error.message);
        reply("❌ Failed to create Roman Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'craftslogo',
    desc: 'Generate a Design-Crafts-themed logo',
    category: 'logo',
    react: '🎨',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🎨 Please provide the text for the Crafts Logo, e.g., *!craftslogo YourText*");
        }

        // API URL for generating the Design-Crafts text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=crafts-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Crafts Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Crafts logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🎨 Here is your Design-Crafts Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Crafts Logo:", error.message);
        reply("❌ Failed to create Crafts Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'ampedlogo',
    desc: 'Generate a Design-Amped-themed logo',
    category: 'logo',
    react: '⚡',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("⚡ Please provide the text for the Amped Logo, e.g., *!ampedlogo YourText*");
        }

        // API URL for generating the Design-Amped text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=amped-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Amped Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Amped logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `⚡ Here is your Design-Amped Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Amped Logo:", error.message);
        reply("❌ Failed to create Amped Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'runnerlogo',
    desc: 'Generate a Fortune-themed logo',
    category: 'logo',
    react: '🌟',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🌟 Please provide the text for the Fortune Logo, e.g., *!fortunelogo YourText*");
        }

        // API URL for generating the Fortune text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=fortune-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Fortune Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Fortune logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🌟 Here is your Fortune Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Fortune Logo:", error.message);
        reply("❌ Failed to create Fortune Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'waterlogo',
    desc: 'Generate a Water-themed logo',
    category: 'logo',
    react: '💧',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("💧 Please provide the text for the Water Logo, e.g., *!waterlogo YourText*");
        }

        // API URL for generating the Water text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=water-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Water Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Water logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `💧 Here is your Water Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Water Logo:", error.message);
        reply("❌ Failed to create Water Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'runnerlogo',
    desc: 'Generate a Runner-themed logo',
    category: 'logo',
    react: '🏃',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🏃 Please provide the text for the Runner Logo, e.g., *!runnerlogo YourText*");
        }

        // API URL for generating the Runner text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=runner-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Runner Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Runner logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🏃 Here is your Runner Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Runner Logo:", error.message);
        reply("❌ Failed to create Runner Logo. Try again later.");
    }
});

//===============================================================
cmd({
    pattern: 'blackbirdlogo',
    desc: 'Generate a Blackbird-themed logo',
    category: 'logo',
    react: '🖤',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🖤 Please provide the text for the Blackbird Logo, e.g., *!blackbirdlogo YourText*");
        }

        // API URL for generating the Blackbird text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=blackbird-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Blackbird Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Blackbird logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🖤 Here is your Blackbird Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Blackbird Logo:", error.message);
        reply("❌ Failed to create Blackbird Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'fluffylogo',
    desc: 'Generate a Fluffy-themed logo',
    category: 'logo',
    react: '🦄',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🦄 Please provide the text for the Fluffy Logo, e.g., *!fluffylogo YourText*");
        }

        // API URL for generating the Fluffy text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=fluffy-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Fluffy Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Fluffy logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🦄 Here is your Fluffy Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Fluffy Logo:", error.message);
        reply("❌ Failed to create Fluffy Logo. Try again later.");
    }
});

//=================================================================
cmd({
    pattern: 'smurflogo',
    desc: 'Generate a Smurfs-themed logo',
    category: 'logo',
    react: '💙',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("💙 Please provide the text for the Smurfs Logo, e.g., *!smurflogo YourText*");
        }

        // API URL for generating the Smurfs text logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=smurfs-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Smurfs Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Smurfs logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `💙 Here is your Smurfs Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Smurfs Logo:", error.message);
        reply("❌ Failed to create Smurfs Logo. Try again later.");
    }
});

//================================================================

//=================================================================
cmd({
    pattern: 'comicslogo',
    desc: 'Generate a Comics-themed logo',
    category: 'logo',
    react: '🎨',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🎨 Please provide the text for the Comics Logo, e.g., *!comicslogo YourText*");
        }

        // API URL for generating the logo in Comics style
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=comics-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML response
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Comics Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated Comics logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🎨 Here is your Comics Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Comics Logo:", error.message);
        reply("❌ Failed to create Comics Logo. Try again later.");
    }
});
//================================================================
cmd({
    pattern: 'neonlogo',
    desc: 'Generate a Neon-themed logo',
    category: 'logo',
    react: '✨',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("✨ Please provide the text for the Neon Logo, e.g., *!neonlogo YourText*");
        }

        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=neon-logo&text=${encodeURIComponent(text)}`;

        // Fetch the HTML response from FlamingText
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the correct image URL from the HTML
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Neon Logo. Please try again later.");
        }

        // Fetch the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated logo
        await conn.sendMessage(from, {
            image: buffer,
            caption: `✨ Here is your Neon Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Neon Logo:", error.message);
        reply("❌ Failed to create Neon Logo. Try again later.");
    }
});

//================================================================
cmd({
    pattern: 'glowlogo',
    desc: 'Generate a Glow-themed logo',
    category: 'logo',
    react: '💡',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("💡 Please provide the text for the Glow Logo, e.g., *!glowlogo YourText*");
        }

        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=glow-logo&text=${encodeURIComponent(text)}`;

        // Fetch HTML from FlamingText
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the correct image URL from the HTML
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Glow Logo. Please try again later.");
        }

        // Fetch the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the generated logo
        await conn.sendMessage(from, {
            image: buffer,
            caption: `💡 Here is your Glow Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Glow Logo:", error.message);
        reply("❌ Failed to create Glow Logo. Try again later.");
    }
});
//=================================================================
cmd({
    pattern: 'firelogo',
    desc: 'Generate a Fire-themed logo',
    category: 'logo',
    react: '🔥',
}, async (conn, mek, m, { from, quoted, reply, args }) => {
    try {
        const text = args.join(' ');

        if (!text) {
            return reply("🔥 Please provide the text for the Fire Logo, e.g., *!firelogo YourText*");
        }

        // URL for generating the logo
        const logoGenUrl = `https://flamingtext.com/net-fu/proxy_form.cgi?script=flame-logo&text=${encodeURIComponent(text)}&fontname=nosifer&fillTextType=gradient`;

        // Fetch the HTML content of the FlamingText result page
        const htmlResponse = await axios.get(logoGenUrl);
        const $ = cheerio.load(htmlResponse.data);

        // Extract the temporary image URL from the HTML
        const imageUrl = $('div.ft-result-logo-image-wrapper a.ft-result-img img.logoImage').attr('src');

        if (!imageUrl) {
            return reply("❌ Failed to retrieve the Fire Logo. Please try again later.");
        }

        // Download the image as a buffer
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(imageResponse.data, 'binary');

        // Send the logo to the user
        await conn.sendMessage(from, {
            image: buffer,
            caption: `🔥 Here is your Fire Logo for: *${text}*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
        }, { quoted: mek });
    } catch (error) {
        console.error("Error generating Fire Logo:", error.message);
        reply("❌ Failed to create Fire Logo. Try again later.");
    }
});
//=================================================================
cmd({
  pattern: "pikachu",
  desc: "Creates a surprised Pikachu meme with custom text.",
  react: "⚡",
  category: "logo",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
  // Define language preference (SI for Sinhala, EN for English)
  const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

  // Check if text input is provided
  if (args.length < 1) {
      const noTextMsg = {
          SI: "*♻ කරුණාකර Pikachu මැදුර සඳහා පෙළ ලබා දෙන්න. උදා: !pikachu හෙලෝ එහිදී*",
          EN: "*♻ Please provide text for the Pikachu meme. Example: !pikachu Hello there*"
      };
      return reply(noTextMsg[language]);
  }

  const text = args.join(" ");

  try {
      const senderNumber = m.sender;
      const isGroup = m.isGroup || false;

      const errorMsg = {
          SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප කරයි. ඔබට මෙම විශේෂණය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ආකාරය වෙනස් කරන්න!*",
          EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
      };

      // Fetch the Pikachu meme image from the API
      const imageUrl = `https://api.popcat.xyz/pikachu?text=${encodeURIComponent(text)}`;
      let response = await fetch(imageUrl);
      let buffer = await response.buffer();

      // Prepare the message caption
      let caption = {
          SI: `*⚡ මෙන්න ඔබේ සැමවිටම Pikachu මැදුර*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
          EN: `*⚡ Here's your surprised Pikachu meme*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      };

      // Send the Pikachu meme image with caption
      await conn.sendMessage(from, { image: buffer, caption: caption[language] }, { quoted: mek });
  } catch (e) {
      console.log(e);
      const errorResponse = {
          SI: "සියලුම දෝෂයක් සිදුවීය: " + e.message,
          EN: "An error occurred: " + e.message
      };
      reply(errorResponse[language]);
  }
});
//======================================================================================================================
cmd({
  pattern: "caution",
  desc: "Creates a caution sign with custom text.",
  react: "⚠️",
  category: "logo",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
  // Define language preference (SI for Sinhala, EN for English)
  const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

  // Check if text input is provided
  if (args.length < 1) {
      const noTextMsg = {
          SI: "*♻ කරුණාකර අවධානයේ ලකුණු සඳහා පෙළ ලබා දෙන්න. උදාහරණය: !caution ඔබේ පියවර පරීක්ෂා කරන්න*",
          EN: "*♻ Please provide text for the caution sign. Example: !caution Watch your step*"
      };
      return reply(noTextMsg[language]);
  }

  const text = args.join(" ");

  try {
      const senderNumber = m.sender;
      const isGroup = m.isGroup || false;


      const errorMsg = {
          SI: "😢 ප්‍රවේශය ප්‍රතික්ෂේප කරයි. ඔබට මෙම විශේෂණය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ආකාරය වෙනස් කරන්න!",
          EN: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!"
      };

      // Fetch the caution sign image from the API
      const imageUrl = `https://api.popcat.xyz/caution?text=${encodeURIComponent(text)}`;
      let response = await fetch(imageUrl);
      let buffer = await response.buffer();

      // Prepare the message caption
      const caption = {
          SI: `⚠️ අවධානය: \n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
          EN: `⚠️ Caution: \n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      };

      // Send the caution sign image with caption
      await conn.sendMessage(from, { image: buffer, caption: caption[language] }, { quoted: mek });
  } catch (e) {
      console.log(e);
      const errorResponse = {
          SI: `ආපසු ගැනීමක් සිදුවුණි: ${e.message}`,
          EN: `An error occurred: ${e.message}`
      };
      reply(errorResponse[language]);
  }
});


//=================================================================
cmd({
  pattern: "drake",
  desc: "Creates a Drake meme with custom text.",
  react: "🎵",
  category: "logo",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
  // Define language preference (SI for Sinhala, EN for English)
  const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

  // Check if both text inputs are provided
  if (args.length < 2) {
      const noTextMsg = {
          SI: "*♻ කරුණාකර Drake meme සඳහා '|' සමඟ වෙන් කරන ලද පෙළ දෙකක් ලබා දෙන්න. උදාහරණය: !drake පෙළ 1 | පෙළ 2*",
          EN: "*♻ Please provide two texts separated by '|' for the Drake meme. Example: !drake Text 1 | Text 2*"
      };
      return reply(noTextMsg[language]);
  }

  const fullText = args.join(" ");
  const [text1, text2] = fullText.split("|").map(text => text.trim());

  if (!text1 || !text2) {
      const missingTextMsg = {
          SI: "*♻ කරුණාකර '|' සමඟ වෙන් කරන ලද පෙළ දෙකක් ලබා දෙන්න.*",
          EN: "*♻ Please provide both texts separated by '|' for the Drake meme.*"
      };
      return reply(missingTextMsg[language]);
  }

  try {
      const senderNumber = m.sender;
      const isGroup = m.isGroup || false;

      const errorMsg = {
          SI: "😢 ප්‍රවේශය ප්‍රතික්ෂේප කරයි. ඔබට මෙම විශේෂණය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ආකාරය වෙනස් කරන්න!",
          EN: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!"
      };

      // Fetch the Drake meme image from the API
      const imageUrl = `https://api.popcat.xyz/drake?text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`;
      let response = await fetch(imageUrl);
      let buffer = await response.buffer();

      // Prepare the message caption
      const caption = {
          SI: `🎵 මෙය ඔබේ Drake meme යි:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
          EN: `🎵 Here's your Drake meme:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      };

      // Send the Drake meme image with caption
      await conn.sendMessage(from, { image: buffer, caption: caption[language] }, { quoted: mek });
  } catch (e) {
      console.log(e);
      const errorResponse = {
          SI: `ආපසු ගැනීමක් සිදුවුණි: ${e.message}`,
          EN: `An error occurred: ${e.message}`
      };
      reply(errorResponse[language]);
  }
});


//======================================================================================================================
cmd({
  pattern: "pooh",
  desc: "Creates a Tuxedo Winnie the Pooh meme with custom text.",
  react: "🐻",
  category: "logo",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
  // Define language preference (SI for Sinhala, EN for English)
  const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

  // Check if both text inputs are provided
  if (args.length < 2) {
      const noTextMsg = {
          SI: "*♻ කරුණාකර Pooh meme සඳහා '|' සමඟ වෙන් කරන ලද පෙළ දෙකක් ලබා දෙන්න. උදාහරණය: !pooh පෙළ 1 | පෙළ 2*",
          EN: "*♻ Please provide two texts separated by '|' for the Pooh meme. Example: !pooh Text 1 | Text 2*"
      };
      return reply(noTextMsg[language]);
  }

  const fullText = args.join(" ");
  const [text1, text2] = fullText.split("|").map(text => text.trim());

  if (!text1 || !text2) {
      const missingTextMsg = {
          SI: "*♻ කරුණාකර '|' සමඟ වෙන් කරන ලද පෙළ දෙකක් ලබා දෙන්න.*",
          EN: "*♻ Please provide both texts separated by '|' for the Pooh meme.*"
      };
      return reply(missingTextMsg[language]);
  }

  try {
      const senderNumber = m.sender;
      const isGroup = m.isGroup || false;
      const errorMsg = {
          SI: "😢 ප්‍රවේශය ප්‍රතික්ෂේප කරයි. ඔබට මෙම විශේෂණය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ආකාරය වෙනස් කරන්න!",
          EN: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!"
      };


      // Fetch the Pooh meme image from the API
      const imageUrl = `https://api.popcat.xyz/pooh?text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`;
      let response = await fetch(imageUrl);
      let buffer = await response.buffer();

      // Prepare the message caption
      const caption = {
          SI: `🐻 මෙය ඔබේ Tuxedo Pooh meme යි:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
          EN: `🐻 Here's your Tuxedo Pooh meme:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      };

      // Send the Pooh meme image with caption
      await conn.sendMessage(from, { image: buffer, caption: caption[language] }, { quoted: mek });
  } catch (e) {
      console.log(e);
      const errorResponse = {
          SI: `ආපසු ගැනීමක් සිදුවුණි: ${e.message}`,
          EN: `An error occurred: ${e.message}`
      };
      reply(errorResponse[language]);
  }
});

//======================================================================================================================
cmd({
  pattern: "sadcat",
  desc: "Fetches a 'Sad Cat' image with custom text.",
  react: "😿",
  category: "logo",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
  // Define language preference (SI for Sinhala, EN for English)
  const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

  // Check if text is provided
  if (!args.join(" ")) {
      const noTextMsg = {
          SI: "*♻ කරුණාකර Sad Cat පින්තූරය සඳහා පෙළ ලබා දෙන්න.*",
          EN: "*♻ Please provide the text for the Sad Cat image.*"
      };
      return reply(noTextMsg[language]);
  }

  const text = args.join(" ");
  try {
      const senderNumber = m.sender;
      const isGroup = m.isGroup || false;
      const errorMsg = {
          SI: "😢 ප්‍රවේශය ප්‍රතික්ෂේප කරයි. ඔබට මෙම විශේෂණය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ආකාරය වෙනස් කරන්න!",
          EN: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!"
      };
      // Fetch the Sad Cat image from the API
      const imageUrl = `https://api.popcat.xyz/sadcat?text=${encodeURIComponent(text)}`;
      let response = await fetch(imageUrl);
      let buffer = await response.buffer();

      // Prepare the message caption
      const caption = {
          SI: `😿 ඔබේ පෙළ සමඟ Sad Cat පින්තූරය මෙහි යුත්කම:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
          EN: `😿 Here is the Sad Cat image with your text:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      };

      // Send the Sad Cat image with caption
      await conn.sendMessage(from, { image: buffer, caption: caption[language] }, { quoted: mek });
  } catch (e) {
      console.log(e);
      const errorResponse = {
          SI: `ආපසු ගැනීමක් සිදුවුණි: ${e.message}`,
          EN: `An error occurred: ${e.message}`
      };
      reply(errorResponse[language]);
  }
});


//======================================================================================================================
cmd({
  pattern: "oogway",
  desc: "Fetches an 'Oogway' image with custom text.",
  react: "🐢",
  category: "logo",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
  // Define language preference (SI for Sinhala, EN for English)
  const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

  // Check if text is provided
  if (!args.join(" ")) {
      const noTextMsg = {
          SI: "*♻ කරුණාකර Oogway පින්තූරය සඳහා පෙළ ලබා දෙන්න.*",
          EN: "*♻ Please provide the text for the Oogway image.*"
      };
      return reply(noTextMsg[language]);
  }

  const text = args.join(" ");
  try {
      const senderNumber = m.sender;
      const isGroup = m.isGroup || false;

      const errorMsg = {
          SI: "😢 ප්‍රවේශය ප්‍රතික්ෂේප කරයි. ඔබට මෙම විශේෂණය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ආකාරය වෙනස් කරන්න!",
          EN: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!"
      };
      // Fetch the Oogway image from the API
      const imageUrl = `https://api.popcat.xyz/oogway?text=${encodeURIComponent(text)}`;
      let response = await fetch(imageUrl);
      let buffer = await response.buffer();

      // Prepare the message caption
      const caption = {
          SI: `🐢 ඔබේ පෙළ සමඟ Oogway පින්තූරය මෙහි යුත්කම:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
          EN: `🐢 Here is the Oogway image with your text:\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      };

      // Send the Oogway image with caption
      await conn.sendMessage(from, { image: buffer, caption: caption[language] }, { quoted: mek });
  } catch (e) {
      console.log(e);
      const errorResponse = {
          SI: `ආපසු ගැනීමක් සිදුවුණි: ${e.message}`,
          EN: `An error occurred: ${e.message}`
      };
      reply(errorResponse[language]);
  }
});
//=======================-USEFUL-COMMANDS-=========================
//=================================================================
cmd({
    pattern: 'newpaste',
    desc: 'Creates a new paste on Pastebin and returns the URL.',
    category: 'useful',
    react: '📄',
    filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
    try {
        const config = await readEnv();
        const PASTEBIN_API_KEY =`uh8QvO6vQJGtIug9WvjdTAPx_ZAFJAxn`
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'
        const pasteContent = args.join(' ');

        if (!pasteContent) {
            const noContentMessage = {
                SI: '📝 කරුණාකර paste එක සඳහා අන්තර්ගතයක් ලබා දෙන්න. උදාහරණයක්: `.newpaste මෙය මගේ නව paste අන්තර්ගතය වේ`',
                EN: '📝 Please provide some content for the paste. Example: `.newpaste This is my new paste content`'
            };
            return reply(noContentMessage[language]);
        }

        const pastebinUrl = 'https://pastebin.com/api/api_post.php';
        const pastebinParams = new URLSearchParams();
        pastebinParams.append('api_dev_key', PASTEBIN_API_KEY);
        pastebinParams.append('api_option', 'paste');
        pastebinParams.append('api_paste_code', pasteContent);
        pastebinParams.append('api_paste_private', 1);  
        pastebinParams.append('api_paste_expire_date', '10M');  
        pastebinParams.append('api_paste_name', 'New Paste');

        const response = await axios.post(pastebinUrl, pastebinParams);
        const pasteUrl = response.data;

        const successMessage = {
            SI: `📄 *ඔබගේ paste එක නිර්මාණය කර ඇත:* ${pasteUrl}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            EN: `📄 *Your paste has been created:* ${pasteUrl}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        };

        if (pasteUrl.startsWith('https://')) {
            reply(successMessage[language]);
        } else {
            const errorMessage = {
                SI: `⚠️ paste එක නිර්මාණය කිරීමට අසාර්ථකයි. දෝෂය: ${pasteUrl}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
                EN: `⚠️ Failed to create paste. Error: ${pasteUrl}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            };
            reply(errorMessage[language]);
        }
    } catch (error) {
        console.error('Error creating Pastebin paste:', error);
        const errorResponse = {
            SI: '⚠️ paste එක නිර්මාණය කිරීමේදී දෝෂයක් සිදු විය.',
            EN: '⚠️ An error occurred while creating the paste.'
        };
        reply(errorResponse[language]);
    }
});
//======================================================================================================================

cmd({
    pattern: 'getpaste',
    desc: 'Fetches the raw content of a Pastebin paste using its URL or key.',
    category: 'useful',
    react: '📄',
    filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
    try {
        const config = await readEnv();
        const PASTEBIN_API_KEY = `uh8QvO6vQJGtIug9WvjdTAPx_ZAFJAxn` 
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'
        const pasteUrl = args[0];
        if (!pasteUrl) {
            const noUrlProvidedMessage = {
                SI: '🔍 කරුණාකර Pastebin URL එකක් හෝ යතුරක් ලබා දෙන්න. උදාහරණයක්: `.getpaste https://pastebin.com/abcdefg`',
                EN: '🔍 Please provide a Pastebin URL or key. Example: `.getpaste https://pastebin.com/abcdefg`'
            };
            return reply(noUrlProvidedMessage[language]);
        }

        const pasteKey = pasteUrl.split('/').pop();
        const rawPastebinUrl = `https://pastebin.com/raw/${pasteKey}`;

        const response = await axios.get(rawPastebinUrl);
        const pasteContent = response.data;

        const pasteContentMessage = {
            SI: `📄 *Pastebin අන්තර්ගතය*:\n\n\`\`\`${pasteContent}\`\`\`\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            EN: `📄 *Pastebin Content*:\n\n\`\`\`${pasteContent}\`\`\`\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        };

        reply(pasteContentMessage[language]);
    } catch (error) {
        console.error('Error retrieving Pastebin content:', error);
        const errorMessage = {
            SI: '⚠️ Pastebin අන්තර්ගතය ලබා ගැනීමේදී දෝෂයක් සිදු විය.',
            EN: '⚠️ An error occurred while retrieving the paste content.'
        };
        reply(errorMessage[language]);
    }
});
//=================================================================
const cybersecurityTips = {
    EN: [
        "Use a unique password for each of your accounts.",
        "Enable two-factor authentication (2FA) whenever possible.",
        "Keep your software and operating systems up to date.",
        "Be cautious when clicking on links in emails or messages.",
        "Use reputable antivirus software and keep it updated.",
        "Avoid using public Wi-Fi networks for sensitive transactions.",
        "Regularly back up your important data.",
        "Use a VPN when connecting to public networks.",
        "Be wary of phishing attempts in emails or messages.",
        "Don't share sensitive information on social media.",
        "Use encrypted messaging apps for sensitive communications.",
        "Regularly check your accounts for any suspicious activity.",
        "Use a password manager to generate and store strong passwords.",
        "Be cautious when downloading attachments from unknown sources.",
        "Enable automatic updates for your software and apps.",
        "Use privacy settings on your social media accounts.",
        "Avoid using easily guessable information in your passwords.",
        "Be careful what you plug into your devices (e.g., unknown USB drives).",
        "Use secure and encrypted cloud services for storing sensitive data.",
        "Educate yourself about current cybersecurity threats and best practices."
    ],
    SI: [
        "ඔබේ ගිණුම් සඳහා නිශ්චිත මුරපදයක් භාවිතා කරන්න.",
        "සමීපකාලයේ අවශ්‍ය නම් කටුසූර සහතිකය (2FA) සක්‍රිය කරන්න.",
        "ඔබේ මෘදුකාංග සහ මෙහෙයුම් පද්ධති යාවත්කාලීනව තබා ගන්න.",
        "ඊමේල් හෝ පණිවිඩ වලට සබැඳි පිළිබඳ වාසනාවන් ඇතුළත් වන විට සැකයක් දරන්න.",
        "හොඳම විරුස නිරාකරණ මෘදුකාංගයක් භාවිතා කරන්න.",
        "සංවේදී ගනුදෙනු සඳහා පොදු Wi-Fi ජාල භාවිතා කිරීමේදී වියෝජන වන්න.",
        "ඔබේ වැදගත් දත්ත පසුබැසීමේදී යාවත්කාලීනව තබා ගන්න.",
        "පොදු ජාල සම්බන්ධ වූ විට VPN එකක් භාවිතා කරන්න.",
        "ඊමේල් හෝ පණිවිඩ වලින් අපූරු ව්‍යාපෘති සඳහා අවධානයෙන් ඉන්න.",
        "සමාජ මාධ්‍යවල සංවේදී තොරතුරු බෙදා ගැනීමට එන්න.",
        "සංවේදී සන්නිවේදන සඳහා සංකේතිත පණිවිඩ යෙදුම් භාවිතා කරන්න.",
        "අසාමාන්‍ය ක්‍රියාවන් සඳහා ඔබේ ගිණුම් පරීක්ෂා කරන්න.",
        "ඉහල මුරපද ප්‍රධානකරුවන් නිර්මාණය කිරීමට සහ රැඳවීමට මුරපද කළමනාකරු භාවිතා කරන්න.",
        "නොදන්නා සම්පත් වලින් සහිත පිටු අයැදුම් ප්‍රවේශය කරන්නේ නැත.",
        "ඔබේ මෘදුකාංග සහ යෙදුම් සඳහා ස්වයංක්‍රීය යාවත්කාලීන කිරීම සක්‍රිය කරන්න.",
        "ඔබේ සමාජ මාධ්‍ය ගිණුම් සඳහා පෞද්ගලිකත්වය සැකසුම් භාවිතා කරන්න.",
        "මුරපද වලදී පහසුවෙන් සොයා ගත හැකි තොරතුරු භාවිතා කිරීමෙන් වළකින.",
        "ඔබේ උපකරණ වලට දාන්නා බවට අවධානයක් දියත් කරන්න (උදා: නොදන්නා USB රථ යාත්‍රා).",
        "සංවේදී දත්ත ගබඩා කිරීමට ආරක්ෂිත සහ සංකේතිත කලාප සේවා භාවිතා කරන්න.",
        "වත්මන් කාණ්ඩාංක ආරක්ෂිත බලපෑම් පිළිබඳ වාසනාවන් සොයා බලන්න."
    ]
};

cmd({
    pattern: "cybertips",
    alias: ["hackertips"],
    desc: "Get random cybersecurity tips.",
    category: "useful",
    react: "🛡️",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Get the language preference
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Multi-language messages
        const accessDeniedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
        const accessDeniedGeneral = lang === 'SI' ? "*😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!*" : "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*";
        const tipsHeader = lang === 'SI' ? "🛡️ *සයිබර් ආරක්ෂිත උපදෙස්* 🛡️" : "🛡️ *Cybersecurity Tips* 🛡️";
        const tipsIntro = lang === 'SI' ? "> අන්තර්ජාලයේ ආරක්ෂිත වීම සඳහා මෙම වැදගත් උපදෙස් අනුගමනය කරන්න:" : "> Stay safe online with these important tips:";
        const tipsFooter = lang === 'SI' ? "> 🔐 සෙවණැති: ඔබේ අන්තර්ජාල ආරක්ෂාව ඔබගේ අත් හිමිකම් යටතේය!" : "> 🔐 Remember: Your online security is in your hands!";
        const repeatTips = lang === 'SI' ? "> තවත් උපදෙස් ගන්න? නැවත .cybertips විධානය භාවිතා කරන්න!" : "> Want more tips? Just use the .cybertips command again!";


        // Shuffle the tips array for the selected language
        const shuffled = cybersecurityTips[lang].sort(() => 0.5 - Math.random());

        // Select 5 random tips
        const selectedTips = shuffled.slice(0, 5);

        const tipsMessage = `
${tipsHeader}

${tipsIntro}

${selectedTips.map((tip, index) => `${index + 1}. ${tip}`).join('\n\n')}

${tipsFooter}

${repeatTips}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
        `.trim();

        await conn.sendMessage(from, { text: tipsMessage }, { quoted: mek });

    } catch (e) {
        console.log(e);
        reply(`🚫 An error occurred: ${e.message}`);
    }
});
//=================================================================
cmd({
    pattern: "gpass",
    alias: ["generatepassword"],
    desc: "Generate a strong password.",
    category: "useful",
    react: "🔐",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Get the language preference
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Multi-language messages
        const accessDeniedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
        const accessDeniedGeneral = lang === 'SI' ? "*😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!*" : "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*";
        const invalidLengthMsg = lang === 'SI' ? "*♻ කරුණාකර මුරපදය සඳහා සත්‍ය දිගක් ලබා දෙන්න (අවම වශයෙන් අක්ෂර 8ක්).*" : "*♻ Please provide a valid length for the password (minimum 8 characters).*";
        const passwordMessageHeader = lang === 'SI' ? "🔐 *ඔබේ ශක්තිමත් මුරපදය* 🔐\n\n" : "🔐 *Your Strong Password* 🔐\n\n";
        const generateAnotherPrompt = lang === 'SI' ? "1 | *තවත් එකක් නිර්මාණය කරන්න*" : "1 | *Generate Another one*";
        const newPasswordHeader = lang === 'SI' ? "🔐 *මෙන්න ඔබගේ නව මුරපදය:* \n\n" : "🔐 *Here's your new password:* \n\n";


        const length = args[0] ? parseInt(args[0]) : 12; // Default length is 12 if not provided
        if (isNaN(length) || length < 8) {
            return reply(invalidLengthMsg);
        }

        const generatePassword = (len) => {
            const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+[]{}|;:,.<>?';
            let password = '';
            for (let i = 0; i < len; i++) {
                const randomIndex = crypto.randomInt(0, charset.length);
                password += charset[randomIndex];
            }
            return password;
        };

        const password = generatePassword(length);
        const message = `${passwordMessageHeader}${generateAnotherPrompt}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        // Send initial notification message
        const sentMessage = await conn.sendMessage(from, { text: message }, { quoted: mek });

        // Send the password in a separate message
        await conn.sendMessage(from, { text: password }, { quoted: mek });

        // Store the sent message for context


        // Wait for a reply
        conn.ev.on("messages.upsert", async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            // Check if the reply matches the "Generate Another one" prompt
            if (messageContext && messageContext.stanzaId === sentMessage.key.id && userReply === "1") {
                const newPassword = generatePassword(length);
                await conn.sendMessage(from, { text: `${newPasswordHeader}${newPassword}` }, { quoted: mek });
            }
        });

    } catch (e) {
        console.error(e);
        const errorMsg = lang === 'SI' ? `❌ මුරපදය නිර්මාණය කිරීමට දෝෂයක් ඇති වී ඇත: ${e.message}` : `❌ Error generating password: ${e.message}`;
        reply(errorMsg);
    }
});
//================================================================
cmd({
    pattern: "tempmail",
    desc: "Generate a temporary email address.",
    category: "useful",
    react: "✉️",
    filename: __filename
}, async (conn, mek, m, { from, quoted, isCmd, command, isGroup, sender, senderNumber, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Get the language preference
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Multi-language messages
        const accessDeniedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
        const accessDeniedGeneral = lang === 'SI' ? "*😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!*" : "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*";
        const emailGenerationError = lang === 'SI' ? "❌ දෝෂයක්: කාලික ඊ-තැපැල් එකක් සාදන්න නොහැක. කරුණාකර පසුව නැවත උත්සාහ කරන්න." : "Error: Unable to generate a temporary email. Please try again later.";


        // API URL to generate a random temporary email
        const url = `https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1`;

        // Fetch the temporary email from 1secmail API
        const response = await axios.get(url);
        const data = response.data;

        // Check if an email was successfully generated
        if (!data || data.length === 0) {
            return reply(emailGenerationError);
        }

        const tempEmail = data[0]; // Extract the first generated email
         const tempEmailMessage = lang === 'SI' ? `✉️ *කාලික ඊ-තැපැල් සාදන ලදි*\n\n📧 ඊ-තැපැල්: ${tempEmail}` : `✉️ *Temporary Email Generated*\n\n📧 Email: ${tempEmail}`;
        // Send the generated temporary email to the user
        reply(tempEmailMessage);

    } catch (e) {
        console.error(e);
        const errorMsg = lang === 'SI' ? `❌ දෝෂයකි: ${e.message}` : `Error: ${e.message}`;
        reply(errorMsg);
    }
});
//======================================================================================================================
cmd({
    pattern: "checkmail",
    desc: "Check inbox of a temporary email address.",
    category: "useful",
    react: "📬",
    filename: __filename
}, async (conn, mek, m, { from, quoted, isCmd, command, args, q, isGroup, sender, senderNumber, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Get the language preference
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
         const tempEmail = q || ''; // The email should be provided as an argument (e.g., .checkmail user@example.com)
        // Multi-language messages
        const accessDeniedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
        const accessDeniedGeneral = lang === 'SI' ? "*😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!*" : "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*";
        const noEmailMsg = lang === 'SI' ? "*♻ කරුණාකර පරීක්ෂා කිරීමට කාලික ඊ-තැපැල් ලිපිනයක් ලබා දෙන්න. උදා: `.checkmail user@example.com`*" : "*♻ Please provide a temporary email address to check. Example: `.checkmail user@example.com`*";
        const invalidEmailFormat = lang === 'SI' ? "ඊ-තැපැල් ආකෘතිය වලංගු නොවේ. කරුණාකර වාසනාවන් භාවිතා කරන්න." : "Invalid email format. Please provide a valid temporary email address.";
        const noMessagesFound = lang === 'SI' ? `📬 ${tempEmail} සඳහා කිසිදු පණිවිඩයක් නැත.` : `📬 No messages found for the email: ${tempEmail}`;
        const inboxHeader = lang === 'SI' ? `📬 *${tempEmail} සඳහා ගබඩා:*` : `📬 *Inbox for ${tempEmail}:*`;
        const messageDetails = (i, from, subject, date) => {
            return lang === 'SI' 
                ? `📩 *පණිවිඩය ${i + 1}*\n📧 *අවසරය*: ${from}\n📜 *මාතෘකාව*: ${subject}\n🕒 *දිනය*: ${date}\n💬 \`.readmail ${id}\` භාවිතා කර ඉංගිතය පියවර කරන්න.\n\n`
                : `📩 *Message ${i + 1}*\n📧 *From*: ${from}\n📜 *Subject*: ${subject}\n🕒 *Date*: ${date}\n💬 Use \`.readmail ${id}\` to read the full message.\n\n`;
        };

        // Validate email input

        if (!tempEmail) {
            return reply(noEmailMsg);
        }

        // Split the email into login and domain parts
        const [login, domain] = tempEmail.split('@');
        if (!login || !domain) {
            return reply(invalidEmailFormat);
        }

        // API URL to check messages for the temporary email
        const url = `https://www.1secmail.com/api/v1/?action=getMessages&login=${login}&domain=${domain}`;

        // Fetch the messages from 1secmail API
        const response = await axios.get(url);
        const messages = response.data;

        // Check if there are any messages
        if (!messages || messages.length === 0) {
            return reply(noMessagesFound);
        }

        // Construct the message list to send
        let inboxInfo = `${inboxHeader}\n\n`;
        for (let i = 0; i < messages.length; i++) {
            const { id, from, subject, date } = messages[i];
            inboxInfo += messageDetails(i, from, subject, date);
        }

        // Send the inbox information
        await conn.sendMessage(from, { 
            text: inboxInfo,
            footer: '> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ'
        }, { quoted: mek });

    } catch (e) {
        console.error(e);
        const errorMsg = lang === 'SI' ? `❌ දෝෂයකි: ${e.message}` : `Error: ${e.message}`;
        reply(errorMsg);
    }
});
//================================================================
cmd({
    pattern: "weather",
    alias: ["weatherinfo"],
    desc: "🌤 Get weather information for a location",
    react: "🌤",
    category: "useful",
    filename: __filename
},
async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;


        if (!q) {
            return reply(config.LANGUAGE === 'SI' 
              ? "❗ කරුණාකර නගරයේ නම ලබාදෙන්න. භාවිතය: .weather [නගරය]" 
              : "❗ Please provide a city name. Usage: .weather [city name]");
        }

        const apiKey = config.OPENWEATHER_API_KEY; // Assuming you've added this to your config file

        const city = encodeURIComponent(q);
        const url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=2d61a72574c11c4f36173b627f8cb177&units=metric`;
        const response = await axios.get(url);
        const data = response.data;

        const weatherSI = `
🌍 *${data.name}, ${data.sys.country} සඳහා කාලගුණ තොරතුරු* 🌍
[ *BHASHI-MD සෙවීම් එන්ජිම* ]

🌡️ *උෂ්ණත්වය*: ${data.main.temp}°C
🤷‍♀️ *විදිනය*: ${data.main.feels_like}°C
🚨 *අවම උෂ්ණත්වය*: ${data.main.temp_min}°C
🌝 *උච්චතම උෂ්ණත්වය*: ${data.main.temp_max}°C
💧 *උෂ්ණතාවය*: ${data.main.humidity}%
☁️ *කාලගුණය*: ${data.weather[0].main}
🌫️ *විස්තරය*: ${data.weather[0].description}
💨 *සුළගේ වේගය*: ${data.wind.speed} මීටර්/තත්.
🔽 *පීඩනය*: ${data.main.pressure} hPa

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
        `.trim();

        const weatherEN = `
🌍 *Weather Information for ${data.name}, ${data.sys.country}* 🌍
[ *BHASHI-MD SEARCH ENGINE* ]

🌡️ *Temperature*: ${data.main.temp}°C
🤷‍♀️ *Feels Like*: ${data.main.feels_like}°C
🚨 *Min Temp*: ${data.main.temp_min}°C
🌝 *Max Temp*: ${data.main.temp_max}°C
💧 *Humidity*: ${data.main.humidity}%
☁️ *Weather*: ${data.weather[0].main}
🌫️ *Description*: ${data.weather[0].description}
💨 *Wind Speed*: ${data.wind.speed} m/s
🔽 *Pressure*: ${data.main.pressure} hPa

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
        `.trim();

        return reply(config.LANGUAGE === 'SI' ? weatherSI : weatherEN);
    } catch (e) {
        console.log(e);
        if (e.response && e.response.status === 404) {
            return reply(config.LANGUAGE === 'SI' 
              ? "🚫 නගරය සොයාගත නොහැක. කරුණාකර අකුරු පරීක්ෂා කර නැවත උත්සාහ කරන්න." 
              : "🚫 City not found. Please check the spelling and try again.");
        }
        return reply(config.LANGUAGE === 'SI' 
          ? "⚠️ කාලගුණ තොරතුරු ලබා ගැනීමේදී දෝෂයක් ඇති විය. කරුණාකර පසුව නැවත උත්සාහ කරන්න." 
          : "⚠️ An error occurred while fetching the weather information. Please try again later.");
    }
});
//=================================================================
cmd({
    pattern: "headers",
    desc: "Fetch HTTP headers from a website",
    category: "useful",
    react: "📑",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'

        if (args.length === 0) {
            const noUrlMessage = {
                SI: "❌ කරුණාකර URL එකක් ලබා දෙන්න. උදාහරණයක්: `.headers https://example.com`",
                EN: "❌ Please provide a URL. Example: `.headers https://example.com`"
            };
            return reply(noUrlMessage[language]);
        }

        const url = args[0];
        const response = await axios.head(url);
        const headers = response.headers;

        const headerInfo = {
            SI: `
*📑 ${url} සඳහා HTTP Headers 📑*
> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ

${Object.entries(headers).map(([key, value]) => `• ${key}: ${value}`).join('\n')}
            `.trim(),
            EN: `
*📑 HTTP Headers for ${url} 📑*
> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ

${Object.entries(headers).map(([key, value]) => `• ${key}: ${value}`).join('\n')}
            `.trim()
        };

        reply(headerInfo[language]);
    } catch (e) {
        console.log(e);
        const errorMessage = {
            SI: `🚫 දෝෂයක් සිදු විය: ${e.message}`,
            EN: `🚫 An error occurred: ${e.message}`
        };
        reply(errorMessage[language]);
    }
});
//=================================================================
cmd({
    pattern: "whois",
    desc: "Perform WHOIS lookup on a domain or IP",
    category: "useful",
    react: "📄",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, reply }) => {
    const config = await readEnv();
    // Define multilingual messages
    const messages = {
        noTarget: {
            SI: "කරුණාකර WHOIS සොයා ගැනීම සඳහා ඕනෑමโดමයින් හෝ IP එකක් ලබා දෙන්න.",
            EN: "Please provide a domain or IP for the WHOIS lookup."
        },
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        lookupFailed: {
            SI: "❌ WHOIS සොයා ගැනීම අසාර්ථක විය: ",
            EN: "❌ WHOIS lookup failed: "
        },
        footer: {
            SI: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            EN: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        },
        error: {
            SI: "🚫 දෝෂයක් ඇති විය: ",
            EN: "🚫 An error occurred: "
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys

        const target = args[0];
        if (!target) return reply(messages.noTarget[lang]);

        whois.lookup(target, (err, data) => {
            if (err) {
                return reply(`${messages.lookupFailed[lang]}${err.message}`);
            }
            reply(`*📄 WHOIS Lookup for ${target} 📄*\n\n${data}\n\n${messages.footer[lang]}`);
        });
    } catch (e) {
        console.log(e);
        reply(`${messages.error[lang]}${e.message}`);
    }
});
//================================================================
cmd({
    pattern: "ipgeo",
    desc: "Get geolocation information for an IP address",
    category: "useful",
    react: "🌐",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'

        // Check if an IP address was provided
        if (args.length === 0) {
            const noIpMessage = {
                SI: "❌ කරුණාකර IP ලිපිනයක් ලබා දෙන්න. උදාහරණයක්: `.ipgeo 104.18.35.46`",
                EN: "❌ Please provide an IP address. Example: `.ipgeo 104.18.35.46`"
            };
            return reply(noIpMessage[language]);
        }

        const ipAddress = args[0];

        // Perform geolocation lookup using the provided API
        const apiUrl = `${vishwa2}/misc/iplookup`;
        const response = await axios.get(apiUrl, {
            params: {
                ip: ipAddress,
                apikey: `key1` // Use your actual API key here
            }
        });

        const data = response.data;

        // Check if the API call was successful
        if (data.status === "success") {
            const { ip, city, region, country, loc, org, postal, timezone } = data.data;

            const resultMessage = {
                SI: `
*📍 IP ලිපිනයේ තොරතුරු*

> 🔗 IP ලිපිනය: *${ip}*
> 🌆 නගරය: *${city}*
> 🗺️ ප්‍රදේශය: *${region}*
> 🌍 රාජ්‍යය: *${country}*
> 📡 ස්ථානය: *${loc}*
> 🏢 සංවිධානය: *${org}*
> 📮 තැපැල් කේතය: *${postal}*
> ⏰ වේලාව: *${timezone}*`,
                EN: `
*📍 IP Address Information*

> 🔗 IP Address: *${ip}*
> 🌆 City: *${city}*
> 🗺️ Region: *${region}*
> 🌍 Country: *${country}*
> 📡 Location: *${loc}*
> 🏢 Organization: *${org}*
> 📮 Postal Code: *${postal}*
> ⏰ Timezone: *${timezone}*`
            };

            await conn.sendMessage(from, { text: resultMessage[language] }, { quoted: mek });
        } else {
            reply(`❌ IP Lookup failed: ${data.message}`);
        }
    } catch (e) {
        console.log(e);
        const errorMessage = {
            SI: `🚫 දෝෂයක් සිදු විය: ${e.message}`,
            EN: `🚫 An error occurred: ${e.message}`
        };
        reply(errorMessage[language]);
    }
});
//=================================================================
cmd({
    pattern: "userinfo",
    desc: "Get detailed information about the user and update privacy settings.",
    category: "useful",
    react: "🧑‍💻",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        const config = await readEnv();
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE || 'EN';

        // Determine the user to fetch info for (quoted user or sender)
        const targetUser = m.quoted ? m.quoted.sender : m.sender;

        const targetJid = targetUser; 
        const phoneNumber = targetJid.split('@')[0];
        const userName = m.pushName || 'Not Available';

        // Fetch privacy settings for the target user
        const privacySettings = await conn.fetchPrivacySettings(true, targetJid);
        console.log("Privacy settings for target user:", privacySettings);

        // Fetch user profile picture only if allowed by privacy settings
        let userProfilePic = 'Not Available.';
        if (privacySettings.profile === 'all' || privacySettings.profile === 'contacts') {
            try {
                userProfilePic = await conn.getProfilePicture(targetJid) || 'Not Available.';
            } catch (error) {
                console.error("Error retrieving profile picture:", error);
                userProfilePic = 'Error retrieving picture.';
            }
        }

        // Handle last seen visibility
        const lastSeen = privacySettings.last === 'all' ? m.lastSeen || 'Not Available' : 'Hidden';

        let isAdmin = 'N/A';
        let joinDate = 'N/A'; 

        if (isGroup) {
            const groupMetadata = await conn.groupMetadata(from).catch(() => null);
            if (groupMetadata) {
                const participant = groupMetadata.participants.find(participant => participant.jid === targetJid);
                isAdmin = participant && participant.isAdmin ? 'Yes' : 'No';
                joinDate = participant ? participant.created : 'N/A'; 
            }
        }

        const defaultDisappearingMode = privacySettings.defaultDisappearingMode !== undefined 
            ? privacySettings.defaultDisappearingMode 
            : 'Not Set';

        // Prepare user information with enhanced formatting
        const userInfo = {
            SI: `👤 *පරිශීලක විස්තර*:\n\n📞 *දුරකථන අංකය*: ${phoneNumber}\n👤 *පෙන්වන නාමය*: ${userName}\n👑 *නායකයෙකු*: ${isAdmin}\n📷 *Profile Picture*: ${userProfilePic}\n🕒 *අවසන් දැක්ම*: ${lastSeen}\n📅 *එක්වූ දිනය*: ${joinDate}\n\n🔒 *පෞද්ගලිකත්වය යාවත්කාලීන කිරීමට විකල්ප*:\n\n1️⃣ *Last Seen Privacy*: ${privacySettings.last}\n2️⃣ *Online Privacy*: ${privacySettings.online}\n3️⃣ *Profile Picture Privacy*: ${privacySettings.profile}\n4️⃣ *Status Privacy*: ${privacySettings.status}\n5️⃣ *Read Receipts Privacy*: ${privacySettings.readreceipts}\n6️⃣ *Groups Add Privacy*: ${privacySettings.groupadd}\n7️⃣ *Default Disappearing Mode*: ${defaultDisappearingMode} seconds\n\n🔧 *යාවත්කාලීන කිරීමට අවශ්‍ය කුමක්ද?*`,
            EN: `👤 *User Information*:\n\n📞 *Phone Number*: ${phoneNumber}\n👤 *Display Name*: ${userName}\n👑 *Admin*: ${isAdmin}\n📷 *Profile Picture*: ${userProfilePic}\n🕒 *Last Seen*: ${lastSeen}\n📅 *Join Date*: ${joinDate}\n\n🔒 *Privacy Settings Options*:\n\n1️⃣ *Last Seen Privacy*: ${privacySettings.last}\n2️⃣ *Online Privacy*: ${privacySettings.online}\n3️⃣ *Profile Picture Privacy*: ${privacySettings.profile}\n4️⃣ *Status Privacy*: ${privacySettings.status}\n5️⃣ *Read Receipts Privacy*: ${privacySettings.readreceipts}\n6️⃣ *Groups Add Privacy*: ${privacySettings.groupadd}\n7️⃣ *Default Disappearing Mode*: ${defaultDisappearingMode} seconds\n\n🔧 *What would you like to update?*`
        };

        await conn.sendMessage(from, { 
            text: userInfo[language],
            footer: `> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`
        });

    } catch (e) {
        console.error(e);
        const errorMessage = {
            SI: `🚫 දෝෂයක් සිදු විය: ${e.message}`,
            EN: `🚫 An error occurred: ${e.message}`
        };
        reply(errorMessage[language]);
    }
});
//=================================================================
cmd({
  pattern: "checkpw",
  alias: ["checkpassword"],
  desc: "Check password strength and provide improvement suggestions.",
  category: "useful",
  react: "🔒",
  filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
  try {
      const config = await readEnv();
    const senderNumber = m.sender;
    const isGroup = m.isGroup || false;
    const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'


    if (!q) {
      const noPasswordMessage = {
        SI: "❌ කරුණාකර පරීක්ෂා කිරීමට මුරපදයක් ලබා දෙන්න. භාවිතය: `.checkpw YourPasswordHere`",
        EN: "❌ Please provide a password to check. Usage: `.checkpw YourPasswordHere`"
      };
      return reply(noPasswordMessage[language]);
    }

    // Call the password strength API
    const response = await axios.get(`${vishwa2}/misc/checkpass`, {
      params: {
        password: q,
        apikey: `key1`// Ensure to use your actual API key here
      }
    });

    const data = response.data;

    // Check if the API call was successful
    if (data.status === "success") {
      const strength = data.data.strength;
      const crackTime = data.data.crackTime;
      const suggestions = data.data.suggestions.join('\n');
      const tips = data.data.tips.join('\n');

      const resultMessage = {
        SI: `
🔒 *මුරපද බලය පරීක්ෂාව* 🔒

🚨 _බලය:_ ${strength}
👾 _උදාහරණ අත්හැරීමේ කාලය:_ *${crackTime}*

🚀 _සुधාරන යෝජනා:_
${suggestions}

🔑 *සාරාංශ උපදෙස්:*
${tips}

*⚠️ සටහන: ඔබේ සැබෑ මුරපද nunca ෙනෙලා එපා. මෙම මෙවලම අධ්‍යාපනික අරමුණු සඳහා පමණක් වේ.*

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
        EN: `
🔒 *Password Strength Check* 🔒

🚨 _Strength:_ ${strength}
👾 _Estimated crack time:_ *${crackTime}*

🚀 _Improvement Suggestions:_
${suggestions}

🔑 *General Tips:*
${tips}

*⚠️ Note: Never share your real passwords. This tool is for educational purposes only.*

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      };

      await conn.sendMessage(from, { text: resultMessage[language] }, { quoted: mek });
    } else {
      const errorMessage = {
        SI: `🚫 දෝෂයක්: ${data.message}`,
        EN: `🚫 Error: ${data.message}`
      };
      reply(errorMessage[language]);
    }
  } catch (e) {
    console.log(e);
    const errorMessage = {
      SI: `🚫 දෝෂයක් සිදු විය: ${e.message}`,
      EN: `🚫 An error occurred: ${e.message}`
    };
    reply(errorMessage[language]);
  }
});
//=================================================================
cmd({
  pattern: "countdown",
  desc: "Set a countdown timer with a custom message.",
  category: "useful",
  react: "⏲️",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
  try {
      const config = await readEnv();
    const senderNumber = m.sender;
    const isGroup = m.isGroup || false;
    const lang = config.LANGUAGE || 'EN'; // Get the language preference

    // Multi-language messages
    const accessDeniedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
    const accessDeniedGeneral = lang === 'SI' ? "*😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!*" : "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*";
    const usageText = lang === 'SI' ? "❌ **භාවිතය:** `!countdown [දෙසකීතයක්] [පණිවිඩය]`\nඋදාහරණය: `!countdown 10 වාසියක් ගන්න!`" : "❌ **Usage:** `!countdown [time in seconds] [message]`\nExample: `!countdown 10 Take a break!`";
    const invalidSecondsText = lang === 'SI' ? "❌ **දෝෂයක්:** කරුණාකර 0 ට වැඩි සත්‍ය කාලයක් ලබා දෙන්න." : "❌ **Error:** Please provide a valid number of seconds greater than 0.";

    if (args.length < 2) {
        return reply(usageText);
    }

    const seconds = parseInt(args[0]);
    const message = args.slice(1).join(' ');

    if (isNaN(seconds) || seconds <= 0) {
        return reply(invalidSecondsText);
    }

    const countdownSetText = lang === 'SI' 
      ? `🕰️ *ගණනාව ස්ථාපිත කර ඇත!*\n⏳ *කාලය:* ${seconds} සෙක්කන්ඩ්\n📝 *පණිවිඩය:* ${message}\n\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` 
      : `🕰️ *Countdown Set!*\n⏳ *Time:* ${seconds} seconds\n📝 *Message:* ${message}\n\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

    reply(countdownSetText);

    // Move the definition of timeUpText here, after initializing message
    const timeUpText = lang === 'SI' 
      ? `🚨 *කාලය ඉක්මවා ගියා!* \n_${message}_\n` 
      : `🚨 *Time's Up!*\n_${message}_\n`;

    setTimeout(() => {
        conn.sendMessage(from, { text: timeUpText });
    }, seconds * 1000);

  } catch (e) {
    console.error(e);
    reply("❌ **Error:** An unexpected error occurred while setting the countdown timer.");
  }
});
//=================================================================
cmd({
    pattern: "dnslook",
    alias: ["dns", "dnslookup"],
    desc: "Perform DNS lookup on a domain",
    category: "useful",
    react: "🌐",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'

        // Check if a domain was provided
        if (args.length === 0) {
            const noDomainMessage = {
                SI: "❌ කරුණාකර ලිපිනයක් ලබා දෙන්න. උදාහරණයක්: `.dnslook example.com`",
                EN: "❌ Please provide a domain to lookup. Example: `.dnslook example.com`"
            };
            return reply(noDomainMessage[language]);
        }

        const domain = args[0];

        // Perform DNS lookup using the API
        const response = await axios.get(`${vishwa2}/misc/dnslookup`, {
            params: {
                domain: domain,
                apikey: `key1` // Ensure to use your actual API key here
            }
        });

        const data = response.data;

        // Log the API response to debug
        console.log(data); // Check the structure of the API response

        // Check if the API call was successful
        if (data.status === "success" && data.data.status === "success") {
            // Access domain and address properly
            const domainName = data.data.data.domain; // Adjusted to access the correct path
            const address = data.data.data.address; // Adjusted to access the correct path

            const resultMessage = {
                SI: `
🌐 *${domainName}* සඳහා DNS Lookup

🔗 IP ලිපිනය: *${address}*

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
                EN: `
🌐 DNS Lookup for *${domainName}*

🔗 IP Address: *${address}*

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            };
            await conn.sendMessage(from, { text: resultMessage[language] }, { quoted: mek });
        } else {
            const lookupFailedMessage = {
                SI: `❌ DNS Lookup අසාර්ථකයි: ${data.message}`,
                EN: `❌ DNS Lookup failed: ${data.message}`
            };
            reply(lookupFailedMessage[language]);
        }
    } catch (e) {
        console.log(e);
        const errorMessage = {
            SI: `🚫 දෝෂයක් සිදු විය: ${e.message}`,
            EN: `🚫 An error occurred: ${e.message}`
        };
        reply(errorMessage[language]);
    }
});
//=================================================================
cmd({
    pattern: "jid",
    desc: "Get the JID of the chat.",
    category: "useful",
    react: "🔍",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'
        // Retrieve the JID of the chat
        const chatJid = from;

        // Construct the JID response message
        const jidResponse = {
            SI: `📍 සංවාදයේ JID: ${chatJid}`,
            EN: `📍 Chat JID: ${chatJid}`
        };

        // Send the JID response
        await conn.sendMessage(from, { 
            text: jidResponse[language],
            footer: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        });

    } catch (e) {
        console.error(e);
        const errorMessage = {
            SI: `🚫 දෝෂයක් සිදු විය: ${e.message}`,
            EN: `🚫 An error occurred: ${e.message}`
        };
        reply(errorMessage[language]);
    }
});
//=================================================================
cmd({
    pattern: "send",
    desc: "Send a message to multiple JIDs",
    category: "useful",
    react: "📨",
    filename: __filename
}, async (conn, mek, m, { args, reply }) => {
    try {
        // Extract JIDs and message from arguments
        if (args.length < 2) {
            return reply("Please specify JIDs and a message in the format: `.send jid1,jid2,... message`.");
        }

        // Split JIDs and extract message
        const jids = args[0].split(",").map(j => j.trim() + "@s.whatsapp.net");
        const message = args.slice(1).join(" ").trim();

        if (jids.length === 0 || !message) {
            return reply("Please provide valid JIDs and a message.");
        }

        // Send the message to each JID
        for (let jid of jids) {
            await conn.sendMessage(jid, { text: message });
        }

        // React to the original command message to confirm success
        await conn.sendMessage(m.key.remoteJid, { react: { text: "📨", key: mek.key } });

    } catch (e) {
        console.error("Error sending message:", e);
        reply("An error occurred while sending the message.");
    }
});
//=================================================================

cmd({
    pattern: "solve",
    alias: ["mathsolve"],
    desc: "🔢 Solve mathematical expressions.",
    react: "🔢",
    category: "useful",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    const config = await readEnv();
    const langConfig = {
        EN: {
            accessDenied: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!",
            blacklisted: "🚫 You are blacklisted. Access denied.",
            invalidAmount: "Please provide a valid amount.",
            conversionUsage: "Usage: .convert <amount> <from_currency> <to_currency>",
            conversionRateNotFound: (currency) => `Conversion rate for ${currency} not found.`,
            conversionInfo: (amount, fromCurrency, convertedAmount, toCurrency, rate) =>
                `💸_*Currency Conversion*_💸\n\n💵 *Amount*: ${amount} ${fromCurrency}\n🔄 *Converted Amount*: ${convertedAmount} ${toCurrency}\n📈 *Exchange Rate*: 1 ${fromCurrency} = ${rate} ${toCurrency}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            mathExpression: (expression) => `📊 *Math Expression:* ${expression}`,
            mathResult: (result) => `✅ *Result:* ${result}`,
            invalidMathExpression: "❌ Invalid mathematical expression. Please check your input and try again.",
            errorFetchingData: (message) => `Error fetching data: ${message}`,
        },
        SI: {
            accessDenied: "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!",
            blacklisted: "🚫 ඔබට මාරු කර ඇත. ප්‍රවේශය ප්‍රහාර කලා.",
            invalidAmount: "කරුණාකර වලංගු මුදලක් ලබා දෙන්න.",
            conversionUsage: "භාවිතය: .convert <මුදල> <from_currency> <to_currency>",
            conversionRateNotFound: (currency) => `${currency} සඳහා මාරු අනුපාතය සොයා ගත නොහැක.`,
            conversionInfo: (amount, fromCurrency, convertedAmount, toCurrency, rate) =>
                `💸_*මුදල් මාරු*_💸\n\n💵 *මුදල*: ${amount} ${fromCurrency}\n🔄 *මාරු කරන ලද මුදල*: ${convertedAmount} ${toCurrency}\n📈 *මාරු අනුපාතය*: 1 ${fromCurrency} = ${rate} ${toCurrency}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            mathExpression: (expression) => `📊 *ගණිත ප්‍රකාශය:* ${expression}`,
            mathResult: (result) => `✅ *ප්‍රතිඵල:* ${result}`,
            invalidMathExpression: "❌ වැරදි ගණිත ප්‍රකාශය. කරුණාකර ඔබගේ ඇතුලත්කිරීම් පරීක්ෂා කරන්න සහ නැවත උත්සාහ කරන්න.",
            errorFetchingData: (message) => `දත්ත ලබා ගැනීමට ඇති දෝෂය: ${message}`,
        },
    };

    const lang = config.LANGUAGE || 'EN'; // Set language preference
    const language = langConfig[lang];

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;



        // Evaluate the mathematical expression
        let result = math.evaluate(q); // Make sure `q` contains a valid expression

        // Prepare response with the solved result
        const response = `
${language.mathExpression(q)}
${language.mathResult(result)}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
        `;

        // Send the result to the user
        return conn.sendMessage(from, { text: response }, { quoted: mek });

    } catch (e) {
        console.error(e);

        // Generic error message
        return reply(language.errorFetchingData(e.message));
    }
});
//==================================================================
cmd({
    pattern: "apod",
    desc: "Get NASA's Astronomy Picture of the Day",
    category: "useful",
    react: "🌠",
    filename: __filename
}, async (conn, mek, m, { reply }) => {
    const config = await readEnv();
    // Define language preference (SI for Sinhala, EN for English)
    const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

    try {
        const response = await fetch('https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY');
        const data = await response.json();

        const replyText = {
            SI: `🌠 *${data.title}*\n\n${data.explanation}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            EN: `🌠 *${data.title}*\n\n${data.explanation}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        };

        await conn.sendMessage(m.chat, { image: { url: data.url }, caption: replyText[language] });
    } catch (error) {
        console.error(error);
        const errorMsg = {
            SI: "⚠️ අන්තර්ගතයේ දෝෂයක් සිදුවිණි.",
            EN: "⚠️ An error occurred while fetching the Astronomy Picture of the Day."
        };
        await reply(errorMsg[language]);
    }
});
//====================================================================
cmd({
    pattern: "wa",
    desc: "Generate a WhatsApp link with a custom message for the quoted user.",
    category: "useful",
    react: "🔗",
    filename: __filename
}, async (conn, mek, m, { from, reply, quoted, text }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'

        // Check if a message was quoted
        if (!quoted) {
            const noQuoteMessage = {
                SI: "❌ කරුණාකර රුකන පණිවුඩයක් පිළිතුරු කරන්න.",
                EN: "❌ Please reply to a message to generate a WhatsApp link for that user."
            };
            return reply(noQuoteMessage[language]);
        }

        // Default message if none provided
        const defaultMessage = {
            SI: 'ආයුබෝවන්!',
            EN: 'Hello!'
        };
        const message = (text && text.trim()) ? text.trim() : defaultMessage[language];

        // Extract the quoted user's phone number (assuming it's in E.164 format, i.e., with country code)
        const quotedJid = quoted.sender;
        const phoneNumber = quotedJid.split('@')[0]; // Extract the phone number part from the quoted JID

        // Construct the wa.me link with the message
        const waLink = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

        // Send the response with the wa.me link
        const responseMessage = {
            SI: `🔗 *පුද්ගලයාගේ WhatsApp ලින්ක්:* ${waLink}`,
            EN: `🔗 *WhatsApp Link for quoted user:* ${waLink}`
        };

        await conn.sendMessage(from, { 
            text: responseMessage[language],
            footer: `> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`
        });

    } catch (e) {
        console.error(e);
        const errorMessage = {
            SI: `🚫 දෝෂයක් සිදු විය: ${e.message}`,
            EN: `🚫 An error occurred: ${e.message}`
        };
        reply(errorMessage[language]);
    }
});
//=================================================================
cmd({
    pattern: "randomuser",
    desc: "Generate a random user profile.",
    react: "👤",
    category: "useful",
    filename: __filename
},
async (conn, mek, m, { reply }) => {
    try {
        const response = await fetchJson("https://randomuser.me/api/");
        const user = response.results[0];

        // Extracting user details
        const name = `${user.name.first} ${user.name.last}`;
        const email = user.email;
        const phone = user.phone || "Not Available";
        const gender = user.gender.charAt(0).toUpperCase() + user.gender.slice(1); // Capitalizing the first letter
        const dob = new Date(user.dob.date).toLocaleDateString(); // Formatting date of birth
        const location = `${user.location.city}, ${user.location.country}`;
        const avatar = user.picture.large;

        // Formatting the reply message
        const replyMessage = `
*Random User Profile*\n
👤 Name: ${name}
📧 Email: ${email}
📞 Phone: ${phone}
⚥ Gender: ${gender}
🎂 Date of Birth: ${dob}
🌍 Location: ${location}
🖼️ Avatar: ${avatar}

Want another user? Just type *.randomuser* again!`;

        reply(replyMessage);
    } catch (e) {
        console.log(e);
        reply("Could not fetch a random user. Please try again.");
    }
});
//=================================================================
cmd({
    pattern: "wordoftheday",
    desc: "Get a random word of the day.",
    react: "📚",
    category: "useful",
    filename: __filename
},
async (conn, mek, m, { reply }) => {
    try {
        const response = await fetchJson("https://random-word-api.herokuapp.com/word?number=1");
        const word = response[0];

        const meaningResponse = await fetchJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
        const meaning = meaningResponse[0].meanings[0].definitions[0].definition;

        reply(`*Word of the Day:* ${word}\n*Meaning:* ${meaning}`);
    } catch (e) {
        console.log(e);
        reply("Could not fetch the word of the day. Please try again.");
    }
});
//================================================================
cmd({
    pattern: "affirmation",
    desc: "Get a daily affirmation.",
    react: "💖",
    category: "useful",
    filename: __filename
},
async (conn, mek, m, { reply }) => {
    try {
        const affirmationData = await fetchJson("https://www.affirmations.dev/");
        reply(`💖 *Daily Affirmation:* ${affirmationData.affirmation}`);
    } catch (e) {
        console.log(e);
        reply("Could not fetch an affirmation right now.");
    }
});
//=============================================================
cmd({
    pattern: "recipe",
    desc: "Get a random recipe.",
    react: "🍽️",
    category: "useful",
    filename: __filename
},
async (conn, mek, m, { reply }) => {
    try {
        const response = await fetchJson("https://www.themealdb.com/api/json/v1/1/random.php");
        const meal = response.meals[0];

        const replyMessage = `
*Recipe: ${meal.strMeal}*
🍳 Instructions: ${meal.strInstructions}

🥗 Ingredients:
${Object.keys(meal)
    .filter(key => key.startsWith('strIngredient') && meal[key])
    .map(key => `- ${meal[key]}`)
    .join('\n')}

🍴 Enjoy your meal!`;

        reply(replyMessage);
    } catch (e) {
        console.log(e);
        reply("Could not fetch a recipe. Please try again.");
    }
});
//============================================================
cmd({
    pattern: "holidays",
    desc: "Get public holidays for a specific year (e.g. 2023) and country (e.g. US).",
    react: "🎉",
    category: "useful",
    filename: __filename
},
async (conn, mek, m, { reply, args }) => {
    const country = args[0] || "US";
    const year = args[1] || new Date().getFullYear();

    try {
        const response = await fetchJson(`https://date.nager.at/api/v2/publicholidays/${year}/${country}`);
        if (response.length === 0) return reply(`No holidays found for ${country} in ${year}.`);

        const holidays = response.map(holiday => `${holiday.date} - ${holiday.localName}`).join('\n');
        reply(`*Public Holidays in ${country} for ${year}:*\n${holidays}`);
    } catch (e) {
        console.log(e);
        reply("Could not fetch holidays. Please try again.");
    }
});

//=================================================================
cmd({
    pattern: "readmore",
    desc: "Readmore message",
    category: "useful",
    react: "📝",
    filename: __filename
}, async (conn, mek, m, {
    from, quoted, body, isCmd, command, args, q, isGroup, sender
}) => {
    try {
        // Get the message text after the command (.readmore text)
        let readmoreText = q ? q : "No text provided";

        // Create the "Readmore" effect by adding a special character to split the text
        let readmore = "\u200B".repeat(4000); // This creates a large gap between text

        // Full message to send
        let replyText = `${readmore}${readmoreText}`;

        // Send the message with the "Readmore" functionality
        await conn.sendMessage(from, { text: replyText }, { quoted: mek });

        // React to the message
        await conn.sendMessage(from, { react: { text: "", key: mek.key } });

    } catch (e) {
        console.log(e);
        reply(`Error: ${e.message}`);
    }
});
//=================================================================
cmd({
    pattern: "binance",
    desc: "Get current cryptocurrency prices from Binance",
    category: "useful",
    react: "📊",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, reply }) => {
    try {
        const config = await readEnv();

        if (args.length === 0) {
            return reply(config.LANGUAGE === 'SI' 
              ? "❌ කරුණාකර ක්‍රිප්ටෝකරන්සි සංකේතය ප්‍රදානය කරන්න. උදාහරණයක්: .binance BTC හෝ .binance ETHUSDT" 
              : "❌ Please specify a cryptocurrency symbol. Example: .binance BTC or .binance ETHUSDT");
        }

        const symbol = args[0].toUpperCase();
        let pair = symbol;
        if (!symbol.endsWith('USDT')) {
            pair = symbol + 'USDT';
        }

        const response = await axios.get(`https://api.binance.com/api/v3/ticker/24hr?symbol=${pair}`);

        if (response.data) {
            const data = response.data;
            const priceMessageSI = `
📊 *Binance මිල තොරතුරු ${symbol} සඳහා* 📊

💰 වර්තමාන මිල: $${parseFloat(data.lastPrice).toFixed(2)}
📈 24h වෙනස: ${parseFloat(data.priceChange).toFixed(2)} (${parseFloat(data.priceChangePercent).toFixed(2)}%)
🔼 24h උච්චතම: $${parseFloat(data.highPrice).toFixed(2)}
🔽 24h පහතම: $${parseFloat(data.lowPrice).toFixed(2)}
📊 24h පරිමාව: ${parseFloat(data.volume).toFixed(2)} ${symbol}

💹 *වෙළඳපොළ කාර්යය*
• ආරම්භක මිල: $${parseFloat(data.openPrice).toFixed(2)}
• වසා දැමූ මිල: $${parseFloat(data.prevClosePrice).toFixed(2)}
• සාපේක්ෂ සාමාන්‍ය: $${parseFloat(data.weightedAvgPrice).toFixed(2)}

🔄 අවසන් යාවත්කාලීන කිරීම: ${new Date().toLocaleString()}

තවත් ක්‍රිප්ටෝකරන්සි එකක් පරීක්ෂා කිරීමට? .binance [SYMBOL] භාවිතා කරන්න

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
            `.trim();

            const priceMessageEN = `
📊 *Binance Price Info for ${symbol}* 📊

💰 Current Price: $${parseFloat(data.lastPrice).toFixed(2)}
📈 24h Change: ${parseFloat(data.priceChange).toFixed(2)} (${parseFloat(data.priceChangePercent).toFixed(2)}%)
🔼 24h High: $${parseFloat(data.highPrice).toFixed(2)}
🔽 24h Low: $${parseFloat(data.lowPrice).toFixed(2)}
📊 24h Volume: ${parseFloat(data.volume).toFixed(2)} ${symbol}

💹 *Market Activity*
• Open Price: $${parseFloat(data.openPrice).toFixed(2)}
• Close Price: $${parseFloat(data.prevClosePrice).toFixed(2)}
• Weighted Avg: $${parseFloat(data.weightedAvgPrice).toFixed(2)}

🔄 Last updated: ${new Date().toLocaleString()}

Want to check another crypto? Just use .binance [SYMBOL]

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
            `.trim();

            await conn.sendMessage(from, { text: config.LANGUAGE === 'SI' ? priceMessageSI : priceMessageEN }, { quoted: mek });
        } else {
            reply(config.LANGUAGE === 'SI' 
              ? `❌ ${symbol} සඳහා දත්ත ලබා ගැනීමට අසමත් විය. නිවැරදි සංකේතයක් ඇතුලත් කර ඇති බවට වග බලා ගන්න.` 
              : `❌ Failed to fetch data for ${symbol}. Make sure you've entered a valid symbol.`);
        }
    } catch (e) {
        console.log(e);
        if (e.response && e.response.status === 400) {
            reply(config.LANGUAGE === 'SI' 
              ? "❌ නිරවද්‍ය සංකේතයක් නොවේ. කරුණාකර පරීක්ෂාකර නැවත උත්සාහ කරන්න." 
              : "❌ Invalid symbol. Please check and try again.");
        } else {
            reply(config.LANGUAGE === 'SI' 
              ? `🚫 දෝෂයක් සිදු විය: ${e.message}` 
              : `🚫 An error occurred: ${e.message}`);
        }
    }
});
//=================================================================







/*
//========================- NSFW COMMANDS -========================================

//=================================================================
cmd({
    pattern: "xnxx",
    desc: "Search XNXX for videos.",
    react: "🔍",
    category: "NSFW",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        console.log('NSFW_CMD:', config.NSFW_CMD);  // Debugging line

        // Check if NSFW commands are enabled
        if (config.NSFW_CMD !== true) {
            return reply(lang === 'SI' ? "❌ NSFW කමාන්ඩ් සක්‍රීය කර නොමැත. එය බොට් විධිමත් මූලිකතා වලට අනුකූල නොවේ." : "❌ NSFW commands are disabled. They are not allowed due to bot's ethical guidelines.");
        }
        const lang = config.LANGUAGE || 'EN'; 

        const noQueryProvidedText = lang === 'SI' ? "🪄 කරුණාකර සෙවීමේ පර්යේෂණයක් ලබා දෙන්න ✨" : "🪄 Please provide a search query ✨";
        const noResultsText = lang === 'SI' ? "❌ සෙවීම් පර්යේෂණය සඳහා වීඩියෝ සෙවීමක් නැත." : "❌ No videos found for the search query.";
        const fetchErrorText = lang === 'SI' ? "❌ සෙවීමේ ප්‍රතිඵල ලබා ගැනීමට අසමත් විය. කරුණාකර පසුගිය කරුණා කරන්න." : "❌ Failed to fetch the search results. Please try again later.";
        const errorOccurredText = lang === 'SI' ? "❗ දෝෂයක් සිදු විය." : "❗ An error occurred.";

        // Check if the search query is provided
        if (!q) return reply(noQueryProvidedText);

        // Construct the API URL for searching videos
        const apiUrl = `https://api.fgmods.xyz/api/search/xnxxsearch?text=${encodeURIComponent(q)}&apikey=Cu5RXZLd`;

        // Fetch search results from the API
        let response = await axios.get(apiUrl);
        let result = response.data;

        // Check if the API response contains data
        if (result && result.result && Array.isArray(result.result)) {
            if (result.result.length === 0) {
                return reply(noResultsText);
            }

            // Build the search results response with the new format
            let searchResults = lang === 'SI' ? "乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖷 𝖭 𝖷 𝖷  𝖲 𝖤 𝖠 𝖱 𝖢 𝖧  𝖤 𝖭 𝖦 𝖨 𝖭 𝖤\n\n" : "乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖷 𝖭 𝖷 𝖷  𝖲 𝖤 𝖠 𝖱 𝖢 𝖧  𝖤 𝖭 𝖦 𝖨 𝖭 𝖤\n\n";

            // Loop through results and format them based on the language
            result.result.forEach((video, index) => {
                searchResults += lang === 'SI' 
                    ? `🎬 මාතෘකාව : ${video.title}\n 🖇️ පිවිසුම් ලින්කුව : ${video.link || 'N/A'}\n\n`
                    : `🎬 Title: ${video.title}\n 🖇️ URL: ${video.link || 'N/A'}\n\n`;
            });

            // Send the search results as a message
            await conn.sendMessage(from, { 
                text: searchResults,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                        newsletterJid: "120363333519565664@newsletter",
                    },
                    externalAdReply: {
                        title: 'ＢＨＡＳＨＩ－ＭＤ Ｖ２ 🚀',
                        body: '© ᴘʀᴇꜱᴇɴᴇ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ',
                        thumbnailUrl: botimg2,
                        sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                        mediaType: 1
                    }
                }
            }, { quoted: mek });

        } else {
            // If the API response fails, send an error message
            return reply(fetchErrorText);
        }
    } catch (e) {
        console.error(e);
        reply(`${errorOccurredText} ${e.message}`); // Include error message in response
    }
});
//===============================================================
cmd({
    pattern: "xnxxdl",
    desc: "Download video from XNXX in high quality.",
    react: "📹",
    category: "NSFW",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Set language preference
        const noUrlProvidedText = lang === 'SI' ? "🪄 කරුණාකර බාගත කිරීමට XNXX වීඩියෝ URL එකක් ලබා දෙන්න ✨" : "🪄 Please provide an XNXX video URL to download ✨";
        const downloadFailedText = lang === 'SI' ? "❌ වීඩියෝ විස්තර ලබා ගැනීමට අසමත් විය. කරුණාකර URL පරීක්ෂා කර නැවත උත්සාහ කරන්න!" : "❌ Failed to fetch the video details. Please check the URL and try again!";
        const errorOccurredText = lang === 'SI' ? "❗ දෝෂයක් සිදු විය." : "❗ An error occurred.";

        // Check if the XNXX video URL is provided
        if (!q) return reply(noUrlProvidedText);

        // Construct the API URL for fetching video details
        const apiUrl = `https://api.fgmods.xyz/api/downloader/xnxxdl?url=${encodeURIComponent(q)}&apikey=Cu5RXZLd`;

        // Fetch video details from the API
        let response = await axios.get(apiUrl);
        let result = response.data;

        // Check if the API response contains data
        if (result && result.result) {
            const video = result.result;

            let desc = lang === 'SI'
                ? `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖷 𝖵 𝖨 𝖣 𝖤 𝖮  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 මාතෘකාව : ${video.title}
📻 බැලීම් : ${video.views || 'N/A'}
📁 ප්‍රමාණය : ${video.quality || 'N/A'}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  බාගත කිරීම : වීඩියෝ ආකාරයට.
│ 2️⃣  බාගත කිරීම : ගොනු ආකාරයට.
╰─────────────────────┈`
                : `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖷 𝖵 𝖨 𝖣 𝖤 𝖮  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

 🎬 𝖳𝗂𝗍𝗅𝖾 : ${video.title}
 📻 𝖵𝗂𝖾𝗐𝗌 : ${video.views || 'N/A'}
 📁 𝖲𝗂𝗓𝖤 : ${video.quality || 'N/A'}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖵𝗂𝖽𝖾𝗈 𝖳𝗒𝗉𝖾.
│ 2️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖣𝗈𝖼𝗎𝗆𝖾𝗇𝗍 𝖳𝗒𝗉𝖾.
╰─────────────────────┈`;

            // Send the video with options for download
            let sentMessage = await conn.sendMessage(from, { 
                    text: desc,
                  contextInfo: {
                      forwardingScore: 999,
                      isForwarded: true,
                      forwardedNewsletterMessageInfo: {
                          newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                          newsletterJid: "120363333519565664@newsletter",
                      },
                      externalAdReply: {
                          title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                          body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                          thumbnailUrl: botimg2,
                          sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                          mediaType: 1,
                          renderLargerThumbnail: false
                      }
                    }
                }, { quoted: mek });

            // Listen for the user's reply to select the download option
            conn.ev.on("messages.upsert", async (messageUpsert) => {
                const msg = messageUpsert.messages[0];
                if (!msg.message || !msg.message.extendedTextMessage) return;

                const userReply = msg.message.extendedTextMessage.text.trim();
                const messageContext = msg.message.extendedTextMessage.contextInfo;

                if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                    if (userReply === "1") {
                        await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                        await conn.sendMessage(from, {
                            video: { url: video.url_dl },
                            caption: lang === 'SI' ? "🎥 වීඩියෝ ඩවුන්ලෝඩ් සම්පූර්ණයි!\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ" : "🎥 Video download complete!\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                            mimetype: 'video/mp4'
                        });
                        await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                    } else if (userReply === "2") {
                        await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                        await conn.sendMessage(from, {
                            document: { url: video.url_dl },
                            caption: lang === 'SI' ? "📄 ගොනු ඩවුන්ලෝඩ් සම්පූර්ණයි!\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ" : "📄 Document download complete!\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                            mimetype: 'video/mp4'
                        });
                        await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                    } else {
                        // Handle invalid option
                        await conn.sendMessage(from, {
                            text: lang === 'SI' ? "❗ වැරදි අංකයක් ලබා දී ඇත. කරුණාකර සුදානම් කළ අංකයක් ලබා දෙන්න." : "❗ Invalid option, please reply with 1 or 2."
                        });
                    }
                }
            });
        } else {
            // If the API response fails, send an error message
            return reply(downloadFailedText);
        }
    } catch (e) {
        console.error(e);
        reply(` ${e.message}`); // Include error message in response
    }
});
//================================================================
cmd({
    pattern: 'hentai2',
    desc: 'Fetches NSFW Waifu images',
    category: 'NSFW',
    react: '🙄',
}, async (conn, mek, m, { from, quoted, reply }) => {
    const config = await readEnv();
    const url = 'https://api.waifu.pics/nsfw/waifu'; 
    const lang = config.LANGUAGE || 'EN'; // Set language preference

    // Multi-language messages
    const nsfwDisabledText = lang === 'SI' ? "🚫 NSFW විධාන අබල කර ඇත." : "🚫 NSFW commands are currently disabled.";
    if (!config.NSFW_CMD) {
        return reply(nsfwDisabledText);
    }
    const noPermissionText = lang === 'SI' ? "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        for (let i = 0; i < 5; i++) {
            const response = await axios.get(url);
            const imageUrl = response.data.url;
            await conn.sendMessage(from, { image: { url: imageUrl } }, { quoted: mek });
        }
    } catch (error) {
        console.error(error);
        reply(`🚫 An error occurred while retrieving the data: ${error.message}`);
    }
});

//========================================================================================================================================
// Command to fetch NSFW Trap images
cmd({
    pattern: 'trap',
    desc: 'Fetches NSFW trap images',
    category: 'NSFW',
    react: '🙄',
}, async (conn, mek, m, { from, quoted, reply }) => {
    const config = await readEnv();
    const url = 'https://api.waifu.pics/nsfw/trap';
    const lang = config.LANGUAGE || 'EN'; // Set language preference

    // Multi-language messages
    const nsfwDisabledText = lang === 'SI' ? "🚫 NSFW විධාන අබල කර ඇත." : "🚫 NSFW commands are currently disabled.";
    const noPermissionText = lang === 'SI' ? "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        for (let i = 0; i < 5; i++) {
            const response = await axios.get(url);
            const imageUrl = response.data.url;
            const caption = `Trap Waifu Image #${i + 1} 🔥\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`;
            await conn.sendMessage(from, { image: { url: imageUrl }, caption }, { quoted: mek });
        }
    } catch (error) {
        reply(`🚫 An error occurred while retrieving the data: ${error.message}`);
    }
});

//========================================================================================================================================
// Command to fetch NSFW Neko images
cmd({
    pattern: 'hneko',
    desc: 'Fetches NSFW neko images',
    category: 'NSFW',
    react: '🙄',
}, async (conn, mek, m, { from, quoted, reply }) => {
    const config = await readEnv();
    const url = 'https://api.waifu.pics/nsfw/neko';
    const lang = config.LANGUAGE || 'EN'; // Set language preference

    // Multi-language messages
    const nsfwDisabledText = lang === 'SI' ? "🚫 NSFW විධාන අබල කර ඇත." : "🚫 NSFW commands are currently disabled.";
    const noPermissionText = lang === 'SI' ? "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        for (let i = 0; i < 5; i++) {
            const response = await axios.get(url);
            const imageUrl = response.data.url;
            const caption = `Neko Waifu Image #${i + 1} 🐾\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`;
            await conn.sendMessage(from, { image: { url: imageUrl }, caption }, { quoted: mek });
        }
    } catch (error) {
        reply(`🚫 An error occurred while retrieving the data: ${error.message}`);
    }
});

//========================================================================================================================================
// Command to fetch NSFW Blowjob images
cmd({
    pattern: 'blowjob',
    desc: 'Fetches NSFW blowjob images',
    category: 'NSFW',
    react: '🙄',
}, async (conn, mek, m, { from, quoted, reply }) => {
    const config = await readEnv();
    const url = 'https://api.waifu.pics/nsfw/blowjob';
    const lang = config.LANGUAGE || 'EN'; // Set language preference

    // Multi-language messages
    const nsfwDisabledText = lang === 'SI' ? "🚫 NSFW විධාන අබල කර ඇත." : "🚫 NSFW commands are currently disabled.";
    const noPermissionText = lang === 'SI' ? "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;


        for (let i = 0; i < 5; i++) {
            const response = await axios.get(url);
            const imageUrl = response.data.url;
            const caption = lang === 'SI' 
                ? `🍑 Blowjob Waifu රූපය #${i + 1}\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}` 
                : `Blowjob Waifu Image #${i + 1} 🍑\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`;

            await conn.sendMessage(from, { image: { url: imageUrl }, caption }, { quoted: mek });
        }
    } catch (error) {
        reply(`🚫 An error occurred while retrieving the data: ${error.message}`);
    }
});
//========================================================================================================================================
cmd({
    pattern: 'hentaivid',
    desc: 'Fetches NSFW hentai videos',
    category: 'NSFW',
    react: '🙄',
}, async (conn, mek, m, { from, quoted, reply }) => {
    const config = await readEnv();
    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN'; // Set language preference

        // Multi-language messages
        const nsfwDisabledText = lang === 'SI' ? "🚫 NSFW විධාන අබල කර ඇත." : "🚫 NSFW commands are currently disabled.";
        if (!config.NSFW_CMD) {
            return reply(nsfwDisabledText);
        }
        const noPermissionText = lang === 'SI' ? "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";

        let videos = await hentai();
        let length = videos.length > 10 ? 10 : videos.length;
        let i = Math.floor(Math.random() * length);

        await conn.sendMessage(from, {
            video: { url: videos[i].video_1 },
            caption: `*🎥Title:* ${videos[i].title}\n*> 🎥Category:* ${videos[i].category} 🎥\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`
        }, { quoted: mek });
    } catch (error) {
        reply('🚫 An error occurred while retrieving the video: ' + error.message);
    }
});

async function hentai() {
    return new Promise((resolve, reject) => {
        const page = Math.floor(Math.random() * 1153);
        axios.get('https://sfmcompile.club/page/' + page)
            .then((data) => {
                const $ = cheerio.load(data.data);
                const results = [];
                $('#primary > div > div > ul > li > article').each(function () {
                    results.push({
                        title: $(this).find('header > h2').text(),
                        link: $(this).find('header > h2 > a').attr('href'),
                        category: $(this).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
                        share_count: $(this).find('header > div.entry-after-title > p > span.entry-shares').text(),
                        views_count: $(this).find('header > div.entry-after-title > p > span.entry-views').text(),
                        type: $(this).find('source').attr('type') || 'video/mp4',
                        video_1: $(this).find('source').attr('src') || $(this).find('img').attr('data-src'),
                        video_2: $(this).find('video > a').attr('href') || ''
                    });
                });
                resolve(results);
            })
            .catch((error) => reject(error));
    });
}
//========================================================================================================================================

// Search XNXX Command
cmd({
    pattern: "xvideo",
    desc: "Search XNXX for videos.",
    react: "🔍",
    category: "NSFW",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN';

        // Multi-language messages
        const nsfwDisabledText = lang === 'SI' ? "🚫 NSFW විධාන අබල කර ඇත." : "🚫 NSFW commands are currently disabled.";
        const noPermissionText = lang === 'SI' ? "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";
        const blacklistedText = lang === 'SI' ? "🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ." : "🚫 You are blacklisted. Access denied.";
        const noQueryProvidedText = lang === 'SI' ? "🪄 කරුණාකර සෙවීමේ පර්යේෂණයක් ලබා දෙන්න ✨" : "🪄 Please provide a search query ✨";
        const noResultsText = lang === 'SI' ? "❌ සෙවීම් පර්යේෂණය සඳහා වීඩියෝ සෙවීමක් නැත." : "❌ No videos found for the search query.";
        const fetchErrorText = lang === 'SI' ? "❌ සෙවීමේ ප්‍රතිඵල ලබා ගැනීමට අසමත් විය. කරුණාකර පසුගිය කරුණා කරන්න." : "❌ Failed to fetch the search results. Please try again later.";
        const errorOccurredText = lang === 'SI' ? "❗ දෝෂයක් සිදු විය." : "❗ An error occurred.";

        // Check if the search query is provided
        if (!q) return reply(noQueryProvidedText);

        // Construct the API URL for searching videos
        const apiUrl = `https://api.fgmods.xyz/api/search/xvideosearch?text=${encodeURIComponent(q)}&apikey=Cu5RXZLd`;

        // Fetch search results from the API
        let response = await axios.get(apiUrl);
        let result = response.data;

        // Check if the API response contains data
        if (result && result.result && Array.isArray(result.result)) {
            if (result.result.length === 0) {
                return reply(noResultsText);
            }

            // Build the search results response
            let searchResults = lang === 'SI' ? "🔍 *Xvideo සෙවීම් ප්‍රතිඵල:*\n\n" : "🔍 *XNXX Search Results:*\n\n";
            result.result.forEach((video, index) => {
                searchResults += `${index + 1}. *TITLE*: ${video.title}\n> 🔗 *Video URL*: ${video.url || 'N/A'}\n\n`;
            });

            // Send the search results as a message
            await conn.sendMessage(from, { text: searchResults }, { quoted: mek });
        } else {
            // If the API response fails, send an error message
            return reply(fetchErrorText);
        }
    } catch (e) {
        console.error(e);
        reply(`${errorOccurredText} ${e.message}`); // Include error message in response
    }
});

// Download XNXX Command
cmd({
    pattern: "xvideodl",
    desc: "Download video from XNXX in high quality.",
    react: "📹",
    category: "NSFW",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN';

        // Multi-language messages
        const nsfwDisabledText = lang === 'SI' ? "🚫 NSFW විධාන අබල කර ඇත." : "🚫 NSFW commands are currently disabled.";
        const noPermissionText = lang === 'SI' ? "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";
        const blacklistedText = lang === 'SI' ? "🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ." : "🚫 You are blacklisted. Access denied.";
        const noUrlProvidedText = lang === 'SI' ? "🪄 කරුණාකර බාගත කිරීමට XNXX වීඩියෝ URL එකක් ලබා දෙන්න ✨" : "🪄 Please provide an XNXX video URL to download ✨";
        const downloadFailedText = lang === 'SI' ? "❌ වීඩියෝ විස්තර ලබා ගැනීමට අසමත් විය. කරුණාකර URL පරීක්ෂා කර නැවත උත්සාහ කරන්න!" : "❌ Failed to fetch the video details. Please check the URL and try again!";
        const errorOccurredText = lang === 'SI' ? "❗ දෝෂයක් සිදු විය." : "❗ An error occurred.";

        // Check if the XNXX video URL is provided
        if (!q) return reply(noUrlProvidedText);

        // Construct the API URL for fetching video details
        const apiUrl = `https://api.fgmods.xyz/api/downloader/xvideosdl?url=${encodeURIComponent(q)}&apikey=Cu5RXZLd`;

        // Fetch video details from the API
        let response = await axios.get(apiUrl);
        let result = response.data;

        // Check if the API response contains data
        if (result && result.result) {
            const video = result.result;

            let desc = lang === 'SI'
                ? `🎬 *ශීර්ෂය*: ${video.title}\n> 👁️ *දැක්වීම්*: ${video.views || 'N/A'}\n> 📺 *ගුණාත්මකභාවය*: ${video.size|| 'N/A'}\n> ⏳ *කාලසීමාව*: ${video.vote || 'N/A'}`
                : `🎬 *TITLE*: ${video.title}\n> 👁️ *Views*: ${video.views || 'N/A'}\n> 📺 *Quality*: ${video.size || 'N/A'}\n> ⏳ *Vote*: ${video.vote|| 'N/A'}`;

            // Send the video
            await conn.sendMessage(from, {
                video: { url: video.url_dl },
                caption: desc,
                mimetype: 'video/mp4',
                contextInfo: {
                    externalAdReply: {
                        title: video.title,
                        body: "⚜️ ʙʜᴀꜱʜɪ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ ᴡᴀ ʙᴏᴛ 2024™️ | ©️ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴠɪꜱʜᴡᴀ ᴍɪʜɪʀᴀɴɡᴀ ᴀɴᴅ ʙʜᴀꜱʜɪᴛʜᴀ | ᴛᴇᴀᴍ ʙʏ ᴅᴀʀᴋ ʜᴀᴄᴋ ᴢᴏɴᴇ",
                        thumbnailUrl: video.thumb, // Ensure 'article' is defined with a valid thumbnail
                        sourceUrl: video.url_dl, // Ensure 'article' is defined with a valid link
                        mediaType: 1, // 1 for image or video, set accordingly
                        renderLargerThumbnail: false // Adjust as necessary
                    }
                }
            }, { quoted: mek });
        } else {
            // If the API response fails, send an error message
            return reply(downloadFailedText);
        }
    } catch (e) {
        console.error(e);
        reply(`${errorOccurredText} ${e.message}`); // Include error message in response
    }
});
//=================================================================
*/







//========================- FUN COMMANDS - ======================================
//=================================================================
const userTipIndex = new Map();

cmd({
    pattern: "studyhelper",
    desc: "Provide study tips and resources.",
    category: "fun",
    react: "📚",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const config = await readEnv();
    const tips = {
        en: [
            "📖 Break your study time into manageable chunks with breaks in between.",
            "📝 Use active recall and spaced repetition to improve retention.",
            "🌟 Practice past exam papers and sample questions.",
            "🎯 Set specific goals for each study session.",
            "💡 Teach what you've learned to someone else to solidify your understanding.",
            "📚 Organize your study space to reduce distractions.",
            "📅 Create a study schedule and stick to it.",
            "🎧 Listen to instrumental music or white noise to improve focus.",
            "🔍 Summarize your notes to highlight key points.",
            "🧠 Use mnemonic devices to remember complex information.",
            "✍️ Practice writing essays and problem-solving regularly.",
            "🧩 Mix different subjects during study sessions to keep things interesting.",
            "📊 Use flashcards for quick review and memorization.",
            "🌐 Use online resources and educational videos to supplement your learning.",
            "💪 Stay physically active and exercise to boost cognitive function.",
            "🚶‍♂️ Take regular breaks to rest and recharge your mind.",
            "💤 Ensure you get enough sleep for optimal cognitive performance.",
            "🥗 Eat a balanced diet to support brain health and concentration.",
            "📈 Track your progress to stay motivated and identify areas for improvement.",
            "👥 Study with friends or in study groups to gain different perspectives.",
            "🔖 Use color-coded notes or diagrams to visually organize information.",
            "📖 Read textbooks and additional materials for a deeper understanding.",
            "🕒 Practice time management during exams and assignments.",
            "📚 Set aside dedicated time for review and revision before exams.",
            "✏️ Practice mindfulness and stress-relief techniques to manage exam anxiety.",
            "🔑 Focus on understanding concepts rather than rote memorization.",
            "🎯 Set realistic and achievable study goals to maintain motivation.",
            "💡 Use apps and tools for time management and productivity.",
            "🎓 Seek help from teachers or tutors if you're struggling with specific topics.",
            "📚 Read summaries and highlights to reinforce learning.",
            "🎯 Stay organized with a planner or to-do list for tasks and deadlines.",
            "🧠 Challenge yourself with practice questions and mock tests regularly.",
            "🔄 Review and revisit material periodically to reinforce learning."
        ],
        si: [
            "📖 ඔබගේ අධ්‍යයන කාලය කළමනාකරණය කළ හැකි කොටස් වලට බෙදාගන්න, අතර අතර වරාය කරන්න.",
            "📝 මතකය වර්ධනය කිරීමට සක්‍රීය ප්‍රතිලාභය සහ ස්ථානය නිවාස කිරීම් භාවිතා කරන්න.",
            "🌟 පසුගිය පරීක්ෂණ කඩපත සහ සාම්පල ප්‍රශ්න මනාප කරන්න.",
            "🎯 ඔබගේ සියලු අධ්‍යයන සැසියකට නිශ්චිත ඉලක්ක සකසන්න.",
            "💡 ඔබ ඉගෙනගත් දේ කිසියම් අයෙකුට උගන්වනවා අධ්‍යයනය තහවුරු කිරීමට.",
            "📚 ඔබගේ අධ්‍යයන අවකාශය සංවිධානය කරන්න සහ අපහසුතා අඩු කරන්න.",
            "📅 අධ්‍යයන කාලසටහනක් සාදා එය අනුගමනය කරන්න.",
            "🎧 මනාව අවධානය යොමු කිරීමට ආශ්‍රිත සංගීතය හෝ සුළඟකාරී සංගීතය අසන්න.",
            "🔍 ඔබගේ සටහන් සංක්ෂේප කරන්න ප්‍රධාන ලක්ෂණ තනි කරන්න.",
            "🧠 දුෂ්කර තොරතුරු මතක තබා ගැනීමට මනෝමය උපකරණ භාවිතා කරන්න.",
            "✍️ නියුක්ත ලේඛන සහ ප්‍රශ්න විසඳීම සමාන්‍යයෙන් පුහුණු කරන්න.",
            "🧩 අධ්‍යයන සැසීන් අතර විවිධ විෂය මිශ්‍ර කරන්න.",
            "📊 වේගයෙන් නැවත සමාලෝචනය සඳහා ෆ්ලැෂ්කාර්ඩ් භාවිතා කරන්න.",
            "🌐 අන්තර්ජාල ආධාරක සහ අධ්‍යයන වීඩියෝ භාවිතා කරන්න.",
            "💪 ඔබේ මනෝකරණ ක්‍රියාවලීන් සවිෂ්ට කරා පවත්වා ගන්න.",
            "🚶‍♂️ ඔබගේ මනස නැවත ප්‍රභාෂය සහ යළි ඉල්ලීමට සාමාන්‍යයෙන් අධ්‍යයනය කරන්න.",
            "💤 හොඳින් නිදා ගැනීම ප්‍රමාණවත්ද යන්න විශ්වස කරන්න.",
            "🥗 මනස සහ අවධානය සහය වීම සඳහා සමීප ශාක්‍යයක් රැගෙන අයදුම් කරන්න.",
            "📈 ඔබගේ සංකල්ප වර්ධනය සඳහා යෝජනා සකස් කරන්න.",
            "👥 මිතුරන් සමඟ අධ්‍යයනය කරන්න.",
            "🔖 ඔබගේ සටහන් දෘශ්‍යමය සංවිධානය කරයි.",
            "📖 ප්‍රධාන ලක්ෂණ ඉගෙන ගැනීමට පිළිබඳ පර්යේෂණය කරන්න.",
            "🕒 විභාග සහ කටයුතු කළමනාකරණය කරන්න.",
            "📚 විභාග සඳහා පෙර අධ්‍යයනයට වෙන් කළ කාලයක් ඇතිකරන්න.",
            "✏️ මානසිකයෝ සහ එම අඩුවලකුව භාවිතා කරන්න.",
            "🔑 කාර්යක්ෂම මතකය සහ නිවැරදිව සලස්වනු ඇත.",
            "🎯 වාසිය සහ වාසියක් සක්‍රීය කරන්න.",
            "💡 කාල කළමනාකරණය සහ නිෂ්පාදන සඳහා යෙදුම් සහ මෙවලම් භාවිතා කරන්න.",
            "🎓 ගුරුවරුන් හෝ ආධාරකයන්ගෙන් උපකාරයක් ලැබීමට උත්සාහ කරන්න.",
            "📚 සංක්ෂේප හා අවධි පුහුණු ගැනීමට පාඨකයන් හෝ සංග්‍රහය කරන්න.",
            "🎯 කටයුතු සහ කාල සටහන් සඳහා සැකැස්මක් භාවිතා කරන්න.",
            "🧠 ක්‍රියාත්මක ප්‍රශ්න සහ නිදර්ශන භාවිතා කරන්න.",
            "🔄 කාල සටහන් සම්පූර්ණයෙන් හෝ නැවත නැවත සකස් කරන්න."
        ]
    };

    // Retrieve the user's language preference from the context, ensuring it matches the expected format
    const lang = (config.LANGUAGE || 'en').toLowerCase(); // Default to English if no language is set
    const selectedTips = tips[lang];

    // Check if selectedTips is valid
    if (!selectedTips) {
        return reply("📚 Sorry, we couldn't find tips for your selected language. Defaulting to English.");
    }

    // Retrieve the last sent tip index for the user
    let index = userTipIndex.get(from) || 0;

    // Send the next tip
    if (index < selectedTips.length) {
        reply(`*📚 Study Tip ${index + 1}:*\n${selectedTips[index]}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
        // Update the index for the next time the user requests a tip
        userTipIndex.set(from, index + 1);
    } else {
        reply("📚 You’ve received all study tips. Use `!studyhelper` again to start over.");
        // Reset the index if you want to allow users to start over
        userTipIndex.delete(from);
    }
});
//================================================================
cmd({
    pattern: "hack",
    desc: "Displays a dynamic and playful 'Hacking' message for fun.",
    category: "fun",
    react: "💻",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN'; // Get the language preference

        // Start the hacking message sequence
        const initialMessage = await conn.sendMessage(from, { text: `𝖡𝗁𝖺𝗌𝗁𝗂 𝖧𝖺𝖼𝗂𝗇𝗀 𝖲𝗍𝖺𝗋𝗍𝖾𝖽 🖥️`}, { quoted: mek });

        const steps = [
            '[██]  10% 🖥️',
            '[████]  20% 🖥️',
            '[█████]  30% 🖥️',
            '[███████]  40% 🖥️',
            '[█████████]  50% 🖥️',
            '[███████████]  60% 🖥️',
            '[█████████████]  70% 🖥️',
            '[██████████████]  80% 🖥️',
            '[████████████████]  90% 🖥️',
            '[█████████████████] 100% 🖥️',
              '𝖧𝖺𝖼𝗄𝖾𝖽 𝖲𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅 𝖯𝗈𝗐𝖾𝗋𝖽 𝖡𝗒 𝖡𝗁𝖺𝗌𝗁𝗂 𝖳𝖾𝖺𝗆 🖥️'
        ];

        // Edit the initial message with each step
        for (const line of steps) {
            await conn.editMessage(from, initialMessage.key, { text: line });
            await new Promise(resolve => setTimeout(resolve, 1000)); // Adjust the delay as needed
        }
    } catch (e) {
        console.log(e);
        reply(`❌ *Error:* ${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "fact",
    desc: "🧠 Get a random fun fact",
    react: "🤓",
    category: "fun",
    filename: __filename
},
async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const url = 'https://uselessfacts.jsph.pl/random.json?language=en';  // API for random facts
        const response = await axios.get(url);
        const fact = response.data.text;

        const funFactSI = `
🧠 *අනවශ්‍ය විනෝද තොරතුරක්* 🧠

${fact}

ඇත්තෙන්ම විනෝදජනක නේද? 😄

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
`;

        const funFactEN = `
🧠 *Random Fun Fact* 🧠

${fact}

Isn't that interesting? 😄

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
`;

        return reply(config.LANGUAGE === 'SI' ? funFactSI : funFactEN);
    } catch (e) {
        console.log(e);
        return reply(config.LANGUAGE === 'SI' 
          ? "⚠️ තොරතුරක් ලබා ගැනීමට උත්සාහ කිරීමේදී දෝෂයක් සිදු විය. කරුණාකර නැවත උත්සාහ කරන්න." 
          : "⚠️ An error occurred while fetching a fun fact. Please try again later.");
    }
});
//=================================================================
cmd({
  pattern: 'genderize',
  desc: 'Get the most likely gender of a name.',
  category: 'fun',
  react: '🧑‍🤝‍🧑',
  filename: __filename
}, async (conn, mek, m, { from, quoted, q, pushname, reply }) => {
    const config = await readEnv();
  // Define language preference (SI for Sinhala, EN for English)
  const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

  try {
      const senderNumber = m.sender;
      const isGroup = m.isGroup || false;

      if (!q) {
          const noInputMsg = {
              SI: "*♻ කරුණාකර විශ්ලේෂණය කිරීමට නම් ලබා දෙන්න.*",
              EN: "*♻ Please provide a name to analyze.*"
          };
          return reply(noInputMsg[language]);
      }

      const response = await axios.get(`https://api.genderize.io/?name=${q}`);
      const data = response.data;

      if (data.gender) {
          const genderResult = {
              SI: `✨ "${q}" නම් සඳහා ප්‍රධාන වශයෙන් ලිංගය: \n*${data.gender}* (${(data.probability * 100).toFixed(2)}%)\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
              EN: `✨ The most likely gender for the name "${q}" is: \n*${data.gender}* (${(data.probability * 100).toFixed(2)}%)\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
          };
          reply(genderResult[language]);
      } else {
          const noDataMsg = {
              SI: `😔 "${q}" නම් සඳහා ලිංග තොරතුරු නොමැත.`,
              EN: `😔 No gender data found for the name "${q}".`
          };
          reply(noDataMsg[language]);
      }
  } catch (error) {
      console.error('Error fetching gender data:', error);
      const errorMsg = {
          SI: '⚠️ ලිංග තොරතුරු ලබා ගැනීමේදී දෝෂයක් සිදුවීය. කරුණාකර යළි උත්සාහ කරන්න.',
          EN: '⚠️ An error occurred while fetching gender data. Please try again later.'
      };
      reply(errorMsg[language]);
  }
});
//=================================================================
cmd({
    pattern: 'predict',
    desc: 'Gives a random prediction about your future.',
    category: 'fun',
    react: '🔮',
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const config = await readEnv();
    const translations = {
        SI: {
            noPermission: "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!",
            blacklisted: "🚫 ඔබ කළු ලැයිස්තුවේ වේ. ප්‍රවේශය තහනම්ය.",
            predictionIntro: "🔮 *මෙන්න ඔබේ අනාගත කතානායකය* 🔮",
            career: "*වෘත්තිය*: ඔබට පළමුවරට ",
            loveLife: "*ආදර ජීවිතය*: ",
            randomEvent: "*අහඹු සිදුවීමක්*: ",
            closing: "🌟 ඔබේ අනාගතය මෙම කතානායකයට සමාන ලෙසින්ම ප්‍රබල වේවා!",
            errorOccurred: "⚠️ ඔබේ කතානායකය පෙනවීමේදී දෝෂයක් ඇතිවිය."
        },
        EN: {
            noPermission: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!",
            blacklisted: "🚫 You are blacklisted. Access denied.",
            predictionIntro: "🔮 *Here is your future prediction* 🔮",
            career: "*Career*: You will become a ",
            loveLife: "*Love Life*: ",
            randomEvent: "*Random Event*: ",
            closing: "🌟 May your future be as bright as this prediction!",
            errorOccurred: "⚠️ An error occurred while making your prediction."
        }
    };

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN'; // Default to English if not set
        // Define random categories for predictions
        const careers = ['software developer', 'artist', 'CEO of a tech company', 'professional gamer', 'chef'];
        const loveLife = ['you will meet someone special', 'an old friend will reach out', 'you will take an exciting solo adventure', 'love will surprise you when least expected'];
        const randomEvents = ['you will win the lottery', 'you will discover a hidden talent', 'a big opportunity will come your way', 'a mystery will be revealed to you'];

        // Randomly select predictions from the arrays
        const careerPrediction = careers[Math.floor(Math.random() * careers.length)];
        const loveLifePrediction = loveLife[Math.floor(Math.random() * loveLife.length)];
        const randomEventPrediction = randomEvents[Math.floor(Math.random() * randomEvents.length)];

        // Create the prediction message based on the selected language
        const predictionMessage = `
${translations[lang].predictionIntro}

${translations[lang].career}${careerPrediction}.

${translations[lang].loveLife}${loveLifePrediction}.

${translations[lang].randomEvent}${randomEventPrediction}.

${translations[lang].closing}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        // Send the prediction message
        await conn.sendMessage(from, { text: predictionMessage }, { quoted: m });
        console.log('Prediction sent successfully');
    } catch (e) {
        console.error('Error executing prediction command:', e);
        reply(translations[lang].errorOccurred);
    }
});
//=================================================================
cmd({
    pattern: 'predict',
    desc: 'Open a mystery box and get a surprise item!',
    category: 'fun',
    react: '🎁',
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    const config = await readEnv();
    const translations = {
        SI: {
            noPermission: "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!",
            blacklisted: "🚫 ඔබ කළු ලැයිස්තුවේ වේ. ප්‍රවේශය තහනම්ය.",
            congratulations: "🎉 *අපූරුයි!* ඔබ ලබාගෙන ඇත: ",
            errorOccurred: "⚠️ මෘදු කොටුව විවෘත කිරීමේදී දෝෂයක් ඇතිවිය."
        },
        EN: {
            noPermission: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!",
            blacklisted: "🚫 You are blacklisted. Access denied.",
            congratulations: "🎉 *Congratulations!* You've received: ",
            errorOccurred: "⚠️ An error occurred while opening the mystery box."
        }
    };
    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN'; // Default to English if not set

        // Randomly select a mystery item from the hardcoded list
        const mysteryItems = ['a golden watch', 'a magical wand', 'a rare gemstone', 'a mysterious map', 'an ancient coin', 'a futuristic gadget'];
        const randomIndex = Math.floor(Math.random() * mysteryItems.length);
        const mysteryItem = mysteryItems[randomIndex];

        // Send the mystery item as a surprise with the correct language
        await conn.sendMessage(from, { 
            text: `${translations[lang].congratulations}${mysteryItem}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` 
        }, { quoted: m });

        console.log('Mystery box opened successfully');
    } catch (e) {
        console.error('Error opening mystery box:', e);
        reply(translations[lang].errorOccurred);
    }
});
//=================================================================
cmd({
    pattern: "predict",
    desc: "😂 Get a random joke",
    react: "🤣",
    category: "fun",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN'; // Get the language preference

        // Multi-language messages
        const accessDeniedText = lang === 'SI' ? "😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!" : "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!";
        const blacklistedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
        const errorText = lang === 'SI' ? "⚠️ දැන් ආස්ථාන කිරීමක් ලබාගත නොහැක. කරුණාකර පසුගිය කරුණා කරන්න." : "⚠️ Couldn't fetch a joke right now. Please try again later.";
        const jokeHeaderText = lang === 'SI' ? "😂 *ඔබට කුතුහලයක් ලබා දීමට තරම් කුතුහලක්!* 😂" : "😂 *Here's a random joke for you!* 😂";
        const url = 'https://official-joke-api.appspot.com/random_joke';  // API for random jokes
        const response = await axios.get(url);
        const joke = response.data;

        // Fixed joke message structure
        const jokeMessage = `
${jokeHeaderText}

*${joke.setup}*

${joke.punchline} 😄

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        return reply(jokeMessage);
    } catch (e) {
        console.log(e);
        return reply(errorText);
    }
});
//===============================================================
cmd({
    pattern: "gif",
    react: "🎥",
    desc: "Search for GIF-like animated images on Pixabay.",
    category: "fun",
    use: '.gif <search term> [tiny|small|medium|large]',
    filename: __filename
},
async (conn, mek, m, { from, q, args, reply }) => {
    const config = await readEnv();
    const PIXABAY_API_KEY = config.PIXABAY_API_KEY;
    const PIXABAY_API_URL = 'https://pixabay.com/api/videos/';
    // GIF Search command
    const translations = {
        SI: {
            noPermission: "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නොමැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!",
            blacklisted: "🚫 ඔබ කළු ලැයිස්තුවේ වේ. ප්‍රවේශය තහනම්ය.",
            provideSearchTerm: "❗ කරුණාකර සෙවීමේ පදයක් ලබා දෙන්න.",
            noGifsFound: "❗ සෙවීමේ පදය සඳහා කිසිදු GIF නොමැත.",
            finalMessage: "🎉 ඔබේ සෙවීමේ පදය සඳහා Pixabay හි ඉහළ GIFs ගණනාව මෙන්න.",
            errorOccurred: "❗ GIF ලබා ගැනීමේදී දෝෂයක් සිදු විය."
        },
        EN: {
            noPermission: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!",
            blacklisted: "🚫 You are blacklisted. Access denied.",
            provideSearchTerm: "❗ Please provide a search term.",
            noGifsFound: "❗ No GIFs found for the provided search term.",
            finalMessage: "🎉 These are the top GIFs from Pixabay for your search term.",
            errorOccurred: "❗ Error occurred while fetching GIFs."
        }
    };
    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE || 'EN'; // Default to English if not set

        if (!q) return reply(translations[lang].provideSearchTerm);

        // Extract search term and size preference
        const searchTerm = args.slice(0, -1).join(' ') || args[0];
        const sizePreference = args[args.length - 1].toLowerCase();

        // Validate size preference
        const validSizes = ['tiny', 'small', 'medium', 'large'];
        const gifSize = validSizes.includes(sizePreference) ? sizePreference : 'small';

        // Make request to Pixabay API for animated videos (GIF-like content)
        const response = await axios.get(PIXABAY_API_URL, {
            params: {
                key: PIXABAY_API_KEY,
                q: searchTerm,
                video_type: 'animation',
                per_page: 5
            }
        });

        const data = response.data;
        if (data.hits.length === 0) return reply(translations[lang].noGifsFound);

        // Send GIFs one by one
        for (let i = 0; i < data.hits.length; i++) {
            const hit = data.hits[i];
            const caption = `*${i + 1}.* ${hit.tags}\n👤 *User:* ${hit.user}\n👁️ *Views:* ${hit.views}\n❤️ *Likes:* ${hit.likes}\n🖼️ *Size:* ${gifSize}`;

            await conn.sendMessage(from, { 
                video: { url: hit.videos[gifSize].url },
                caption: caption,
                gifPlayback: true
            }, { quoted: mek });

            // Add a small delay between messages to prevent flooding
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        // Send a final message
        await conn.sendMessage(from, { 
            text: translations[lang].finalMessage
        }, { quoted: mek });

    } catch (e) {
        reply(translations[lang].errorOccurred);
        console.error(e);
    }
});
//=================================================================



















//=====================-SEACH COMMAND-===================================
//=================================================================
// Define possible text formats
const textFormats = [
    `*Current Cricket Match:*`,
    `*Ongoing Cricket Match:*`,
    `*Latest Cricket Match:*`
];

// Function to get a random text format
const getRandomTextFormat = () => textFormats[Math.floor(Math.random() * textFormats.length)];

cmd({
  pattern: "cric",
  desc: "Get a random current cricket match.",
  react: "🏏",
  category: "search",
  filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
  const config = await readEnv();
  const language = config.LANGUAGE || "EN"; // Default to English
  const CRIC_URL = 'https://api.cricapi.com/v1/currentMatches';
  const CRIC_KEY = 'f68d1cb5-a9c9-47c5-8fcd-fbfe52bace78';

  try {
    // Fetch current cricket matches
    let response = await fetch(`${CRIC_URL}?apikey=${CRIC_KEY}`);
    let data = await response.json();

    if (!data || !data.data || data.data.length === 0) {
      const noMatchMessage = {
        SI: "🏏 දැන් ක්‍රියාත්මක වන කිසිදු ක්‍රිකට් තරගයක් සොයා ගත නොහැකි විය.",
        EN: "🏏 No current cricket matches found."
      };
      return reply(noMatchMessage[language]);
    }

    // Function to send match details
    const sendMatchDetails = async (match) => {
      let matchesMessage = `🏏 ${getRandomTextFormat()}\n\n`;

      // Check if teamInfo exists and is valid
      let teamInfo = {};
      if (match.teamInfo && Array.isArray(match.teamInfo)) {
        teamInfo = match.teamInfo.reduce((info, team) => {
          if (team.shortname && team.img) {
            info[team.shortname] = team.img;
          }
          return info;
        }, {});
      }

      const matchInfoMessage = {
        SI: `🏆 *තරගය:* ${match.name} \n📍 *ස්ථානය:* ${match.venue} \n📅 *දිනය:* ${match.date} \n🆚 *කණ්ඩායම්:* ${match.teams.map((team) => {
          return teamInfo[team] ? `![${team}](${teamInfo[team]}) ${team}` : team;
        }).join(' 🆚 ')}\n⏳ *තත්ත්වය:* ${match.status} \n`,
        EN: `🏆 *Match:* ${match.name} \n📍 *Venue:* ${match.venue} \n📅 *Date:* ${match.date} \n🆚 *Teams:* ${match.teams.map((team) => {
          return teamInfo[team] ? `![${team}](${teamInfo[team]}) ${team}` : team;
        }).join(' 🆚 ')}\n⏳ *Status:* ${match.status} \n`
      };
      matchesMessage += matchInfoMessage[language];

      // Add scores if available
      if (Array.isArray(match.score)) {
        match.score.forEach(score => {
          const scoreMessage = {
            SI: `*${score.inning}:* ${score.r} ක් රැස්කඩ 🏏, ${score.w} ක් විකට් 🎯, ${score.o} ක් ඕවර් ⏱️\n`,
            EN: `*${score.inning}:* ${score.r} runs 🏏, ${score.w} wickets 🎯, ${score.o} overs ⏱️\n`
          };
          matchesMessage += scoreMessage[language];
        });
      }

      const promptMessage = {
        SI: "\n1 | *තවත් තරගයක් ලබා ගන්න*\n",
        EN: "\n1 | *Get Another Match*\n"
      };
      matchesMessage += promptMessage[language];
      matchesMessage += `\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

      // Send the match message
      const sentMessage = await conn.sendMessage(from, { text: matchesMessage }, { quoted: mek });

      // Listen for replies to the sent message
      conn.ev.on("messages.upsert", async (messageUpsert) => {
        const replyMessage = messageUpsert.messages[0];
        if (!replyMessage.message || !replyMessage.message.extendedTextMessage) return;

        const userReply = replyMessage.message.extendedTextMessage.text.trim();
        const messageContext = replyMessage.message.extendedTextMessage.contextInfo;

        // Check if the reply is to the previously sent message
        if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
          if (userReply === '1') {
            // Select another random match
            let newMatch = data.data[Math.floor(Math.random() * data.data.length)];
            await sendMatchDetails(newMatch); // Send the details of the new match
          } else {
            const invalidInputMessage = {
              SI: "❗ අවලංගු පිළිතුර. තවත් තරගයක් ලබා ගැනීමට '1' කියා පිළිතුරක් එවන්න.",
              EN: "❗ Invalid input. Reply with '1' to get another match."
            };
            await conn.sendMessage(from, { text: invalidInputMessage[language] }, { quoted: replyMessage });
          }
        }
      });
    };

    // Select a random match
    let match = data.data[Math.floor(Math.random() * data.data.length)];
    await sendMatchDetails(match); // Send match details initially

  } catch (e) {
    console.log(e);
    const errorMessage = {
      SI: `⚠️ දෝෂයක් සිදු විය: ${e.message}`,
      EN: `⚠️ An error occurred: ${e.message}`
    };
    reply(errorMessage[language]);
  }
});

//=================================================================
cmd({
    pattern: "define",
    desc: "📚 Get the definition of a word",
    react: "🔍",
    category: "search",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();

        // Multilingual messages
        const messages = {
            noWord: {
                SI: "❗ කරුණාකර නිර්වචනය කිරීමට පදයක් ලබා දෙන්න. භාවිතය: .define [pada]",
                EN: "❗ Please provide a word to define. Usage: .define [word]"
            },
            wordNotFound: {
                SI: "🚫 පදය හමු නොවීය. කරුණාකර වක්‍රීකරනය පරීක්ෂා කරන්න.",
                EN: "🚫 Word not found. Please check the spelling and try again."
            },
            fetchError: {
                SI: "⚠️ නිර්වචනය ලබා ගැනීමට දෝෂයක් සිදු විය. කරුණාකර නැවත උත්සාහ කරන්න.",
                EN: "⚠️ An error occurred while fetching the definition. Please try again later."
            },
            wordInfoHeader: {
                SI: "📚 *BASHI-MD ශබ්දකෝෂය* 🔍\n",
                EN: "📚 *BASHI-MD DICTIONARY* 🔍\n"
            },
            wordLabel: {
                SI: "📚 *පදය*: ",
                EN: "📚 *Word*: "
            },
            definitionLabel: {
                SI: "🔍 *නිර්වචනය*: ",
                EN: "🔍 *Definition*: "
            },
            exampleLabel: {
                SI: "📝 *උදාහරණය*: ",
                EN: "📝 *Example*: "
            },
            synonymsLabel: {
                SI: "🔗 *සමාන පද*: ",
                EN: "🔗 *Synonyms*: "
            },
        };

        // Check if a word is provided
        if (!q) return reply(messages.noWord[config.LANGUAGE.toUpperCase()]);

        const word = q;
        const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;

        const response = await axios.get(url);
        const definitionData = response.data[0];

        const definition = definitionData.meanings[0].definitions[0].definition;
        const example = definitionData.meanings[0].definitions[0].example || 'No example available';
        const synonyms = definitionData.meanings[0].definitions[0].synonyms.join(', ') || 'No synonyms available';

        const lang = config.LANGUAGE.toUpperCase(); // Get the current language setting

        const wordInfo = `${messages.wordInfoHeader[lang]}\n${messages.wordLabel[lang]}${definitionData.word}\n${messages.definitionLabel[lang]}${definition}\n${messages.exampleLabel[lang]}${example}\n${messages.synonymsLabel[lang]}${synonyms}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        return reply(wordInfo);
    } catch (e) {
        console.log(e);
        if (e.response && e.response.status === 404) {
            return reply(messages.wordNotFound[config.LANGUAGE.toUpperCase()]);
        }
        return reply(messages.fetchError[config.LANGUAGE.toUpperCase()]);
    }
});
//=================================================================
cmd({
  pattern: "gits",
  alias: ["gitsearch"],
  desc: "Search GitHub repositories related to a query.",
  react: "🔍",
  category: "search",
  filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
  try {
    const config = await readEnv(); // Ensure `readEnv` retrieves the required configuration
    const query = args.join(' ') || "vajira"; // Default to "vajira" if no query is provided
    const language = config.LANGUAGE || "EN"; // Default to English if LANGUAGE is undefined
    const apiUrl = `${vishwa2}/misc/github-search?query=${query}&limit=30&sort=stars&order=desc&apikey=key1`;

    // Language dictionary
    const langDict = {
      EN: {
        noResults: "❌ No GitHub repositories found for the query.",
        resultsTitle: `*🔍 GitHub Search Results for '${query}'*:\n\n`,
        repoName: "📦 *Name:*",
        stars: "(⭐ {stars} stars)",
        description: "📝 *Description:*",
        owner: "👤 *Owner:*",
        url: "🔗 *Repository URL:*",
        language: "🌐 *Language:*",
        createdAt: "📅 *Created At:*",
        updatedAt: "📅 *Updated At:*",
        footer: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      },
      SI: {
        noResults: "❌ GitHub පරිපාලන වලින් ප්‍රතිපල හමුවී නැත.",
        resultsTitle: `*🔍 '${query}' සොයන්නාගේ GitHub ප්‍රතිපල*:\n\n`,
        repoName: "📦 *නම:*",
        stars: "(⭐ {stars} තාරකා)",
        description: "📝 *විස්තරය:*",
        owner: "👤 *හිමිකරු:*",
        url: "🔗 *ගිණුම:*",
        language: "🌐 *භාෂාව:*",
        createdAt: "📅 *සෑදූ දිනය:*",
        updatedAt: "📅 *යාවත්කාලීන දිනය:*",
        footer: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
      }
    };

    const lang = langDict[language] || langDict["EN"]; // Fallback to English if language is not found

    // Fetch the GitHub search results
    const response = await fetch(apiUrl);
    if (!response.ok) throw new Error(`API responded with status ${response.status}`);

    const data = await response.json();

    if (!data || !data.data || data.data.length === 0) {
      return reply(lang.noResults);
    }

    // Prepare the search results message
    let resultMessage = lang.resultsTitle;

    data.data.forEach(repo => {
      resultMessage += `${lang.repoName} ${repo.name} ${lang.stars.replace("{stars}", repo.stars)}\n`;
      resultMessage += `${lang.description} ${repo.description || "No description"}\n`;
      resultMessage += `${lang.owner} ${repo.owner.login} | ${repo.owner.url}\n`;
      resultMessage += `${lang.url} ${repo.url}\n`;
      resultMessage += `${lang.language} ${repo.language || "Not specified"}\n`;
      resultMessage += `${lang.createdAt} ${new Date(repo.createdAt).toLocaleString()}\n`;
      resultMessage += `${lang.updatedAt} ${new Date(repo.updatedAt).toLocaleString()}\n\n`;
    });

    resultMessage += lang.footer;

    // Send the search results
    await conn.sendMessage(from, {
      text: resultMessage,
      contextInfo: {
        externalAdReply: {
          title: "BHASHI-MD GitHub Search",
          body: "Your Ultimate Bot Assistant",
          sourceUrl: "https://github.com" // You can modify this URL if needed
        }
      }
    }, { quoted: mek });

  } catch (e) {
    console.error("Error:", e);
    const errorMessage = {
      SI: `🚫 GitHub ප්‍රතිපල ලබා ගැනීමේදී දෝෂයක් සිදු විය: ${e.message}`,
      EN: `🚫 An error occurred while fetching GitHub repositories: ${e.message}`
    };
    reply(errorMessage[language || "EN"]); // Default to English for error messages
  }
});

//=================================================================
cmd({
    pattern: "spotifys",
    desc: "Search Spotify songs by title.",
    category: "search",
    react: "🎵",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, config }) => {
    try {
        const lang = config?.LANGUAGE || "EN";

        const translations = {
            EN: {
                noQuery: "🔍 Please provide a song title to search. Example: `.spotifys Bad`",
                noResults: "🚫 No results found for your query.",
                searchResults: "🎵 *Spotify Search Results for:*",
                title: "🎬 *𝖳𝖺𝗍𝗂𝗅𝖾*",
                artist: "🖥️ *𝖠𝗋𝗍𝗂𝗌𝗍*",
                album: "📑 *𝖠𝗅𝖻𝗎𝗆*",
                duration: "⏰ *𝖣𝗎𝗋𝖺𝗍𝗂𝗈𝗇*",
                releaseDate: "📆 *𝖱𝖾𝗅𝖾𝖺𝗌𝖾𝖽*",
                spotifyLink: "🔗 *[Listen on Spotify]*",
                previewLink: "🎧 *[Preview Track]*",
                footer: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            },
            SI: {
                noQuery: "🔍 කරුණාකර සොයන ගීත මාතෘකාව ඇතුලත් කරන්න. උදා: `.spotifys Bad`",
                noResults: "🚫 ඔබේ විමසීමට ගැලපෙන මොකක්ද? ප්‍රතිඵල හමු නොවීය.",
                searchResults: "🎵 *Spotify හි සොයන ප්‍රතිඵලය:*",
                title: "*🎬 මාතෘකාව*",
                artist: "*🖥️ නිර්මාතෘ*",
                album: "*📑 ඇල්බමය*",
                duration: "*⏰ කාල සීමාව*",
                releaseDate: "*📆 නිකුත් කල දිනය*",
                spotifyLink: "*🔗 [Spotify තුළ අහන්න]*",
                previewLink: "*🎧 [ඉක්මන් නැරඹුම]*",
                footer: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            }
        };

        const T = translations[lang] || translations.EN;

        const query = args.join(' ');
        if (!query) {
            return reply(T.noQuery);
        }

        // Fetch Spotify Search Results
        const apiUrl = `https://api.nyxs.pw/dl/spotify-search?title=${encodeURIComponent(query)}`;
        const response = await axios.get(apiUrl);

        if (!response.data || !response.data.status || response.data.result.length === 0) {
            return reply(T.noResults);
        }

        // Extract first 5 results
        const results = response.data.result.slice(0, 5);

        let messageText = `${T.searchResults} _${query}_ 🎵\n\n`;

        for (const [index, track] of results.entries()) {
            messageText += `*${index + 1}. ${track.name}*\n`;
            messageText += `> ${T.artist}: ${track.artists}\n`;
            messageText += `> ${T.album}: ${track.album}\n`;
            messageText += `> ${T.duration}: ${track.duration}\n`;
            messageText += `> ${T.releaseDate}: ${track.releaseDate}\n`;
            messageText += `> ${T.spotifyLink}(${track.spotifyUrl})\n`;
            messageText += `> ${T.previewLink}(${track.previewUrl || "N/A"})\n\n`;
        }

        // Use the thumbnail from the first result
        const thumbnailUrl = results[0]?.thumbnail || null;

        if (thumbnailUrl) {
            await conn.sendMessage(from, {
                image: { url: thumbnailUrl },
                caption: `${messageText}\n\n${T.footer}`
            }, { quoted: mek });
        } else {
            await conn.sendMessage(from, {
                text: `${messageText}\n\n${T.footer}`
            }, { quoted: mek });
        }

    } catch (error) {
        console.error("Error fetching Spotify search results:", error);
        reply("⚠️ An error occurred while searching Spotify songs.");
    }
});

//================================================================
cmd({
    pattern: "lyrics",
    desc: "Fetches song information, a brief lyrics preview, and the album cover image.",
    react: "🎵",
    category: "search",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
    // Get the user's language preference
    const lang = config.LANGUAGE || 'EN';

    // Multi-language messages
    const noSongNameMsg = lang === 'SI' ? "කරුණාකර ගීතයේ නමක් ලබා දෙන්න. උදාහරණය: !lyrics Never Gonna Give You Up" : "Please provide a song name. Example: !lyrics Never Gonna Give You Up";
    const errorFetchingMsg = lang === 'SI' ? `❌ දෝෂයකි: ` : `❌ Error: `;
    const lyricsInfoHeader = lang === 'SI' ? `🎵 *ගීත තොරතුරු:* ☘️\n\n` : `🎵 *Lyrics Information:* ☘️\n\n`;
    const titleText = lang === 'SI' ? `🎤 *ශීර්ෂය:* ` : `🎤 *Title:* `;
    const artistText = lang === 'SI' ? `👨‍🎤 *කලාකරුවා:* ` : `👨‍🎤 *Artist:* `;
    const albumText = lang === 'SI' ? `💿 *අලබම්:* ` : `💿 *Album:* `;
    const lyricsPreviewText = lang === 'SI' ? `📜 *ගීත පෙළ පෙරහුරුව:*\n` : `📜 *Lyrics Preview:*\n`;
    const supportArtistText = lang === 'SI' ? `🎧 කරුණාකර ඔබේ ගීතය මිලදී ගැනීමට කලාකරුවාට සහය වන්න!\n\n` : `🎧 Please support the artist by purchasing their music!\n\n`;
    const footerText = `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

    // Check if song name is provided
    if (!args.join(" ")) return reply(noSongNameMsg);
    const songName = args.join(" ");

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Fetch the song information from the API
        const apiUrl = `https://api.popcat.xyz/lyrics?song=${encodeURIComponent(songName)}`;
        let response = await fetch(apiUrl);
        let data = await response.json();

        if (data.error) {
            return reply(`${errorFetchingMsg}${data.error}`);
        }

        // Prepare the message with song information, emojis, and formatting
        let message = lyricsInfoHeader;
        message += `${titleText}${data.title}\n`;
        message += `${artistText}${data.artist}\n`;
        message += `${albumText}${data.album || 'N/A'}\n\n`;
        message += `${lyricsPreviewText}"${data.lyrics}"\n\n`;
        message += supportArtistText;
        message += footerText;

        // Fetch the album cover image
        let imageBuffer;
        try {
            const imageResponse = await fetch(data.image);
            imageBuffer = await imageResponse.buffer();
        } catch (imageError) {
            console.log("Error fetching image:", imageError);
            imageBuffer = null;
        }

        // Send the formatted song information message with the album cover image
        if (imageBuffer) {
            await conn.sendMessage(from, { image: imageBuffer, caption: message }, { quoted: mek });
        } else {
            // If image fetch fails, send text only
            await conn.sendMessage(from, { text: message }, { quoted: mek });
        }
    } catch (e) {
        console.log(e);
        const errorMsg = `${errorFetchingMsg}${e.message}`;
        reply(errorMsg);
    }
});
//=================================================================
cmd({
    pattern: "npm",
    desc: "Fetch npm package details.",
    category: "search",
    react: "📦",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, config }) => {
    try {
        const config = await readEnv();
        const lang = config?.LANGUAGE || "EN";

        const translations = {
            EN: {
                notFound: "🚫 Package not found on npm.",
                packageTitle: "乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖭 𝖯 𝖬  𝖯 𝖪 𝖦  𝖲 𝖳 𝖠 𝖫 𝖪 𝖤 𝖱",
                packageDetails: "📁 𝖭𝗉𝗆 𝖯𝖺𝖼𝗄𝖺𝗀𝖾",
                description: "📰 𝖣𝖾𝗌𝖼𝗋𝗂𝗉𝗍𝗂𝗈𝗇",
                latestVersion: "📆 𝖫𝖺𝗍𝖾𝗌𝗍 𝖵𝖾𝗋𝗌𝗂𝗈𝗇",
                author: "🖥️ 𝖠𝗎𝗍𝗁𝗈𝗋",
                repository: "📻 𝖱𝖾𝗉𝗈𝗌𝗂𝗍𝗈𝗋𝗒",
                url: "🖇️ 𝖴𝗋𝗅"
            },
            SI: {
                notFound: "🚫 NPM හි package එකක් හමු නොවීය.",
                packageTitle: "乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖭 𝖯 𝖬  𝖯 𝖪 𝖦  𝖲 𝖳 𝖠 𝖫 𝖪 𝖤 𝖱",
                packageDetails: "📁 𝖭𝗉𝗆 පැකේජය",
                description: "📰 විස්තරය",
                latestVersion: "📆 යාවත්කාලිනය",
                author: "🖥️ අයිතුකරු",
                repository: "📻 ගබඩාව",
                url: "🖇️ පිවිසුම් ලින්කුව"
            }
        };

        const T = translations[lang] || translations.EN;

        const query = args.join(' ');
        if (!query) {
            return reply(`⚠️ Please provide a package name to search. Example: \`.npm axios\``);
        }

        const apiUrl = `https://registry.npmjs.org/${query}`;
        const response = await axios.get(apiUrl);

        if (!response.data) {
            return reply(T.notFound);
        }

        const data = response.data;
        const packageName = data.name || "N/A";
        const description = data.description || "N/A";
        const latestVersion = data["dist-tags"]?.latest || "N/A";
        const author = data.author?.name || "N/A";
        const repository = data.repository?.url || "N/A";
        const npmUrl = `https://www.npmjs.com/package/${packageName}`;

        const message = `
${T.packageTitle}

${T.packageDetails} : ${packageName}
${T.description} : ${description}
${T.latestVersion} : ${latestVersion}
${T.author} : ${author}
${T.repository} : ${repository}
${T.url} : ${npmUrl}

> ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2 | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        reply(message);
    } catch (error) {
        console.error("Error fetching npm package details:", error);
        reply("⚠️ An error occurred while fetching npm package details.");
    }
});
//============================================================
cmd({
  pattern: "npmsearch",
  alias: ["npms"],
  desc: "Search NPM packages related to a query.",
  react: "🔍",
  category: "search",
  filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
  try {
      const config = await readEnv();
    const query = args.join(' ') || "express"; // Fallback to "express" if no query provided
    const language = config.LANGUAGE; // Language set either to 'SI' or 'EN'
    const apiUrl = `${vishwa2}/misc/npm-search?query=${query}&limit=50&apikey=key1`;

    // Fetch the NPM search results
    const response = await fetch(apiUrl);
    const data = await response.json();

    if (!data || !data.data || data.data.length === 0) {
      const noResultsMessage = {
        SI: "❌ NPM පැකේජ සඳහා ප්‍රතිපල හමු වී නැත.",
        EN: "❌ No NPM packages found for the query."
      };
      return reply(noResultsMessage[language]);
    }

    let resultMessage = {
      SI: `*🔍 '${query}' සොයන්නාගේ NPM පැකේජ ප්‍රතිපල*:\n\n`,
      EN: `*🔍 NPM Search Results for '${query}'*:\n\n`
    };

    data.data.forEach(pkg => {
      resultMessage[language] += `📦 *${pkg.name}* (v${pkg.version})\n`;
      resultMessage[language] += `*📝 විස්තර >* ${pkg.description || "විස්තරයක් නොමැත"}\n`;
      resultMessage[language] += `*👤 ලේකකයා >* ${pkg.author || "නොදන්නා"} | ප්‍රකාශකයා: ${pkg.publisher || "නොදන්නා"}\n`;
      resultMessage[language] += `*📅 ප්‍රකාශය >* ${new Date(pkg.date).toLocaleString()}\n`;
      resultMessage[language] += `*🌟 ගුණාත්මකත්වය >* ${pkg.score.detail.quality.toFixed(2)} | ජනප්‍රියත්වය: ${pkg.score.detail.popularity.toFixed(2)} | නඩත්තු කිරීම: ${pkg.score.detail.maintenance.toFixed(2)}\n`;
      resultMessage[language] += `*🔗 NPM සම්බන්ධතාවය >* ${pkg.links.npm} | [Homepage](${pkg.links.homepage || pkg.links.repository})\n\n`;
    });

    resultMessage[language] += `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

    // Send the search result as a message
    await conn.sendMessage(from, {
      text: resultMessage[language],
          contextInfo: {
              forwardingScore: 999,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                  newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                  newsletterJid: "120363333519565664@newsletter",
              },
              externalAdReply: {
                  title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                  body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                  thumbnailUrl: botimg2,
                  sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                  mediaType: 1,
                  renderLargerThumbnail: false
              }
      }
    }, { quoted: mek });

  } catch (e) {
    console.log(e);
    const errorMessage = {
      SI: `🚫 NPM පැකේජ ලබා ගැනීමේදී දෝෂයක් සිදු විය: ${e.message}`,
      EN: `🚫 An error occurred while fetching NPM packages: ${e.message}`
    };
    reply(errorMessage[language]);
  }
});
//============================================================
cmd({
    pattern: "githubstalk",
    alias: ["gstalk", "gitstalk"],
    desc: "Fetch detailed GitHub user profile including profile picture.",
    category: "utility",
    react: "🖥️",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Get the language preference
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;

        // Multi-language messages
        const accessDeniedText = lang === 'SI' ? "*🚫 ඔබ කළු ලැයිස්තුවේ නාමාවලියට ගිහින් ඇත. ඇතුලත් වීමට අවසර නැහැ.*" : "*🚫 You are blacklisted. Access denied.*";
        const accessDeniedGeneral = lang === 'SI' ? "*😢 අයිතිකාරකම ලබා ගැනීමට ඔබට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!*" : "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*";
        const noUsernameText = lang === 'SI' ? "කරුණාකර GitHub භාවිතාකරු නාමයක් ලබා දෙන්න." : "Please provide a GitHub username.";
        const errorFetchingText = lang === 'SI' ? "දත්ත ලබා ගැනීමට දෝෂයක් ඇතිවිය." : "Error fetching data.";

        const username = args[0];
        if (!username) {
            return reply(noUsernameText);
        }

        const apiUrl = `https://api.github.com/users/${username}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        let userInfo = lang === 'SI'
            ? `     🔍 *BHASHI-MD GIT STALK* 🔎\n\n👤 *යූසර් නාමය*: ${data.name || data.login}\n🔗 *GitHub URL*:(${data.html_url})\n📝 *ජීවන රේඛාව*: ${data.bio || 'ලැබුණේ නැත'}\n🏙️ *ස්ථානය*: ${data.location || 'නිකන්'}\n📊 *සමූහ රෙපොස්*: ${data.public_repos}\n👥 *අනුග්‍රහකයන්*: ${data.followers} | අනුගමනය කරනවා: ${data.following}\n📅 *හදවතට*: ${new Date(data.created_at).toDateString()}\n🔭 *පොදු ගිස්ට්ස්*: ${data.public_gists}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            : `     🔍 *BHASHI-MD GIT STALK* 🔎\n\n👤 *Username*: ${data.name || data.login}\n🔗 *Github Url*:(${data.html_url})\n📝 *Bio*: ${data.bio || 'Not available'}\n🏙️ *Location*: ${data.location || 'Unknown'}\n📊 *Public Repos*: ${data.public_repos}\n👥 *Followers*: ${data.followers} | Following: ${data.following}\n📅 *Created At*: ${new Date(data.created_at).toDateString()}\n🔭 *Public Gists*: ${data.public_gists}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        await conn.sendMessage(from, { image: { url: data.avatar_url }, caption: userInfo }, { quoted: mek });
    } catch (e) {
        console.log(e);
        reply(errorFetchingText);
    }
});
//===============================================================
cmd({
    pattern: "color",
    desc: "Fetches a color and sends it as a message.",
    react: "🎨",
    category: "information",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
    // Define multilingual messages
    const messages = {
        noColorCode: {
            SI: "කරුණාකර පැහැය කේතයක් ලබා දෙන්න (ආදර්ශය: #ffcc99).",
            EN: "Please provide a color code in hex format (e.g., #ffcc99)."
        },
        blacklisted: {
            SI: "*🚫 ඔබ අසාදු ලේඛනගත කර ඇත. ප්‍රවේශය ප්‍රතික්ෂේප විය.*",
            EN: "*🚫 You are blacklisted. Access denied.*"
        },
        accessDenied: {
            SI: "*😢 ප්‍රවේශය ප්‍රතික්ෂේප විය. මෙම විධානය භාවිතා කිරීමට ඔබට අවසර නැත.🎁 බොට් මාදිලිය වෙනස් කරන්න!*",
            EN: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*"
        },
        invalidColor: {
            SI: "පාඨය කේතය ගෙන නොහැකි විය.",
            EN: "Unable to retrieve color information."
        },
        colorInfo: {
            SI: `🎨 මෙන්න පැහැය පිළිබඳ විස්තර:\n\n🎨*පැහැය කේතය:* #`,
            EN: `🎨 Here is the color information:\n\n🎨*Color Code:* #`
        },
        footer: {
            SI: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            EN: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        },
        error: {
            SI: "😔 දෝෂයක් ඇති විය: ",
            EN: "😔 An error occurred: "
        }
    };

    // Check if color code is provided
    if (!args[0]) return reply(messages.noColorCode[config.LANGUAGE.toUpperCase()]);

    const colorCode = args[0].replace('#', ''); // Remove the hash from the color code

    try {
        const senderNumber = m.sender;
        const isGroup = m.isGroup || false;
        const lang = config.LANGUAGE.toUpperCase(); // Adjust to match your message object keys
        // Fetch the color information from the API
        const response = await fetch(`https://api.popcat.xyz/color/${colorCode}`);
        const data = await response.json();

        // Check if the color data is valid
        if (!data || !data.color_image) {
            return reply(messages.invalidColor[lang]);
        }

        // Fetch the color image
        const imageResponse = await fetch(data.color_image);
        const imageBuffer = await imageResponse.buffer();

        // Prepare the color message
        const colorMessage = `${messages.colorInfo[lang]}${data.hex}\n` +
            `🎨 *Color Name:* ${data.name}\n` +
            `🎨 *RGB Value:* ${data.rgb}\n` +
            `🎨 *Brightened Color:* ${data.brightened}\n\n` +
            messages.footer[lang];

        // Send the color image and details
        await conn.sendMessage(from, { image: imageBuffer, caption: colorMessage }, { quoted: mek });

    } catch (e) {
        console.log(e);
        reply(`${messages.error[lang]}${e.message}`);
    }
});
//================================================================
cmd({
    pattern: "yts",
    desc: "Search YouTube videos.",
    category: "search",
    react: "🎥",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        const query = args.join(' ');

        if (!query) {
            return reply("🔍 Please provide a search term. Example: `.yts coding tutorials`");
        }

        // Perform a YouTube search
        const searchResults = await yts(query);

        if (!searchResults || !searchResults.videos || searchResults.videos.length === 0) {
            return reply("🚫 No results found for your query.");
        }

        // Extract the first 5 search results
        const results = searchResults.videos.slice(0, 30);

        // Construct the reply message
        let messageText = `🎥 *YouTube Search Results for:* _${query}_ 🎥\n\n`;

        results.forEach((video, index) => {
            messageText += `*${index + 1}. ${video.title}*\n`;
            messageText += `> 🕒 Duration: ${video.timestamp}\n`;
            messageText += `> 👤 Channel: ${video.author.name}\n`;
            messageText += `> 🔗 [Watch Now](${video.url})\n\n`;
        });

        // Send the message
        await conn.sendMessage(from, { text: messageText }, { quoted: mek });

    } catch (error) {
        console.error("Error fetching YouTube search results:", error);
        reply("⚠️ An error occurred while searching for YouTube videos.");
    }
});

//===============================================
cmd({
    pattern: "srepo",
    desc: "Fetch information about a GitHub repository.",
    category: "search",
    react: "📁",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const messages = {
        noRepo: "Please provide a GitHub repository name in the format `owner/repo`.",
        repoNotFound: "Error: Repository not found. Please check the owner/repo format.",
        fetchError: "Error: Unable to fetch repository information. Please try again later.",
        repoDetailsHeader: "📁 _*GitHub Repository Info*_ 📁\n\n",
        repoName: "📌 *Name*: ",
        repoURL: "🔗 *URL*: ",
        repoDescription: "📝 *Description*: ",
        repoStars: "⭐ *Stars*: ",
        repoForks: "🍴 *Forks*: ",
        repoOwner: "🧑‍💻 *Owner*: ",
        repoLanguage: "🛠️ *Primary Language*: ",
        repoCreatedOn: "📅 *Created on*: ",
        repoLicense: "📜 *License*: ",
        footer: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
        error: "🚫 An error occurred: "
    };

    try {
        const repoLink = args.join(' ');

        if (!repoLink) {
            return reply(messages.noRepo);
        }

        // Extract owner/repo from input
        const repo = repoLink.match(/([^\/]+\/[^\/]+)/)?.[0];
        if (!repo) {
            return reply(messages.noRepo);
        }

        const [owner, repository] = repo.split('/');

        // API endpoint
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/github-repo-info`;
        const response = await axios.get(apiUrl, {
            params: {
                owner,
                repo: repository,
                apikey: 'key1'
            }
        });

        const data = response.data;

        if (!data || data.status !== "success" || !data.data) {
            return reply(messages.repoNotFound);
        }

        const repoData = data.data;

        // Construct repository information message
        let repoInfo = `${messages.repoDetailsHeader}`;
        repoInfo += `${messages.repoName}${repoData.name || "N/A"}\n`;
        repoInfo += `${messages.repoURL}${repoData.url || "N/A"}\n`;
        repoInfo += `${messages.repoDescription}${repoData.description || "No description provided"}\n`;
        repoInfo += `${messages.repoStars}${repoData.stars || 0}\n`;
        repoInfo += `${messages.repoForks}${repoData.forks || 0}\n`;
        repoInfo += `${messages.repoOwner}${repoData.owner?.login || "N/A"}\n`;
        repoInfo += `${messages.repoLanguage}${repoData.language || "Not specified"}\n`;
        repoInfo += `${messages.repoCreatedOn}${new Date(repoData.createdAt).toLocaleDateString()}\n`;
        repoInfo += `${messages.repoLicense}${repoData.license?.name || "No license specified"}\n`;
        repoInfo += `\n${messages.footer}`;

        // Sending the repository owner's avatar as an image
        const avatarUrl = repoData.owner?.avatarUrl || '';
        await conn.sendMessage(from, {
            image: { url: avatarUrl },
            caption: repoInfo
        }, { quoted: mek });

    } catch (e) {
        console.error(e);
        reply(`${messages.error}${e.message}`);
    }
});

//================================================================

//================================================================
cmd({
    pattern: "tech",
    desc: "Get random technology facts or latest tech news with images.",
    category: "search",
    react: "💻",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    const messages = {
        EN: {
            accessDenied: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*",
            blacklisted: "*🚫 You are blacklisted. Access denied.*",
            techFact: `🖥️ Tech Fact of the Day:\n\n{{fact}}`,
            breakingNews: `*📰 Breaking Tech News 🚨*\n\n🔥 {{title}}\n\n📝 {{description}}\n\n*🔗 Read more:* {{url}}\n\n\n> {{footer}}`,
        },
        SI: {
            accessDenied: "*😢 ප්‍රවේශය ප්‍රතික්ෂේපිතයි. මෙම විධානය භාවිතා කිරීමට ඔබට අනුමැතිය නැත.🎁 Bot ආකාරය වෙනස් කරන්න!*",
            blacklisted: "*🚫 ඔබට වළක්වනු ලැබුණි. ප්‍රවේශය ප්‍රතික්ෂේපිතයි.*",
            techFact: `🖥️ අද දිනයේ තාක්ෂණ සත්‍යය:\n\n{{fact}}`,
            breakingNews: `*📰 දැන් සිටින තාක්ෂණය 🚨*\n\n🔥 {{title}}\n\n📝 {{description}}\n\n*🔗 තවත් කියවන්න:* {{url}}\n\n\n> {{footer}}`,
        }
    };
    try {
        const config = await readEnv();
        const senderNumber = m.sender;

        // Choose between tech fact or news with 70% chance for news
        const choice = Math.random() < 0.7 ? 'news' : 'fact';

        let message;
        let image = { url: botimg};  // Default to ALIVE_IMG

        if (choice === 'fact') {
            // Array of technology facts with emojis
            const techFacts = [
                "🦠 The first computer virus was created in 1983.",
                "🖱️ The first computer mouse was made of wood.",
                "⌨️ The QWERTY keyboard layout was designed to slow typing speed.",
                "📷 The first webcam was created to check the status of a coffee pot.",
                "💰 About 90% of the world's currency is digital.",
                "👩‍💻 The first computer programmer was a woman named Ada Lovelace.",
                "🏋️ The first electronic computer ENIAC weighed more than 27 tons.",
                "💾 The first hard drive could store just 5 MB of data.",
                "🌐 More than 570 new websites are created every minute.",
                "🎮 The first computer game was created in 1961."
            ];

            const randomFact = techFacts[Math.floor(Math.random() * techFacts.length)];
            message = messages[config.LANGUAGE].techFact.replace("{{fact}}", randomFact);
        } else {
            // Fetch latest tech news
            const response = await axios.get('https://newsapi.org/v2/top-headlines', {
                params: {
                    country: 'us',
                    category: 'technology',
                    apiKey: '0f2c43ab11324578a7b1709651736382'  // Moved to config for better security
                }
            });

            const newsItem = response.data.articles[0];
            message = messages[config.LANGUAGE].breakingNews
                .replace("{{title}}", newsItem.title)
                .replace("{{description}}", newsItem.description)
                .replace("{{url}}", newsItem.url)
                .replace("{{footer}}", `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);

            // Use news image if available, otherwise keep ALIVE_IMG
            if (newsItem.urlToImage) {
                image = { url: newsItem.urlToImage };
            }
        }

        // Send the tech message with image
        await conn.sendMessage(from, { 
            image: image,
            caption: message
        }, { quoted: mek });

    } catch(e) {
        console.error(e);
        reply(`🚫 Oops! Something went wrong: ${e.message}`);
    }
});
//================================================================
cmd({
    pattern: "wiki", 
    desc: "Search Wikipedia and get a summary.", 
    category: 'search', 
    react: '📚', 
    filename: __filename 
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        const config = await readEnv();
   
        // Check if a search term is provided
        if (args.length < 1) {
            const noSearchTermMessage = config.LANGUAGE === 'SI' 
                ? "කරුණාකර සෙවීම් පදයක් ලබාදෙන්න." 
                : "Please provide a search term.";
            return reply(noSearchTermMessage);
        }

        const searchTerm = args.join(" ");
        const wikiApiUrl = "https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(searchTerm);

        // Fetch data from Wikipedia
        const response = await axios.get(wikiApiUrl);
        const { extract, title } = response.data;

        // Construct response text
        const responseText = (lang) => lang === 'SI' 
            ? `*🛸 විකිපීඩියා සෙවීම:* *${title}* - ${extract}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            : `*🛸 Wiki Search* *"${title}"* - ${extract}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        // Send the response in the appropriate language
        await conn.sendMessage(from, { text: responseText(config.LANGUAGE) }, { quoted: mek });
    } catch (error) {
        console.error(error);
        const errorMessage = config.LANGUAGE === 'SI' 
            ? "විකිපීඩියා සෙවීමේදී දෝෂයක් ඇති විය." 
            : "An error occurred while searching Wikipedia.";
        await reply(errorMessage);
    }
});
//================================================================



//===============================================================









//==========================-A.I. COMMANDS-=====================
//================================================================
//================================================================
cmd({
    pattern: "letmegpt",
    desc: "Chat with LetMeGPT AI for various topics.",
    react: "🤖",
    category: "AI",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    const config = await readEnv();
    try {
        // Check if the user has provided a query
        if (!q) {
            return reply(config.LANGUAGE === 'SI' 
                ? "කරුණාකර ප්‍රශ්නයක් හෝ යමක් ඇතුළත් කරන්න." 
                : "Please enter a question or message.");
        }

        // Fetch LetMeGPT response from the API
        const apiUrl = `https://www.dark-yasiya-api.site/ai/letmegpt?q=${encodeURIComponent(q)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        // Check if the response is successful
        if (!data.status) {
            return reply(config.LANGUAGE === 'SI' 
                ? "සමාවන්න, දෝෂයක් සිදු විය." 
                : "Sorry, an error occurred.");
        }

        // Construct and send the response message
        const responseMessage = `*🤖 LetMeGPT*\n\n ${data.result}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;
        return reply(responseMessage);
    } catch (e) {
        console.log(e);
        const errorMessage = config.LANGUAGE === 'SI' 
            ? `දෝෂයක්: ${e.message || 'අපට පැමිණුණු දෝෂයක් ඇත.'}` 
            : `Error: ${e.message || 'An error occurred.'}`;
        return reply(errorMessage);
    }
});

//=================================================================
cmd({
    pattern: "goodyai",
    desc: "Chat with GoodyAI for various topics.",
    react: "🤖",
    category: "AI",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    const config = await readEnv();
    try {
        // Check if the user has provided a query
        if (!q) {
            return reply(config.LANGUAGE === 'SI' 
                ? "කරුණාකර ප්‍රශ්නයක් හෝ යමක් ඇතුළත් කරන්න." 
                : "Please enter a question or message.");
        }

        // Fetch GoodyAI response from the API
        const apiUrl = `https://www.dark-yasiya-api.site/ai/goodyai?q=${encodeURIComponent(q)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        // Check if the response is successful
        if (!data.status) {
            return reply(config.LANGUAGE === 'SI' 
                ? "සමාවන්න, දෝෂයක් සිදු විය." 
                : "Sorry, an error occurred.");
        }

        // Construct and send the response message
        const responseMessage = `*🤖 GoodyAI*\n\n ${data.result}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;
        return reply(responseMessage);
    } catch (e) {
        console.log(e);
        const errorMessage = config.LANGUAGE === 'SI' 
            ? `දෝෂයක්: ${e.message || 'අපට පැමිණුණු දෝෂයක් ඇත.'}` 
            : `Error: ${e.message || 'An error occurred.'}`;
        return reply(errorMessage);
    }
});

//===============================================================
cmd({
    pattern: "gemini",
    desc: "Chat with Gemini AI.",
    react: "✨",
    category: "AI",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    const config = await readEnv();
    try {
        // Check if the user has provided a query
        if (!q) {
            return reply(config.LANGUAGE === 'SI' 
                ? "කරුණාකර ප්‍රශ්නයක් හෝ යමක් ඇතුළත් කරන්න." 
                : "Please enter a question or message.");
        }

        // Fetch Gemini AI response from the new API
        const apiUrl = `https://www.dark-yasiya-api.site/ai/gemini?q=${encodeURIComponent(q)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        // Check if the response is successful
        if (!data.status) {
            return reply(config.LANGUAGE === 'SI' 
                ? "සමාවන්න, දෝෂයක් සිදු විය." 
                : "Sorry, an error occurred.");
        }

        // Construct and send the response message
        const responseMessage = `*✨ Gemini AI*\n\n ${data.result}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;
        return reply(responseMessage);
    } catch (e) {
        console.log(e);
        const errorMessage = config.LANGUAGE === 'SI' 
            ? `දෝෂයක්: ${e.message || 'අපට පැමිණුණු දෝෂයක් ඇත.'}` 
            : `Error: ${e.message || 'An error occurred.'}`;
        return reply(errorMessage);
    }
});
//=================================================================
cmd({
    pattern: "chatgpt",
    desc: "Chat with GPT.",
    react: "🤖",
    category: "AI",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    const config = await readEnv();
    try {
        // Check if the user has provided a query
        if (!q) {
            return reply(config.LANGUAGE === 'SI' 
                ? "කරුණාකර ප්‍රශ්නයක් හෝ යමක් ඇතුළත් කරන්න." 
                : "Please enter a question or message.");
        }

        // Fetch AI response from the new API
        const apiUrl = `https://www.dark-yasiya-api.site/ai/chatgpt?q=${encodeURIComponent(q)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        // Check if the response is successful
        if (!data.status) {
            return reply(config.LANGUAGE === 'SI' 
                ? "සමාවන්න, දෝෂයක් සිදු විය." 
                : "Sorry, an error occurred.");
        }

        // Construct and send the response message
        const responseMessage = `*🤖 ChatGPT*\n\n ${data.result}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;
        return reply(responseMessage);
    } catch (e) {
        console.log(e);
        const errorMessage = config.LANGUAGE === 'SI' 
            ? `දෝෂයක්: ${e.message || 'අපට පැමිණුණු දෝෂයක් ඇත.'}` 
            : `Error: ${e.message || 'An error occurred.'}`;
        return reply(errorMessage);
    }
});

//===============================================================

cmd({
    pattern: "llama",
    desc: "Get a response from the Llama AI.",
    react: "🦙",
    category: "AI",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    const config = await readEnv();
    try {

        // If no text provided, show an error
        if (!q || q.trim() === "") {
            return reply(config.LANGUAGE === 'SI' ? "❌ කරුණාකර Llama AI සඳහා පෙළක් ලබා දෙන්න." : "❌ Please provide a text prompt for the Llama AI.");
        }

        // Fetch response from the Llama API
        const apiUrl = `https://api.gurusensei.workers.dev/llama?prompt=${encodeURIComponent(q.trim())}`;
        const response = await fetch(apiUrl);

        // Check if response is OK
        if (!response.ok) {
            return reply(config.LANGUAGE === 'SI' ? "⚠️ API එකෙන් දත්ත ලබා ගැනීමට දෝෂයක්. කරුණාකර පසුව උත්සහ කරන්න." : "⚠️ Error fetching data from the API. Please try again later.");
        }

        const data = await response.json();

        // Check if the response is valid and extract the relevant text
        if (data && data.response && data.response.response) {
            return reply(`🦙 *LLAMA A.I*\n\n${data.response.response}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
        } else {
            return reply(config.LANGUAGE === 'SI' ? "⚠️ කණගාටුයි, Llama AI පිළිතුරක් ලබා ගැනීමට නොහැකි විය." : "⚠️ Sorry, I couldn't get a response from the Llama AI. Please try again later.");
        }
    } catch (e) {
        console.log(e);
        reply(config.LANGUAGE === 'SI' ? `දෝෂයක් ඇතිවී ඇත: ${e.message}` : `An error occurred: ${e.message}`);
    }
});

//=============================================================
cmd({
    pattern: "mistral",
    desc: "Get a response from the Mistral AI.",
    react: "🌬️",
    category: "AI",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    try {
        const config = await readEnv();
        // If no text provided, show an error
        if (!q || q.trim() === "") {
            return reply(config.LANGUAGE === 'SI' 
                ? "❌ කරුණාකර Mistral AI සඳහා පෙළක් ඇතුළත් කරන්න." 
                : "❌ Please provide a text prompt for the Mistral AI.");
        }

        // Fetch response from the Mistral API
        const apiUrl = `https://api.gurusensei.workers.dev/mistral?text=${encodeURIComponent(q.trim())}`;
        const response = await fetch(apiUrl);

        // Check if response is OK
        if (!response.ok) {
            return reply(config.LANGUAGE === 'SI' 
                ? "⚠️ API වෙතින් දත්ත ලබා ගැනීමේ දෝෂයකි. කරුණාකර නැවත උත්සාහ කරන්න." 
                : "⚠️ Error fetching data from the API. Please try again later.");
        }

        const data = await response.json();

        // Check if the response is valid and extract the relevant text
        if (data && data.response && data.response.response) {
            return reply(config.LANGUAGE === 'SI' 
                ? `🌬️ *MISTRAL A.I*\n\n${data.response.response}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` 
                : `🌬️ *MISTRAL A.I*\n\n${data.response.response}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
        } else {
            return reply(config.LANGUAGE === 'SI' 
                ? "⚠️ කනගාටුයි, Mistral AI වෙතින් ප්‍රතිචාරයක් ලබා ගත නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න." 
                : "⚠️ Sorry, I couldn't get a response from the Mistral AI. Please try again later.");
        }
    } catch (e) {
        console.log(e);
        reply(config.LANGUAGE === 'SI' 
            ? `දෝෂයක් සිදු විය: ${e.message}` 
            : `An error occurred: ${e.message}`);
    }
});
//=============================================================
cmd({
    pattern: "ai",
    desc: "AI chat.",
    react: "✔",
    category: "AI",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    const config = await readEnv();
    try {
        if (!q) {
            return reply(config.LANGUAGE === 'SI' 
                ? "කරුණාකර ප්‍රශ්නයක් හෝ යමක් ඇතුළත් කරන්න." 
                : "Please enter a question or message.");
        }

        let data = await fetchJson(`https://chatgptforprabath-md.vercel.app/api/gptv1?q=${encodeURIComponent(q)}`);

        // Remove the unwanted text from the response
        let responseMessage = data.data.replace("Generated by BLACKBOX.AI, try unlimited chat https://www.blackbox.ai", "");

        return reply(`🛫 CHATGPT A.I.\n\n${responseMessage}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
    } catch (e) {
        console.log(e);
        const errorMessage = config.LANGUAGE === 'SI' 
            ? `දෝෂයක්: ${e.message || 'අපට පැමිණුණු දෝෂයක් ඇත.'}` 
            : `Error: ${e.message || 'An error occurred.'}`;
        return reply(errorMessage);
    }
});

//==========================-CONEVRTER COMMANDS-=====================

//================================================================

//================================================================

//================================================================

//=================================================================
cmd({
    pattern: "sha256encode",  // Command trigger
    desc: "Convert text to SHA256 hash",  // Description of the command
    react: "🔐",  // Emoji for reacting to the command
    category: "converter",  // Category for the command
    filename: __filename  // File name containing the command
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        // Get the user's text to hash
        const textToHash = args.join(" ");
        if (!textToHash) {
            // If no text is provided, return an error message
            return reply("⚠️ Please provide text to convert into SHA256 hash. Example: `.sha256 Hello World!`");
        }

        // Convert the text to SHA256 hash
        const crypto = require('crypto');
        const sha256Hash = crypto.createHash('sha256').update(textToHash).digest('hex');

        // Send the SHA256 hash result with formatting
        return reply(`💡 *SHA256 Hash Complete!*\n\n✨ Here's the SHA256 hash of your input:\n\n\`\`\`${sha256Hash}\`\`\`\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
    } catch (error) {
        console.error(error);
        return reply("⚠️ An error occurred while processing the request. Please try again later.");
    }
});

//===============================================================
cmd({
    pattern: "shorturl",
    desc: "Create a short URL using TinyURL API.",
    category: "utility",
    filename: __filename
}, async (conn, mek, m, { from, reply, q }) => {
    try {
        const config = await readEnv();
        const messages = {
            EN: {
                accessDenied: "*😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!*",
                blacklisted: "*🚫 You are blacklisted. Access denied.*",
                urlRequired: "⚠️ Please provide a URL to shorten.",
                originalUrl: "🌐 *Original URL:*",
                shortenedUrl: "✂️ *Shortened URL:*",
                successMessage: "You can now use this short URL to share your link more easily! 🌟",
                error: "❌ An error occurred while shortening the URL: ",
            },
            SI: {
                accessDenied: "*😢 ප්‍රවේශය ප්‍රතික්ෂේපිතයි. මෙම විධානය භාවිතා කිරීමට ඔබට අනුමැතිය නැත.🎁 Bot ආකාරය වෙනස් කරන්න!*",
                blacklisted: "*🚫 ඔබට වළක්වනු ලැබුණි. ප්‍රවේශය ප්‍රතික්ෂේපිතයි.*",
                urlRequired: "⚠️ කෙටි URL එකක් සාදා ගැනීමට URL එකක් ලබා දෙන්න.",
                originalUrl: "🌐 *මුල් URL:*",
                shortenedUrl: "✂️ *කෙටි URL:*",
                successMessage: "ඔබට දැන් මෙම කෙටි URL එක භාවිතා කර ඔබේ සබැඳිය ලේසියෙන් බෙදා ගත හැක! 🌟",
                error: "❌ URL එක කෙටි කිරීමට දෝෂයක් සිදුවිය: ",
            }
        };

        if (!q) return reply(messages[config.LANGUAGE].urlRequired);

        const longUrl = q.trim();
        const apiUrl = `https://tinyurl.com/api-create.php?url=${encodeURIComponent(longUrl)}`;

        const response = await axios.get(apiUrl);
        const shortUrl = response.data;

        const resultMessage = `
🔗 *URL Shortener*

${messages[config.LANGUAGE].originalUrl} ${longUrl}
${messages[config.LANGUAGE].shortenedUrl} ${shortUrl}

${messages[config.LANGUAGE].successMessage}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
        `;

        await conn.sendMessage(from, { text: resultMessage }, { quoted: mek });
    } catch (e) {
        console.error('Error shortening URL:', e.message);
        reply(`${messages[config.LANGUAGE].error}${e.message}`);
    }
});

//=================================================================
cmd({
    pattern: "trt",
    alias: ["translate"],
    desc: "🌍 Translate text between languages",
    react: "🌐",
    category: "converter",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; // Get the language preference

        const noArgsText = lang === 'SI' ? "❗ කරුණාකර භාෂා කේතයක් සහ පෙළක් ලබා දෙන්න. භාවිතය: .trt [භාෂා කේතය] [පෙළ]" : "❗ Please provide a language code and text. Usage: .trt [language code] [text]";
        const errorText = lang === 'SI' ? "⚠️ පෙළ පරිවර්තනය කරන විට දෝෂයක් සිදුවිය. කරුණාකර පසුගිය කරුණා කරන්න." : "⚠️ An error occurred while translating the text. Please try again later.";

        const args = q.split(' ');
        if (args.length < 2) return reply(noArgsText);

        const targetLang = args[0];
        const textToTranslate = args.slice(1).join(' ');

        // Prepare the URL for translation API
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(textToTranslate)}&langpair=en|${targetLang}`;

        const response = await axios.get(url);
        const translation = response.data.responseData.translatedText;

        // Construct the translation message
        const translationMessage = lang === 'SI' ? `
🌍 *පරිවර්තනය* 🌍

🔤 *මූලිකය*: ${textToTranslate}
🔠 *පරිවර්තනය කළේ*: ${translation}
🌐 *භාෂාව*: ${targetLang.toUpperCase()}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        : `
🌍 *Translation* 🌍

🔤 *Original*: ${textToTranslate}
🔠 *Translated*: ${translation}
🌐 *Language*: ${targetLang.toUpperCase()}

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        return reply(translationMessage);
    } catch (e) {
        console.log(e);
        return reply(errorText);
    }
});
//================================================================
cmd({
    pattern: "convert",
    desc: "Convert an amount from one currency to another.",
    category: "converter",
    react: "💱",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
    const langConfig = {
        EN: {
            accessDenied: "😢 Access denied. You don't have permission to use this command.🎁 Change Bot Mode!",
            blacklisted: "🚫 You are blacklisted. Access denied.",
            invalidAmount: "Please provide a valid amount.",
            conversionUsage: "Usage: .convert <amount> <from_currency> <to_currency>",
            conversionRateNotFound: (currency) => `Conversion rate for ${currency} not found.`,
            conversionInfo: (amount, fromCurrency, convertedAmount, toCurrency, rate) =>
                `💸_*Currency Conversion*_💸\n\n💵 *Amount*: ${amount} ${fromCurrency}\n🔄 *Converted Amount*: ${convertedAmount} ${toCurrency}\n📈 *Exchange Rate*: 1 ${fromCurrency} = ${rate} ${toCurrency}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            mathExpression: (expression) => `📊 *Math Expression:* ${expression}`,
            mathResult: (result) => `✅ *Result:* ${result}`,
            invalidMathExpression: "❌ Invalid mathematical expression. Please check your input and try again.",
            errorFetchingData: (message) => `Error fetching data: ${message}`,
        },
        SI: {
            accessDenied: "😢 ඔබට මෙම විධානය භාවිතා කිරීමට අවසර නැත.🎁 බොට් ක්‍රමය වෙනස් කරන්න!",
            blacklisted: "🚫 ඔබට මාරු කර ඇත. ප්‍රවේශය ප්‍රහාර කලා.",
            invalidAmount: "කරුණාකර වලංගු මුදලක් ලබා දෙන්න.",
            conversionUsage: "භාවිතය: .convert <මුදල> <from_currency> <to_currency>",
            conversionRateNotFound: (currency) => `${currency} සඳහා මාරු අනුපාතය සොයා ගත නොහැක.`,
            conversionInfo: (amount, fromCurrency, convertedAmount, toCurrency, rate) =>
                `💸_*මුදල් මාරු*_💸\n\n💵 *මුදල*: ${amount} ${fromCurrency}\n🔄 *මාරු කරන ලද මුදල*: ${convertedAmount} ${toCurrency}\n📈 *මාරු අනුපාතය*: 1 ${fromCurrency} = ${rate} ${toCurrency}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            mathExpression: (expression) => `📊 *ගණිත ප්‍රකාශය:* ${expression}`,
            mathResult: (result) => `✅ *ප්‍රතිඵල:* ${result}`,
            invalidMathExpression: "❌ වැරදි ගණිත ප්‍රකාශය. කරුණාකර ඔබගේ ඇතුලත්කිරීම් පරීක්ෂා කරන්න සහ නැවත උත්සාහ කරන්න.",
            errorFetchingData: (message) => `දත්ත ලබා ගැනීමට ඇති දෝෂය: ${message}`,
        },
    };
    const lang = config.LANGUAGE || 'EN'; // Set language preference
    const language = langConfig[lang];

    try {
        const amount = args[0];
        const fromCurrency = args[1].toUpperCase();
        const toCurrency = args[2].toUpperCase();

        if (isNaN(amount)) {
            return reply(language.invalidAmount);
        }

        const apiUrl = `https://api.exchangerate-api.com/v4/latest/${fromCurrency}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (!data.rates[toCurrency]) {
            return reply(language.conversionRateNotFound(toCurrency));
        }

        const convertedAmount = (amount * data.rates[toCurrency]).toFixed(2);
        const conversionInfo = language.conversionInfo(amount, fromCurrency, convertedAmount, toCurrency, data.rates[toCurrency]);

        await conn.sendMessage(from, { text: conversionInfo }, { quoted: mek });
    } catch (e) {
        console.log(e);
        reply(language.errorFetchingData(e.message));
    }
});
//================================================================
cmd({
    pattern: "sticker",
    react: "🔮",
    alias: ["s", "stic"],
    category: "converter",
    use: '.sticker <Reply to image>',
    filename: __filename
},
async (conn, mek, m, { from, quoted, pushname, reply }) => {
    const config = await readEnv();
    const language = config.LANGUAGE || 'EN'; // Set default language to 'EN'

    try {
        // Check if the message is a quoted image or video
        const isQuotedImage = quoted ? (quoted.type === 'imageMessage' || (quoted.type === 'viewOnceMessage' && quoted.msg.type === 'imageMessage')) : false;
        const isQuotedSticker = quoted ? (quoted.type === 'stickerMessage') : false;

        let name;
        if ((m.type === 'imageMessage') || isQuotedImage) {
            name = getRandom('.jpg');
            const imageBuffer = isQuotedImage ? await quoted.download() : await m.download();
            await fs.promises.writeFile(name, imageBuffer); // Save the image temporarily
        } else if (isQuotedSticker) {
            name = getRandom('.webp');
            const stickerBuffer = await quoted.download();
            await fs.promises.writeFile(name, stickerBuffer); // Save the sticker temporarily
        } else {
            const noImageMessage = {
                SI: "❌ කරුණාකර රූපයක් පිළිතුරු කරන්න.",
                EN: "❌ Please reply to an image."
            };
            return reply(noImageMessage[language]);
        }

        // Create sticker from the downloaded image or sticker
        let sticker = new Sticker(name, {
            pack: pushname, // The pack name
            author: 'ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2 | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ', // The author name
            type: (m.q && (m.q.includes("--crop") || m.q.includes('-c'))) ? StickerTypes.CROPPED : StickerTypes.FULL,
            categories: ["🤩", "🎉"], // The sticker category
            id: "12345", // The sticker id
            quality: 75, // The quality of the output file
            background: "transparent", // The sticker background color (only for full stickers)
        });

        const buffer = await sticker.toBuffer();
        await conn.sendMessage(from, { sticker: buffer }, { quoted: mek });

    } catch (e) {
        const errorMessage = {
            SI: "🚫 දෝෂයක් සිදු විය!",
            EN: "🚫 An error occurred!"
        };
        reply(errorMessage[language]);
        console.log(e);
    }
});
//================================================================
const morseCodeMap = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.',
    'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.',
    'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-', 'U': '..-',
    'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--', 'Z': '--..', '1': '.----',
    '2': '..---', '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...',
    '8': '---..', '9': '----.', '0': '-----', ' ': '/'
};
function encodeToMorse(text) {
    return text.toUpperCase().split('').map(char => morseCodeMap[char] || char).join(' ');
}
// Function to decode Morse code to text
function decodeFromMorse(morseCode) {
    const morseCodeMap = {
        '.-': 'A', '-...': 'B', '-.-.': 'C', '-..': 'D', '.': 'E',
        '..-.': 'F', '--.': 'G', '....': 'H', '..': 'I', '.---': 'J',
        '-.-': 'K', '.-..': 'L', '--': 'M', '-.': 'N', '---': 'O',
        '.--.': 'P', '--.-': 'Q', '.-.': 'R', '...': 'S', '-': 'T',
        '..-': 'U', '...-': 'V', '.--': 'W', '-..-': 'X', '-.--': 'Y',
        '--..': 'Z', '-----': '0', '.----': '1', '..---': '2', '...--': '3',
        '....-': '4', '.....': '5', '-....': '6', '--...': '7', '---..': '8',
        '----.': '9', '/': ' ' // space in Morse code
    };

    return morseCode.split(' ').map(code => morseCodeMap[code] || '').join(''); // Decode each Morse code character
}

cmd({
    pattern: 'morse',
    desc: 'Convert text to Morse code',
    category: 'converter',
    react: '📡',
    filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
    try {
        const config = await readEnv();
         const lang = config.LANGUAGE || 'EN'; // Default to English if not set

 
        const noInputText = lang === 'SI' ? "කරුණාකර මෝස් කේතයට පරිවර්තනය කිරීමට පාඨයක් ලබා දෙන්න. උදා: `.morse Hello World`" : "Please provide text to convert to Morse code. Example: `.morse Hello World`";
        const errorOccurredText = lang === 'SI' ? "⚠️ මෝස් කේතයට පරිවර්තනය කිරීමේදී දෝෂයක් ඇතිවිය." : "⚠️ An error occurred while converting to Morse code.";


        // Check if input is provided
        if (!args.length) {
            return reply(noInputText);
        }

        const inputText = args.join(' ');
        const morseCode = encodeToMorse(inputText); // Assumes function for Morse encoding exists

        // Multi-language response for Morse code
        const morseResponseText = lang === 'SI' 
            ? `*⚠️ මෝස් කේතය* "${inputText}" සඳහා:\n\n${morseCode}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            : `*⚠️ Morse code for* "${inputText}":\n\n${morseCode}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        await reply(morseResponseText);

    } catch (e) {
        console.error('Error converting to Morse code:', e);
        reply(errorOccurredText);
    }
});
//=================================================================
cmd({
    pattern: 'demorse',
    desc: 'Convert Morse code to text',
    category: 'converter',
    react: '📡',
    filename: __filename
}, async (conn, mek, m, { from, reply, args }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; 
        const noInputText = lang === 'SI' ? "කරුණාකර මෝර්ස් කේතය ලබා දෙන්න. උදා: `.demorse ... --- ...`" : "Please provide Morse code to convert to text. Example: `.demorse ... --- ...`";
        const errorOccurredText = lang === 'SI' ? "⚠️ මෝර්ස් කේතය පරිවර්තනය කිරීමේදී දෝෂයක් ඇතිවිය." : "⚠️ An error occurred while converting Morse code.";


        // Check if input is provided
        if (!args.length) {
            return reply(noInputText);
        }

        const morseCode = args.join(' '); // Join arguments to get the Morse code
        const decodedText = decodeFromMorse(morseCode); // Function to decode Morse code

        // Multi-language response for decoded text
        const demorseResponseText = lang === 'SI' 
            ? `*⚠️ මෝර්ස් කේතය* "${morseCode}" සඳහා:\n\n${decodedText}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            : `*⚠️ Decoded text for* "${morseCode}":\n\n${decodedText}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`;

        await reply(demorseResponseText);

    } catch (e) {
        console.error('Error converting Morse code:', e);
        reply(errorOccurredText);
    }
});
//===============================================================
cmd({
    pattern: "urldecode",  // Command trigger
    desc: "Decode a URL-encoded string",  // Description of the command
    react: "🔃",  // Emoji for reacting to the command
    category: "converter",  // Category for the command
    filename: __filename  // File name containing the command
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        // Get the URL-encoded string
        const encodedText = args.join(" ");
        if (!encodedText) {
            // If no encoded text is provided, return an error message
            return reply("⚠️ Please provide a URL-encoded string to decode. Example: `.urldecode APIs%20(Application%20Programming%20Interfaces)%20are%20essential%20tools`");
        }

        // API URL to get the decoded result
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/urldecode?encodedUrl=${encodeURIComponent(encodedText)}&apikey=key1`;

        // Fetch data from the API
        const response = await fetch(apiUrl);
        const json = await response.json();

        // Check if the response is successful
        if (json.status !== "success") {
            return reply("❌ There was an error decoding the URL-encoded string. Please try again later.");
        }

        // Get the decoded result from the response
        const decodedText = json.decodedUrl;

        // Send the decoded result with formatting
        return reply(`💡 *URL Decoding Complete!*\n\n✨ Here's the decoded result:\n\n\`\`\`${decodedText}\`\`\`\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
    } catch (error) {
        console.error(error);
        return reply("⚠️ An error occurred while processing the request. Please try again later.");
    }
});


//===============================================================
cmd({
    pattern: "urlencode",  // Command trigger
    desc: "Encode text into URL format",  // Description of the command
    react: "🔃",  // Emoji for reacting to the command
    category: "converter",  // Category for the command
    filename: __filename  // File name containing the command
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        // Get the user's text to encode
        const textToEncode = args.join(" ");
        if (!textToEncode) {
            // If no text is provided, return an error message
            return reply("⚠️ Please provide text to encode into URL format. Example: `.urlencode Hello World!`");
        }

        // API URL to get the URL-encoded result
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/urlencode?text=${encodeURIComponent(textToEncode)}&apikey=key1`;

        // Fetch data from the API
        const response = await fetch(apiUrl);
        const json = await response.json();

        // Check if the response is successful
        if (json.status !== "success") {
            return reply("❌ There was an error encoding the text into URL format. Please try again later.");
        }

        // Get the URL-encoded result from the response
        const encodedText = json.encodedUrl;

        // Send the URL-encoded result with formatting
        return reply(`💡 *URL Encoding Complete!*\n\n✨ Here's the URL-encoded result:\n\n\`\`\`${encodedText}\`\`\`\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
    } catch (error) {
        console.error(error);
        return reply("⚠️ An error occurred while processing the request. Please try again later.");
    }
});


//===============================================================
cmd({
    pattern: "base64decode",  // Command trigger
    desc: "Decode Base64 to text",  // Description of the command
    react: "🔃",  // Emoji for reacting to the command
    category: "converter",  // Category for the command
    filename: __filename  // File name containing the command
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        // Get the user's Base64 string to decode
        const base64String = args.join(" ");
        if (!base64String) {
            // If no Base64 string is provided, return an error message
            return reply("⚠️ Please provide a Base64 string to decode. Example: `.base64decode SGVsbG8=`");
        }

        // API URL to get the decoded result of the Base64 string
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/base64decode?base64=${encodeURIComponent(base64String)}&apikey=key1`;

        // Fetch data from the API
        const response = await fetch(apiUrl);
        const json = await response.json();

        // Check if the response is successful
        if (json.status !== "success") {
            return reply("❌ There was an error decoding the Base64 string. Please try again later.");
        }

        // Get the decoded text from the response
        const decodedText = json.text;

        // Send the decoded result with formatting
        return reply(`💡 *Base64 Decoding Complete!*\n\n✨ Here's the decoded text from your Base64 string:\n\n\`\`\`${decodedText}\`\`\`\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
    } catch (error) {
        console.error(error);
        return reply("⚠️ An error occurred while processing the request. Please try again later.");
    }
});


//===============================================================

cmd({
    pattern: "base64encode",  // Command trigger
    desc: "Convert text to Base64",  // Description of the command
    react: "🔃",  // Emoji for reacting to the command
    category: "converter",  // Category for the command
    filename: __filename  // File name containing the command
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        // Get the user's text to encode
        const text = args.join(" ");
        if (!text) {
            return reply("⚠️ Please provide some text to encode to Base64. Example: `.base64encode Hello`");
        }

        // API URL to get the Base64 encoded result of the text
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/base64encode?text=${encodeURIComponent(text)}&apikey=key1`;

        // Fetch data from the API
        const response = await fetch(apiUrl);
        const json = await response.json();

        // Check if the response is successful
        if (json.status !== "success") {
            return reply("❌ There was an error encoding the text to Base64. Please try again later.");
        }

        // Get the Base64 encoded result from the response
        const base64Text = json.base64;

        // Send the Base64 result with formatting
        return reply(`💡 *Base64 Encoding Complete!*\n\n✨ Here's the Base64 encoded result of your text:\n\n\`\`\`${base64Text}\`\`\`\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
    } catch (error) {
        console.error(error);
        return reply("⚠️ An error occurred while processing the request. Please try again later.");
    }
});

//===============================================================
cmd({
    pattern: "dbinary",  
    desc: "Convert binary to text",  
    react: "🔃",  
    category: "converter",  
    filename: __filename  
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        const binaryText = args.join(" ");
        if (!binaryText) {
            return reply("⚠️ Please provide binary to convert. Example: `.dbinary 01001000 01100101 01101100 01101100 01101111`");
        }

        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/dbinary?binary=${encodeURIComponent(binaryText)}&apikey=key1`;
        const response = await fetch(apiUrl);
        const json = await response.json();

        if (json.status !== "success" || !json.text) {
            return reply("❌ There was an error converting the binary to text. Please try again later.");
        }

        const decodedText = json.text;
        return reply(`💡 *Binary to Text Conversion Complete!*\n\n✨ Here's the text representation of your binary:\n\n\`\`\`${decodedText}\`\`\``);

    } catch (error) {
        console.error(error);
        return reply("⚠️ An error occurred while processing your request. Please try again later.");
    }
});


//=================================================================
cmd({
    pattern: "ebinary",  
    desc: "Convert text to binary format",  
    react: "🔃",  
    category: "converter",  
    filename: __filename  
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        // Ensure 'text' is defined and not empty
        const text = args.join(" ");
        if (!text || typeof text !== "string") {
            return reply("⚠️ Please provide some text to convert to binary. Example: `.ebinary Hello`");
        }

        // API call to fetch binary representation
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/ebinary?text=${encodeURIComponent(text)}&apikey=key1`;
        const response = await fetch(apiUrl);
        const json = await response.json();

        // Check for API success and valid response
        if (json.status !== "success" || !json.binary) {
            return reply("❌ There was an error converting the text to binary. Please try again later.");
        }

        // Prepare and send the reply
        const binaryText = json.binary;
        return reply(`💡 *Binary Conversion Complete!*\n\n✨ Here's the binary representation of your text:\n\n\`\`\`${binaryText}\`\`\``);

    } catch (error) {
        console.error("Error in .ebinary command:", error);

        // Fallback error message
        return reply("⚠️ An error occurred while processing your request. Please try again later.");
    }
});

//=================================================================
cmd({
  pattern: "qr",
  desc: "Generate a QR code from text or URL.",
  react: "🔃",
  category: "converter",
  filename: __filename
}, async (conn, mek, m, { from, reply, q }) => {
    const config = await readEnv();
    const language = config.LANGUAGE; // SI for Sinhala, EN for English

    try {
        // Ensure 'q' is defined and is a valid non-empty string
        if (!q || typeof q !== 'string' || q.trim().length === 0) {
            const message = {
                SI: "⚠️ කරුණාකර QR කේතයක් නිර්මාණය කිරීමට පෙළක් හෝ URL එකක් ලබා දෙන්න.",
                EN: "⚠️ Please provide text or URL to generate a QR code."
            };
            return reply(message[language]);
        }

        const text = q.trim(); // Make sure the input is properly trimmed

        // Call the external API to generate the QR code
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/generate-qrcode?text=${encodeURIComponent(text)}&apikey=key1`;

        const response = await axios.get(apiUrl);

        // Check if the API response is successful
        if (response.data.status !== 'success') {
            throw new Error('Failed to generate QR code via API.');
        }

        // Get the QR code image URL from the API response
        const qrCodeUrl = response.data.data;

        // Send the QR code image URL as a message
        const caption = {
            SI: `📱 මෙය ඔබගේ QR කේතය: ${text}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            EN: `📱 Here's your QR code for: ${text}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
        };

        await conn.sendMessage(from, {
            image: { url: qrCodeUrl }, // Send the QR code image from the API response
            caption: caption[language]
        }, { quoted: mek });

    } catch (e) {
        console.error('Error generating QR code:', e.message);
        const errorMessage = {
            SI: `❌ QR කේතය නිර්මාණය කිරීමේදී දෝෂයක් සිදු විය: ${e.message}`,
            EN: `❌ An error occurred while generating the QR code: ${e.message}`
        };
        reply(errorMessage[language]);
    }
});









//=======================- DOWNLOADER COMMANDS =====================
//=================================================================
cmd({
    pattern: "wallpaper",
    desc: "Download multiple wallpapers based on a search term.",
    react: "🖼️",
    category: "downloader",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    const config = await readEnv();
    try {
        const query = args.join(" ");  // Get the search term from user input
        if (!query) {
            // If no search term is provided, show an error message
            return reply(config.LANGUAGE === 'SI' 
                ? "කරුණාකර පින්තූර සෙවීම සඳහා වචන ඇතුළත් කරන්න." 
                : "Please provide a search term to fetch wallpapers. Example: `.wallpaper car`");
        }

        // Construct the URL to fetch wallpapers
        const apiUrl = `https://www.dark-yasiya-api.site/download/wallpaper?text=${encodeURIComponent(query)}&page=1`;

        // Fetch the wallpaper data from the API
        const response = await fetch(apiUrl);

        // Check if the response was successful
        if (!response.ok) {
            return reply("⚠️ Failed to fetch wallpapers. Please try again later.");
        }

        // Parse the response JSON
        const data = await response.json();
        if (!data.result || data.result.length === 0) {
            return reply("⚠️ No wallpapers found for this search. Please try another term.");
        }

        // Extract the first 5 images from the result
        const wallpapers = [];
        for (let i = 0; i < Math.min(data.result.length, 5); i++) {
            wallpapers.push(data.result[i].image[0]);  // You can change the index if you prefer a different image size
        }

        // Send all 5 images
        for (const wallpaper of wallpapers) {
            await conn.sendMessage(from, { image: { url: wallpaper }, caption: `✨ Wallpaper for "${query}"` }, { quoted: mek });
        }

    } catch (e) {
        console.log(e);
        const errorMessage = config.LANGUAGE === 'SI' 
            ? `දෝෂයක්: ${e.message || 'අපට පැමිණුණු දෝෂයක් ඇත.'}` 
            : `Error: ${e.message || 'An error occurred.'}`;
        return reply(errorMessage);
    }
});

//=================================================================
cmd({
    pattern: "gimg",
    alias: ["googleimages"],
    desc: "Search and send 5 images from Google Image search",
    react: "📸",
    category: "image",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q, lang }) => {
    try {
        // Define the default query or use the user input
        const query = args.length ? args.join(" ") : "hello";

        // Define messages based on language selection
        const messages = {
            en: {
                noQuery: "Please provide a search query.",
                noImagesFound: "Sorry, no images found for your search query.",
                insufficientImages: "Sorry, there are not enough images for your search.",
                error: "An error occurred while fetching the images. Please try again later.",
                caption: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                responseStart: "Here are 5 images for"
            },
            si: {
                noQuery: "කරුණාකර සෙවුම් ප්‍රශ්නයක් ලබාදෙන්න.",
                noImagesFound: "සමාවන්න, ඔබගේ සෙවුම් ප්‍රශ්නය සඳහා ඡායාරූප කිසිවක් සොයාගත නොහැකිවූයේය.",
                insufficientImages: "සමාවන්න, ඔබේ සෙවුම සඳහා පින්තූර පරිප්‍රේෂණ කිසිවක් නොමැත.",
                error: "ඡායාරූප ලබා ගැනීමට දෝෂයක් ඇතිවිය. කරුණාකර නැවත උත්සාහ කරන්න.",
                caption: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                responseStart: "මෙන්න ඔබගේ සෙවීම සඳහා 5 පින්තූර"
            }
        };

        // Determine the selected language or default to English
        const selectedLang = lang || "en";

        // Fetching Google Image Search results from the API
        const apiUrl = `https://vishwa-api-78d69c95453f.herokuapp.com/misc/google-image-search?q=${encodeURIComponent(query)}&apikey=key1`;
        const response = await fetch(apiUrl);
        const json = await response.json();  // Parse the JSON response

        // Check if the response contains valid data
        if (!json.status || !json.data || json.data.length === 0) {
            return reply(messages[selectedLang].noImagesFound);
        }

        // Extracting the image URLs from the response data
        const imageUrls = json.data[0].result;

        // Check if there are at least 5 images
        if (imageUrls.length < 5) {
            return reply(messages[selectedLang].insufficientImages);
        }

        // Send the images one by one
        let message = `${messages[selectedLang].responseStart} "${query}":`;

        // Send a response message with images
        for (let i = 0; i < 5; i++) {
            await conn.sendMessage(from, {
                image: { url: imageUrls[i] },
                caption: `${messages[selectedLang].caption} ${i + 1}`,
                quoted: mek
            });
        }
    } catch (error) {
        console.error(error);
        reply(messages[selectedLang].error);
    }
});


//=================================================================
cmd({
    pattern: "pinterest",
    alias: ["pin","pimg"],
    desc: "Create Pinterest images with random search terms",
    react: "🖼️",
    category: "image",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    try {
        const config = await readEnv();  // Read configuration for language
        const query = args.length ? args.join(" ") : "car"; // Use 'car' if no argument is given

        // Fetching Pinterest results using the provided API
        const apiUrl = `https://www.dark-yasiya-api.site/download/piniimg?text=${encodeURIComponent(query)}`;
        const response = await fetch(apiUrl);
        const json = await response.json(); // Parse the JSON response

        const imageUrls = json.result.map(pin => pin.images_url).filter(url => url); // Filter out empty URLs

        if (imageUrls.length < 5) {
            return reply("Sorry, not enough images found for your search. Please try again later.");
        }

        // Language-specific messages
        let responseMessage = "";
        if (config.LANGUAGE === "SI") {
            // Sinhala message
            responseMessage = `✨ ඔබගේ පින්ටරෙස්ට් පින් එක සාර්ථකව සාදන්න "${query}" 📸`;
        } else {
            // English message
            responseMessage = `✨ Your Pinterest images for "${query}" have been successfully created 📸`;
        }

        // Send the images directly
        await conn.sendMessage(from, {
            text: responseMessage,
            image: { url: imageUrls[0] },
            caption: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
            quoted: mek
        });

        // Send remaining 4 images
        for (let i = 1; i < 5; i++) {
            await conn.sendMessage(from, {
                image: { url: imageUrls[i] },
                caption: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
                quoted: mek
            });
        }

    } catch (error) {
        console.error(error);
        reply("An error occurred while processing your request. Please try again later.");
    }
});

//================================================================
cmd({
    pattern: "apk",
    desc: "Download APK (WhatsApp Messenger)",
    react: "💻",
    category: "downloader",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    try {
        const config = await readEnv();
        const apiUrl1 = "https://vishwa-api-78d69c95453f.herokuapp.com/misc/apk?id=whatsapp&apikey=key1";
        const response1 = await fetch(apiUrl1);
        const data1 = await response1.json();

        // If the first server fails, fall back to the second server (Dark Yasiya API)
        const apiUrl2 = "https://www.dark-yasiya-api.site/download/apk?id=whatsapp";
        const response2 = await fetch(apiUrl2);
        const data2 = await response2.json();

        // Checking if data from the first server is available
        let appData = null;
        if (data1.status === "success") {
            appData = data1.app;
        } else if (data2.status === true) {
            appData = data2.result;
        }

        if (appData) {
            const { name, package, size, dllink, icon,dl_link } = appData;

            // Select language-specific messages
            let appInfoMessage = "";
            let downloadOptionsMessage = "";

            if (config.LANGUAGE === "SI") {
                // Sinhala messages
                appInfoMessage = `
乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖠 𝖯 𝖯 𝖫 𝖨 𝖢 𝖠 𝖳 𝖨 𝖮 𝖭  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🖥️ ගොනුවේ නම : ${name}
📻 මූලික පැකේජය : ${package}
📁 ප්‍රමාණය : ${size}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  බාගත කිරීම : උත්සහ කිරීම 01.
│ 2️⃣  බාගත කිරීම : උත්සහ කිරීම 02.
╰─────────────────────┈
`;
            } else {
                // English messages
                appInfoMessage = `
乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖠 𝖯 𝖯 𝖫 𝖨 𝖢 𝖠 𝖳 𝖨 𝖮 𝖭  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🖥️ Name : ${name}
📻 Package : ${package}
📁 Size : ${size}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  Download : Server 01.
│ 2️⃣  Download : Server 02.
╰─────────────────────┈
`;
            }

            // Send message with APK info and download options
            const sentMessage = await conn.sendMessage(from, { 
                text: appInfoMessage,
                  contextInfo: {
                      forwardingScore: 999,
                      isForwarded: true,
                      forwardedNewsletterMessageInfo: {
                          newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                          newsletterJid: "120363333519565664@newsletter",
                      },
                      externalAdReply: {
                          title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                          body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                          thumbnailUrl: botimg2,
                          sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                          mediaType: 1,
                          renderLargerThumbnail: false
                      }
                }
            }, { quoted: mek });

            // Listen for user's response to choose the server
            conn.ev.on("messages.upsert", async (messageUpsert) => {
                const msg = messageUpsert.messages[0];
                if (!msg.message || !msg.message.extendedTextMessage || !msg.message.extendedTextMessage.text) {
                    return; // Ensure the message has text before accessing it
                }

                const userReply = msg.message.extendedTextMessage.text.trim();
                const messageContext = msg.message.extendedTextMessage.contextInfo;

                // Check if the reply is for this specific message and user chose "1"
                if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                    if (userReply === "1") {
                        await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                        await conn.sendMessage(from, { 
                            document: { url: dllink }, // Use the URL directly if you fetch from an external URL
                            mimetype: 'application/vnd.android.package-archive',
                            fileName: `${name}.apk`,
                            caption:`> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
                            quoted: mek 
                        });
                        await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                    } else if (userReply === "2") {
                        await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                        await conn.sendMessage(from, { 
                            document: { url: dllink }, // Use the URL directly if you fetch from an external URL
                            mimetype: 'application/vnd.android.package-archive',
                            fileName: `${name}.apk`,
                            caption:`> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
                            quoted: mek 
                        });
                        await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                    } else {
                        await conn.sendMessage(from, "Invalid choice. Please reply with 1 or 2.");
                    }
                }
            });
        } else {
            reply("Failed to fetch app details from both servers.");
        }
    } catch (error) {
        console.error(error);
        reply("An error occurred while processing your request.");
    }
});

//=================================================================

//==============================================================
cmd({
    pattern: "igdl",
    desc: "Download media (image/video) from Instagram.",
    react: "📸",
    category: "downloader",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    try {
        // Ensure the URL is provided and contains "instagram.com"
        if (!q || !q.includes("instagram.com")) {
            return reply("❌ Please provide a valid Instagram URL.");
        }

        // Prepare the API URL with the provided URL
        const apiUrl = `https://api.nyxs.pw/dl/ig?url=${encodeURIComponent(q)}`;

        // Fetch the media data from the API
        const response = await fetch(apiUrl);
        const data = await response.json();

        // Handle API failure or missing result
        if (!data.status || !data.result || data.result.data !== 3) {
            return reply("❌ Failed to fetch the media. Ensure the URL is valid or try again later.");
        }

        const { result } = data;
        const mediaUrls = result.url;

        // Send a message indicating media download
        await conn.sendMessage(from, { text: "📥 Downloading Instagram Media..." }, { quoted: mek });

        // Check if video URL exists and send it
        if (mediaUrls[0].includes(".mp4")) {
            await conn.sendMessage(from, {
                video: { url: mediaUrls[0] },
                mimetype: "video/mp4",
                caption: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            }, { quoted: mek });
        }
        // Check if HEIC or image URL exists and send it
        else if (mediaUrls[1].includes(".heic")) {
            await conn.sendMessage(from, {
                image: { url: mediaUrls[1] },
                caption: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            }, { quoted: mek });
        } else if (mediaUrls[2].includes(".jpg") || mediaUrls[2].includes(".png")) {
            await conn.sendMessage(from, {
                image: { url: mediaUrls[2] },
                caption: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            }, { quoted: mek });
        } else {
            return reply("❌ No media found in the provided Instagram link.");
        }

    } catch (error) {
        console.error(error);
        reply("❌ An error occurred while processing your request. Please try again later.");
    }
});


//===============================================================
cmd({
    pattern: "twitter",
    desc: "Download media (video/audio) from Twitter.",
    react: "🐦",
    category: "downloader",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || "EN"; // Default to English
        const messages = {
            EN: {
                invalidUrl: "❌ Please provide a valid Twitter URL.",
                fetchError: "❌ Failed to fetch the media. Ensure the URL is valid or try again later.",
                unsupportedMedia: "❌ Unsupported media type. No video or audio found.",
                downloading: "📥 Downloading media...",
                mediaDetails: `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖳 𝖶 𝖨 𝖳 𝖳 𝖤 𝖱  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 𝖳𝗂𝗍𝗅𝖾 : {desc}
🖇️ 𝖴𝗋𝗅 : ${q}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭
 
╭─────────────────────┈
│ 1️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : HD 𝖵𝗂𝖽𝖾𝗈 𝖳𝗒𝗉𝖾.
│ 2️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : SD 𝖵𝗂𝖽𝖾𝗈 𝖳𝗒𝗉𝖾.
│ 3️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖠𝗎𝖽𝗂𝗈 𝖳𝗒𝗉𝖾.
╰─────────────────────┈`,
                HDVideo: "🎬 *HD Video*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                SDVideo: "🎬 *SD Video*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                audio: "🎧 *Audio File*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            },
            SI: {
                invalidUrl: "❌ වලංගු Twitter URL එකක් ලබා දෙන්න.",
                fetchError: "❌ මාධ්‍ය ලබා ගැනීම අසාර්ථක විය. URL වලංගු බව සහ තවත් වරක් උත්සාහ කරන්න.",
                unsupportedMedia: "❌ අනුමත නොකළ මාධ්‍ය වර්ගය. වීඩියෝ හෝ සංගීතයක් සොයාගත නොහැක.",
                downloading: "📥 මාධ්‍ය බාගත කරමින්...",
                mediaDetails: `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖳 𝖶 𝖨 𝖳 𝖳 𝖤 𝖱  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 මාතෘකාව : {desc}
🖇️ පිවිසුම් ලින්කුව : ${q}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭
 
╭─────────────────────┈
│ 1️⃣  බාගත කිරීම : HD වීඩියෝ ආකාරයට.
│ 2️⃣  බාගත කිරීම : SD වීඩියෝ ආකාරයට.
│ 3️⃣  බාගත කිරීම : සංගීත ආකාරයට.
╰─────────────────────┈`,
                HDVideo: "🎬 *HD වීඩියෝ*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                SDVideo: "🎬 *SD වීඩියෝ*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ",
                audio: "🎧 *සංගීත ගොනුව*\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ"
            }
        };

        // Ensure a valid Twitter URL is provided
        if (!q || !q.includes("twitter.com")) return reply(messages[lang].invalidUrl);

        // Prepare the API URL with the provided URL
        const apiKey = "Cu5RXZLd";
        const apiUrl = `https://api.fgmods.xyz/api/downloader/twitter?url=${encodeURIComponent(q)}&apikey=${apiKey}`;

        // Fetch the Twitter media details
        const response = await fetch(apiUrl);
        const data = await response.json();

        // Handle API failure or missing result
        if (!data.status || !data.result) {
            return reply(messages[lang].fetchError);
        }

        const { desc, thumb, HD, SD, audio } = data.result;

        // Construct and send message with media details
        const mediaInfo = messages[lang].mediaDetails.replace("{desc}", desc);
        const sentMessage = await conn.sendMessage(from, {
            image: { url: thumb },
            caption: mediaInfo
        }, { quoted: mek });

        // Listen for user replies (e.g., 1, 2, 3)
        conn.ev.on("messages.upsert", async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                switch (userReply) {
                    case "1":
                        if (HD) {
                            await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                            await conn.sendMessage(from, {
                                video: { url: HD },
                                mimetype: "video/mp4",
                                caption: messages[lang].HDVideo
                            }, { quoted: mek });
                            await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                        }
                        break;
                    case "2":
                        if (SD) {
                            await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                            await conn.sendMessage(from, {
                                video: { url: SD },
                                mimetype: "video/mp4",
                                caption: messages[lang].SDVideo
                            }, { quoted: mek });
                            await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                        }
                        break;
                    case "3":
                        if (audio) {
                            await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                            await conn.sendMessage(from, {
                                audio: { url: audio },
                                mimetype: "audio/mp3",
                                caption: messages[lang].audio
                            }, { quoted: mek });
                            await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                        }
                        break;
                    default:
                        reply(messages[lang].unsupportedMedia);
                }
            }
        });

    } catch (error) {
        console.error(error);
        reply(messages[lang].fetchError);
    }
});
//================================================================

cmd({
    pattern: "mega",
    category: "downloader",
    react: "⬇️",
    use: '.mega <Link>',
    desc: "Download Mega file and send it with detailed info.",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, args, q, reply }) => {
    try {
        if (!q || !q.includes('mega.nz')) {
            return reply("❌ *Invalid URL!* Please provide a valid Mega.nz file URL. 🔗");
        }

        // Extract file link and key from the Mega URL
        const [fileURL, fileKey] = q.split("#");
        if (!fileKey) {
            return reply("🔑 *Decryption key missing!* Please provide a complete Mega.nz URL.");
        }

        // Create a File instance
        const file = File.fromURL(`${fileURL}#${fileKey}`);

        // Notify about the download starting
        reply("📥 *Preparing to download...*\nPlease wait, fetching file details.");

        // Get file metadata
        const fileMeta = await file.loadAttributes();

        const fileName = fileMeta.name || "Unknown_File";
        const fileSizeMB = (fileMeta.size / (1024 * 1024)).toFixed(2); // Size in MB
        const fileDate = new Date(fileMeta.timestamp * 1000).toLocaleString(); // Convert timestamp to readable date

        // Inform the user about the file details
        await conn.sendMessage(from, {
            text: `🔍 *File Details:*\n\n📁 *Name:* ${fileName}\n📦 *Size:* ${fileSizeMB} MB\n⏰ *Uploaded On:* ${fileDate}\n🔗 *Source URL:* ${q}\n\n📥 *Downloading now...*`,
            quoted: mek
        });

        // Progress tracking
        file.on('progress', (bytesLoaded, bytesTotal) => {
            const percent = ((bytesLoaded / bytesTotal) * 100).toFixed(2);
            const loadedMB = (bytesLoaded / (1024 * 1024)).toFixed(2);
            const totalMB = (bytesTotal / (1024 * 1024)).toFixed(2);

            reply(`⬇️ *Progress:*\n${percent}% (${loadedMB} MB of ${totalMB} MB)`);
        });

        // Download the file as a buffer
        const buffer = await file.downloadBuffer();

        // Send the file as a document
        await conn.sendMessage(from, {
            document: buffer,
            mimetype: "application/octet-stream",
            fileName: fileName,
            caption: `✅ *Download Complete!*\n\n📁 *Name:* ${fileName}\n📦 *Size:* ${fileSizeMB} MB\n⏰ *Uploaded On:* ${fileDate}\n\n🎉 Enjoy your file!`
        }, { quoted: mek });

    } catch (error) {
        console.error(error);
        reply(`❌ *Error occurred!*\n\nDetails: ${error.message}`);
    }
});

//================================================================
cmd({
    pattern: "mfire",
    desc: "Download files from MediaFire.",
    react: "📥",
    category: "downloader",
    filename: __filename,
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        const config = await readEnv();

        // Check if the user has provided a URL
        if (!q || !q.startsWith("http")) {
            return reply(config.LANGUAGE === "SI" 
                ? "❌ කරුණාකර වලංගු MediaFire URL එකක් ලබා දෙන්න!" 
                : "❌ Please provide a valid MediaFire URL!"
            );
        }

        // Construct API URL to get MediaFire file details
        const apiUrl = `https://www.dark-yasiya-api.site/download/mfire?url=${encodeURIComponent(q)}`;

        // Fetch data from the API
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (!data.status || !data.result) {
            return reply(config.LANGUAGE === "SI" 
                ? "❌ MediaFire ලින්කුව විග්‍රහ කිරීම අසාර්ථක විය. කරුණාකර නැවත පරීක්ෂා කරන්න." 
                : "❌ Failed to process the MediaFire link. Please check and try again."
            );
        }

        const { fileName, fileType, size, dl_link } = data.result;

        // Send download information to the user
        await conn.sendMessage(from, {
            text: config.LANGUAGE === "SI" 
                ? `*乂 𝗠𝗘𝗗𝗜𝗔𝗙𝗜𝗥𝗘 𝗙𝗜𝗟𝗘 𝗗𝗘𝗧𝗔𝗜𝗟𝗦* \n\n📄 *ගොනුවේ නම:* ${fileName}\n📂 *ප්‍රමාණය:* ${size}\n🖇️ *URL:* ${q}\n\n✅ *බාගත කිරීම ආරම්භ වේ...*` 
                : `*乂 MEDIAFIRE FILE DETAILS* \n\n📄 *File Name:* ${fileName}\n📂 *Size:* ${size}\n🖇️ *URL:* ${q}\n\n✅ *Downloading file now...*`,
            footer: "ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀",
        }, { quoted: mek });

        // Download the file and send it to the user
        await conn.sendMessage(from, {
            document: { url: dl_link },
            mimetype: fileType,
            fileName,
            caption: config.LANGUAGE === "SI" 
                ? `🎉 *බාගත කිරීම සාර්ථකයි!*\n© 𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 𝗕𝗛𝗔𝗦𝗛𝗜-𝗠𝗗 🚀` 
                : `🎉 *Download successful!*\n© POWERED BY BHASHI-MD 🚀`,
        }, { quoted: mek });

    } catch (error) {
        console.error(error);
        reply(config.LANGUAGE === "SI" 
            ? `❌ දෝෂයක් සිදු විය: ${error.message}. කරුණාකර නැවත උත්සාහ කරන්න.` 
            : `❌ An error occurred: ${error.message}. Please try again.`
        );
    }
});

//=================================================================
cmd({
    pattern: "soundcloud",
    desc: "Download SoundCloud tracks.",
    react: "🎶",
    category: "downloader",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    try {
        const config = await readEnv();
        if (!q) {
            return reply(config.LANGUAGE === "SI" 
                ? "🎵 කරුණාකර වලංගු SoundCloud URL එකක් ලබා දෙන්න!" 
                : "🎵 Please provide a valid SoundCloud URL!"
            );
        }

        const apiKey = "Cu5RXZLd"; // Your API key
        const soundcloudUrl = `https://api.fgmods.xyz/api/downloader/soundcloud?url=${encodeURIComponent(q)}&apikey=${apiKey}`;

        const response = await fetch(soundcloudUrl);
        const data = await response.json();

        // Check if data was successfully fetched
        if (!data.status || !data.result) {
            return reply(config.LANGUAGE === "SI" 
                ? "❌ SoundCloud ගීතය ලබා ගැනීම අසමත් විය. කරුණාකර URL එක පරීක්ෂා කරන්න හෝ නැවත උත්සාහ කරන්න." 
                : "❌ Unable to fetch track details. Check the URL or try again."
            );
        }

        const { title, duration, thumb, dl_url } = data.result;

        // Prepare track information message based on language
        const trackInfo = config.LANGUAGE === "SI" 
            ? `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖲 𝖮 𝖴 𝖭 𝖣 𝖢 𝖫 𝖮 𝖴 𝖣  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 මාතෘකාව : ${title}
⏰ කාලසීමාව : ${duration}
🖇️ පිවිසුම් ලින්කුව : ${q}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖮  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  බාගත කිරීම : ඕඩියෝ
╰─────────────────────┈`
            : `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖲 𝖮 𝖴 𝖭 𝖣 𝖢 𝖫 𝖮 𝖴 𝖣  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 Title: ${title}
⏰ Duration: ${duration}
🖇️ URL: ${q}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖮  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  Download: Audio Type
╰─────────────────────┈`;

        // Send the message with the track information and thumbnail
        const sentMessage =  await conn.sendMessage(from, {
                image: { url: thumb },
                caption: trackInfo,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                        newsletterJid: "120363333519565664@newsletter",
                    },
                    externalAdReply: {
                        title: 'ＢＨＡＳＨＩ－ＭＤ Ｖ２ 🚀',
                        body: '© ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ',
                        thumbnailUrl: botimg2,
                        sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: mek });

        // Listen for the user's reply and send the audio if they choose "1"
        conn.ev.on("messages.upsert", async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            // Check if the reply is for this specific message and user chose "1"
            if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                if (userReply === "1") {
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(from, {
                        audio: { url: dl_url },
                        mimetype: "audio/mpeg",
                        fileName: `${title}.mp3`,
                        caption: config.LANGUAGE === "SI" 
                            ? `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` 
                            : `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
                    }, { quoted: mek });
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                }
            }
        });

    } catch (error) {
        console.error(error);
        reply(config.LANGUAGE === "SI" 
            ? `❌ දෝෂයක් සිදු විය: ${error.message}. කරුණාකර නැවත උත්සාහ කරන්න.` 
            : `❌ An error occurred: ${error.message}. Please try again.`
        );
    }
});

//================================================================
cmd({
    pattern: "video",
    desc: "Search and download YouTube videos.",
    react: "📹",
    category: "downloader",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q }) => {
    try {
        const config = await readEnv();
        if (!q) return reply(config.LANGUAGE === 'SI' ? "📹 කරුණාකර වීඩියෝ පණිවිඩයක් හෝ URL එකක් සපයන්න ✨" : "📹 Please provide a video query or URL ✨");

        // Search for videos using yts
        const searchResults = await yts(q);
        if (!searchResults.videos || searchResults.videos.length === 0) {
            return reply(config.LANGUAGE === 'SI' ? "❌ වීඩියෝ නොපවතී. කරුණාකර නැවත සොයන්න." : "❌ No videos found. Please refine your search.");
        }

        const video = searchResults.videos[0]; // Select the first result
        const videoUrl = video.url;

        // Fetch additional download information
        const videoInfo = await fetch(`https://api.nyxs.pw/dl/yt?url=${videoUrl}`).then(res => res.json());
        if (!videoInfo.status) return reply(config.LANGUAGE === 'SI' ? "❌ වීඩියෝ ලබා ගැනීමට අසමත් විය. කරුණාකර URL එක පරීක්ෂා කරන්න හෝ නැවත උත්සාහ කරන්න." : "❌ Failed to fetch video. Please check the URL or try again.");

        const { title, data } = videoInfo.result;
        const hd = data.hd;
        const fhd = data.fhd;

        // Prepare detailed video message
        let desc = (config.LANGUAGE === 'SI' ? `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖵 𝖨 𝖣 𝖤 𝖮  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 මාතෘකාව : ${title}
⏰ කාලසීමාව : ${video.timestamp}
📻 චැනලය : ${video.author.name}
📆 උඩුගත කල දිනය : ${video.ago}
🖇️ පිවිසුම් ලින්කුව : ${video.url} 

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖬 𝖤 𝖭 𝖴  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭
 
╭─────────────────────┈
│ 1️⃣  බාගත කිරීම : 𝖧𝖣 වීඩියෝ ආකාරයට.
│ 2️⃣  බාගත කිරීම : 𝖲𝖣 වීඩියෝ ආකාරයට.
╰─────────────────────┈` 
        : `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖵 𝖨 𝖣 𝖤 𝖮  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 𝖳𝗂𝗍𝗅𝖾 : ${title}
⏰ 𝖣𝗎𝗋𝖺𝗍𝗂𝗈𝗇 : ${video.timestamp}
📻 𝖢𝗁𝖺𝗇𝖾𝗅 : ${video.author.name}
📆 𝖴𝗉𝗅𝗈𝖺𝖽 𝖮𝗇 : ${video.ago}
🖇️ 𝖴𝗋𝗅 : ${video.url} 

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖬 𝖤 𝖭 𝖴  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭
 
╭─────────────────────┈
│ 1️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖧𝖣 𝖵𝗂𝖽𝖾𝗈 𝖳𝗒𝗉𝖾.
│ 2️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖲𝖣 𝖵𝗂𝖽𝖾𝗈 𝖳𝗒𝗉𝖾.
╰─────────────────────┈`);

        // Send video details with thumbnail
        const sentMessage = await conn.sendMessage(from, {
            image: { url: video.thumbnail },
            caption: desc,
              contextInfo: {
                  forwardingScore: 999,
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                      newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                      newsletterJid: "120363333519565664@newsletter",
                  },
                  externalAdReply: {
                      title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                      body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                      thumbnailUrl: botimg2,
                      sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                      mediaType: 1,
                      renderLargerThumbnail: false
                  }
            }
        }, { quoted: mek });

        // Listen for user's choice
        conn.ev.on("messages.upsert", async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            // Check if the reply is to the sent message
            if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                if (userReply === '1') {
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(from, {
                        video: { url: hd.url },
                        caption: config.LANGUAGE === 'SI' ? `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴇ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` : `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴇ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
                    }, { quoted: mek });
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else if (userReply === '2') {
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(from, {
                        video: { url: fhd.url },
                        caption: config.LANGUAGE === 'SI' ? `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴇ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` : `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴇ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
                    }, { quoted: mek });
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else {
                    await reply(config.LANGUAGE === 'SI' ? "🚫 අසම්මානජනක පිළිතුරක්! කරුණාකර '1' HD හෝ '2' FHD යන පිළිතුරක් යවන්න." : "🚫 Invalid choice! Please reply with '1' for HD or '2' for FHD.");
                }
            }
        });

    } catch (e) {
        console.log(e);
        reply(config.LANGUAGE === 'SI' ? `❌ දෝෂයක් සිදු විය: ${e.message}. කරුණාකර නැවත උත්සාහ කරන්න!` : `❌ An error occurred: ${e.message}. Please try again!`);
    }
});

//===============================================================
cmd({
    pattern: "song",
    desc: "Download songs.",
    react: "🎶",
    category: "downloader",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, q, config }) => {
    try {
        const config = await readEnv();
        const language = config.LANGUAGE || 'EN'; // Default to English if no language is set

        // Multi-language responses
        const messages = {
            'EN': {
                noQuery: "🪄 Please provide a song URL or name ✨",
                songInfo: `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖲 𝖮 𝖭 𝖦  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 𝖳𝗂𝗍𝗅𝖾 : {title}
⏰ 𝖣𝗎𝗋𝖺𝗍𝗂𝗈𝗇 : {duration}
📻 𝖢𝗁𝖺𝗇𝖾𝗅 : {channel}
📆 𝖴𝗉𝗅𝗈𝖺𝖽 𝖮𝗇 : {uploaded}
🖇️ 𝖴𝗋𝗅 : {url}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖬 𝖤 𝖭 𝖴  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭
 
╭─────────────────────┈
│ 1️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖠𝗎𝖽𝗂𝗈 𝖳𝗒𝗉𝖾.
│ 2️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖣𝗈𝖼𝗎𝗆𝖾𝗇𝗍 𝖳𝗒𝗉𝖾.
╰─────────────────────┈`,
                invalidChoice: "🚫 Invalid choice! Please reply with '1' to download as audio or '2' to download as a document."
            },
            'SI': {
                noQuery: "🪄 කරුණාකර සංගීත URL එකක් හෝ නමක් ලබා දෙන්න ✨",
                songInfo: `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖲 𝖮 𝖭 𝖦  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🎬 මාතෘකාව : {title}
⏰ කාලසීමාව : {duration}
📻 චැනලය :  {channel}
📆 උඩුගත කල දිනය : {uploaded}
🖇️ පිවිසුම් ලින්කුව : {url}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖬 𝖤 𝖭 𝖴  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭
 
╭─────────────────────┈
│ 1️⃣  බාගත කිරීම : සංගීත ආකාරයට.
│ 2️⃣  බාගත කිරීම : ගොනු ආකාරයට.
╰─────────────────────┈`,
                invalidChoice: "🚫 වැරදි තෝරන්න! කරුණාකර '1' ලෙස උත්තර දෙන්න, සංගීත ආකාරයට බාගත කිරීමට හෝ '2' ලෙස ගොනු ආකාරයට බාගත කිරීමට."
            }
        };

        // Check for query input
        if (!q) return reply(messages[language].noQuery);

        // Search for song
        const search = await yts(q);
        const data = search.videos[0];
        const url = data.url;

        // Prepare song details message
        let desc = messages[language].songInfo
            .replace("{title}", data.title)
            .replace("{duration}", data.timestamp)
            .replace("{channel}", data.author.name)
            .replace("{uploaded}", data.ago)
            .replace("{url}", data.url);

        // Send song details with thumbnail and emoji
        const sentMessage = await conn.sendMessage(
                from,
                {
                    text: desc,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: false,
                        forwardedNewsletterMessageInfo: {
                            newsletterName: "ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​",
                            newsletterJid: "120363333519565664@newsletter",
                        },
                        externalAdReply: {
                            title: `Bhashi Song Downloader`,
                            body: `${data.title} : Powerd By Bhashi Song Information Search Engine`,
                            thumbnailUrl: data.thumbnail,
                            sourceUrl: ``,
                            mediaType: 1,
                            renderLargerThumbnail: false,
                        },
                    },
                },
                { quoted: mek },
            );

        // Download audio
        const downloadInfo = await fetch(`https://api.nyxs.pw/dl/yt-direct?url=${url}`).then(res => res.json());
        const audioUrl = downloadInfo.result.urlAudio;

        // Listen for the user's reply (handle the number choice)
        conn.ev.on("messages.upsert", async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            // Check if the reply is to the previously sent prompt
            if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                if (userReply === '1') {
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(from, { 
                        audio: { url: audioUrl }, 
                        mimetype: "audio/mpeg", 
                        caption: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ" 
                    }, { quoted: mek });
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else if (userReply === '2') {
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(from, { 
                        document: { url: audioUrl }, 
                        mimetype: "audio/mpeg", 
                        caption: "> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ", 
                        fileName: `${data.title}.mp3` 
                    }, { quoted: mek });
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else {
                    await reply(messages[language].invalidChoice);
                }
            }
        });

    } catch (e) {
        console.log(e);
        reply(`❌ An error occurred: ${e.message}. Please try again!`);
    }
});


//===============================================================
cmd({
    pattern: "gitclone",
    alias: ["repoclone"],
    desc: "Download a GitHub repository",
    category: "downloader",
    react: "📥",
    filename: __filename
},
async (conn, mek, m, { from, args, reply }) => {
    try {
        const config = await readEnv();
        const lang = config.LANGUAGE || 'EN'; 

        const noUrlProvidedText = lang === 'SI' ? `කරුණාකර GitHub නාමාවලියක් ලබා දෙන්න.\n\nඋදාහරණය: .gitclone https://github.com/example/example` : `Please provide a GitHub repository URL.\n\nExample: .gitclone https://github.com/example/example`;
        const invalidUrlText = lang === 'SI' ? 'අවලංගු GitHub නාමාවලිය. කරුණාකර වලංගු URL එකක් ලබා දෙන්න.' : 'Invalid GitHub repository URL. Please provide a valid URL.';
        const repoNotFoundText = lang === 'SI' ? 'නාමාවලිය සොයා ගත නොහැක. කරුණාකර URL එක පරීක්ෂා කර නැවත උත්සාහ කරන්න.' : 'Repository not found. Please check the URL and try again.';
        const downloadingTextBase = lang === 'SI' ? `📥 ඩවුන්ලෝඩ් කරමින්: %s\n\nකරුණාකර වාසියක්, මෙය විනාඩි කිහිපයක් ගනු ඇත...` : `📥 Downloading: %s\n\nPlease wait, this may take a moment...`;


        if (!args[0]) {
            return reply(noUrlProvidedText);
        }

        const regex = /(?:https?:\/\/)?(?:www\.)?github\.com\/([^\/]+)\/([^\/]+)/i;
        const match = args[0].match(regex);

        if (!match) {
            return reply(invalidUrlText);
        }

        const [, user, repo] = match;
        const zipUrl = `https://codeload.github.com/${user}/${repo}/zip/refs/heads/main`;
        const apiUrl = `https://api.github.com/repos/${user}/${repo}`;

        // Fetch repository information
        https.get(apiUrl, {
            headers: { 'User-Agent': 'BHASHI-MD Bot' }
        }, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', async () => {
                if (res.statusCode === 404) {
                    return reply(repoNotFoundText);
                }

                const repoInfo = JSON.parse(data);

                // Send a message indicating download is starting
                const downloadingText = downloadingTextBase.replace('%s', repoInfo.full_name);
                await reply(downloadingText);

                // Download and send the repository
                await conn.sendMessage(from, {
                    document: { url: zipUrl },
                    mimetype: 'application/zip',
                    fileName: `${repoInfo.name}.zip`,
                    caption: lang === 'SI' 
                        ? `📦 *නාමාවලිය:* ${repoInfo.full_name}\n🌟 *තරඟ:* ${repoInfo.stargazers_count}\n📚 *විස්තරය:* ${repoInfo.description || 'විස්තරයක් නොමැත.'}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
                        : `📦 *Repository:* ${repoInfo.full_name}\n🌟 *Stars:* ${repoInfo.stargazers_count}\n📚 *Description:* ${repoInfo.description || 'No description provided.'}\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,
                });
            });
        }).on('error', (error) => {
            console.error(error);
            reply(lang === 'SI' ? '📥 ප්‍රවේශ කරමින් GitHub නාමාවලියක් ලබා ගැනීමේ දෝෂයක් ඇතිවිය. කරුණාකර නැවත උත්සාහ කරන්න.' : 'An error occurred while fetching repository information. Please try again later.');
        });

    } catch (error) {
        console.error(error);
        reply(lang === 'SI' ? '❌ **දෝෂයක්:** ඔබේ ඉල්ලීම සැකසීමේදී අනපේක්ෂිත දෝෂයක් සිදුවිය.' : '❌ **Error:** An unexpected error occurred while processing your request. Please try again later.');
    }
});
//==============================================================
cmd({
    pattern: "gdrive",
    alias: ["gdrive"],
    react: "📥",
    desc: "Download files from Google Drive",
    category: "downloader",
    use: ".gdrive <Google Drive file URL>",
    filename: __filename
}, async (conn, mek, m, { from, args, reply, pushname }) => {
    const config = await readEnv();
    const language = config.LANGUAGE; 
    try {
        const gdriveUrl = args.join(" ");
        if (!gdriveUrl) {
            const message = {
                SI: "*🚫 කරුණාකර Google Drive ලින්ක් එකක් ලබා දෙන්න!*",
                EN: "*🚫 Please provide a Google Drive URL!*"
            };
            return await reply(message[language]);
        }

        // API URL to fetch file information
        const apiUrl = `${vishwa}/misc/gdrive?url=${encodeURIComponent(gdriveUrl)}&apikey=key1`;

        // Fetch file information from the API
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data.status === "success") {
            const fileInfo = data.fileInfo;
            const { fileName, directDownloadLink, originalLink, Author } = fileInfo;

            // Send the file info to the user
            const message = {
                SI: `╭─『 *Google Drive DL* 』───⊷
│
│ ✨ *Requester*: ${pushname}
│ 🤖 *Bot*: BHASHI-MD
│ 📄 *File Name:* ${fileName}
│ 📚 *Author:* ${Author}
│ 📎 *Type:* Image (Assumed for simplicity)
│ 📥 *Direct Download Link:* ${directDownloadLink}
│
│ 🤷‍♀️ _Your Google Drive content is on its way!_
╰────────────────────⊷`,
                EN: `╭─『 *Google Drive DL* 』───⊷
│
│ ✨ *Requester*: ${pushname}
│ 🤖 *Bot*: BHASHI-MD
│ 📄 *File Name:* ${fileName}
│ 📚 *Author:* ${Author}
│ 📎 *Type:* Image (Assumed for simplicity)
│ 📥 *Direct Download Link:* ${directDownloadLink}
│
│ 🤷‍♀️ _Your Google Drive content is on its way!_
╰────────────────────⊷`
            };
            await reply(message[language]);

            // Now send the file directly to the user from the direct download link
            await conn.sendMessage(from, {
                document: { url: directDownloadLink },
                mimetype: 'application/octet-stream',
                fileName: fileName,
                caption: `📥 *${pushname}*, here is your Google Drive file!\n\n> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
            });
        } else {
            const errorMessage = {
                SI: "*🚫 ගූගල් ඩ්රයිව් ගොනුව සොයා ගැනීමේදී දෝෂයක් සිදු විය!*",
                EN: "*🚫 Error occurred while fetching the Google Drive file!*"
            };
            await reply(errorMessage[language]);
        }

    } catch (e) {
        // Handle errors gracefully
        const errorMessage = {
            SI: `❌ *ඔබේ ඉල්ලීම පිරිනැමීමේදී දෝෂයක් සිදු විය:* ${e.message} ❌`,
            EN: `❌ *Error occurred while processing your request:* ${e.message} ❌`
        };
        await conn.sendMessage(from, { text: errorMessage[language], quoted: mek });
        console.log(e);
    }
});
//==================================================================
cmd({
    pattern: "ytmp3",
    category: "downloader",
    react: "🎵",
    use: ".ytmp3 <YouTube URL>",
    desc: "Download YouTube video as MP3",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply }) => {
    try {
        if (!q || !q.includes("youtube.com") && !q.includes("youtu.be")) {
            return reply("❌ *Invalid URL!* Please provide a valid YouTube video URL.");
        }

        const apiUrl = `https://api.nyxs.pw/dl/yt-direct?url=${encodeURIComponent(q)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (!data.status) {
            return reply("❌ *Failed to fetch video details!* Please check the URL or try again.");
        }

        const { urlAudio, title, description, length, channelName, thumbnail } = data.result;

        // Send video details with thumbnail
        await conn.sendMessage(from, {
            image: { url: thumbnail },
            caption: `🎵 *YouTube MP3 Download*\n\n📌 *Title:* ${title}\n📚 *Channel:* ${channelName}\n⏰ *Duration:* ${length}\n📝 *Description:* ${description.substring(0, 100)}...\n\n📥 *Downloading MP3...*`,
            quoted: mek
        });

        // Send the audio file
        await conn.sendMessage(from, {
            audio: { url: urlAudio },
            mimetype: "audio/mpeg",
            fileName: `${title.replace(/[^a-zA-Z0-9]/g, "_")}.mp3`,
            caption: `✅ *Download Complete!*\n\n🎵 Enjoy your music!`
        }, { quoted: mek });

    } catch (error) {
        console.error(error);
        reply(`❌ *Error occurred!* Details: ${error.message}`);
    }
});
//==================================================================
cmd({
    pattern: "ytmp4",
    category: "downloader",
    react: "🎥",
    use: ".ytmp4 <YouTube URL>",
    desc: "Download YouTube video as MP4",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply }) => {
    try {
        if (!q || !q.includes("youtube.com") && !q.includes("youtu.be")) {
            return reply("❌ *Invalid URL!* Please provide a valid YouTube video URL.");
        }

        const apiUrl = `https://api.nyxs.pw/dl/yt-direct?url=${encodeURIComponent(q)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (!data.status) {
            return reply("❌ *Failed to fetch video details!* Please check the URL or try again.");
        }

        const { urlVideo, title, description, length, channelName, thumbnail } = data.result;

        // Send video details with thumbnail
        await conn.sendMessage(from, {
            image: { url: thumbnail },
            caption: `🎥 *YouTube MP4 Download*\n\n📌 *Title:* ${title}\n📚 *Channel:* ${channelName}\n⏰ *Duration:* ${length}\n📝 *Description:* ${description.substring(0, 100)}...\n\n📥 *Downloading MP4...*`,
            quoted: mek
        });

        // Send the video file
        await conn.sendMessage(from, {
            video: { url: urlVideo },
            mimetype: "video/mp4",
            fileName: `${title.replace(/[^a-zA-Z0-9]/g, "_")}.mp4`,
            caption: `✅ *Download Complete!*\n\n🎥 Enjoy your video!`
        }, { quoted: mek });

    } catch (error) {
        console.error(error);
        reply(`❌ *Error occurred!* Details: ${error.message}`);
    }
});

//=================================================================
cmd({
    pattern: "tt",
    alias: ["tiktok"],
    react: '🎵',
    desc: "Download TikTok videos",
    category: "downloader",
    use: '.tt <tiktok link>',
    filename: __filename
}, async (conn, mek, m, { from, args, reply, pushname }) => {
    const config = await readEnv();
    // Define language preference (SI for Sinhala, EN for English)
    const language = config.LANGUAGE; // Ensure this is set to either 'SI' or 'EN'

    try {
        // Get the TikTok URL from args
        const q = args.join(" ");
        if (!q) {
            const message = {
                SI: '*🚫 කරුණාකර TikTok URL එකක් ලබා දෙන්න!*',
                EN: '*🚫 Please provide a TikTok URL!*'
            };
            return await reply(message[language]);
        }

        // Watermark message
        const wm = {
            SI: `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖳 𝖨 𝖪 𝖳 𝖮 𝖪  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🖇️ පිවිසුම් ලින්කුව : ${q}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  බාගත කිරීම : වීඩියෝ ආකාරයට. ( සලකුනු ඉවත් කරමින් )
│ 2️⃣  බාගත කිරීම : සංගීත ආකාරයට.
╰─────────────────────┈`,
            EN: `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖳 𝖨 𝖪 𝖳 𝖮 𝖪  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭

🖇️ 𝖡𝖺𝗌𝖾 𝖴𝗋𝗅 : ${q}

乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖣 𝖮 𝖶 𝖭 𝖫 𝖮 𝖠 𝖣  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭

╭─────────────────────┈
│ 1️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖵𝗂𝖽𝖾𝗈 𝖧𝖣 𝖳𝗒𝗉𝖾. ( 𝖶𝗂𝗍𝗁𝗈𝗎𝗍 𝖶𝖺𝗍𝖾𝗋𝗆𝖺𝗋𝗄 )
│ 2️⃣  𝖣𝗈𝗐𝗇𝗅𝗈𝖺𝖽 : 𝖠𝗎𝖽𝗂𝗈 𝖳𝗒𝗉𝖾.
╰─────────────────────┈`
        };

        // Perform TikTok download using a hypothetical tiktokdl function
        let response = await tiktokdl(q);
        let { video, music } = response;

        // Send initial message with options
        const sentMessage = await conn.sendMessage(from, {
              document: { url: botimg }, 
              fileName: 'ＢＨＡＳＨＩ－ＭＤ Ｖ２ 🚀', 
              mimetype: "application/pdf",
              fileLength: 99999999999999,
              image: { url: 'https://i.ibb.co/5rm6dLz/image.png' },
              pageCount: 2024,
              caption: wm[language],
              contextInfo: {
                  forwardingScore: 999,
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                      newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                      newsletterJid: "120363333519565664@newsletter",
                  },
                  externalAdReply: {
                      title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                      body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                      thumbnailUrl: botimg2,
                      sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                      mediaType: 1,
                      renderLargerThumbnail: false
                  }
              }
          });

        // Listen for user's reply
        conn.ev.on("messages.upsert", async (messageUpsert) => {
            const msg = messageUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            // Check if the reply is to the previously sent prompt
            if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
                if (userReply === '1') {
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(from, { 
                        video: { url: video }, 
                        caption: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`
                    }, { quoted: msg });
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else if (userReply === '2') {
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(from, { 
                        audio: { url: music }, 
                        mimetype: "audio/mpeg" 
                    }, { quoted: msg });
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else {
                    await conn.sendMessage(from, { 
                        text: language === 'SI' ? "❗ *වැරදි ආකාරය.* කරුණාකර '1' ලෙස වීඩියෝ සඳහා හෝ '2' ලෙස ශබ්දය සඳහා පිළිතුරු දෙන්න." : "❗ *Invalid input.* Please reply with '1' for Video or '2' for Audio."
                    }, { quoted: msg });
                }
            }
        });

        // Send a reaction
        return await conn.sendMessage(from, { react: { text: '🎉', key: mek.key } });
    } catch (e) {
        // Reply with an error message to the user via WhatsApp
        const errorMessage = {
            SI: `❌ *ඔබේ ඉල්ලීම පිරිනැමීමේදී දෝෂයක් සිදු විය:* ${e.message} ❌`,
            EN: `❌ *Error occurred while processing your request:* ${e.message} ❌`
        };
        await conn.sendMessage(from, { text: errorMessage[language], quoted: mek });
        console.log(e);
    }
});
//=================================================================
cmd({
    pattern: "9gag",
    react: "😂",
    desc: "Get a random post from 9GAG.",
    category: "downloader",
    use: '.9gag [section]',
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        // Ensure config is read properly
        const config = await readEnv();
        const section = q.trim() || 'hot'; // Default to 'hot' if no section is provided

        await reply(config.LANGUAGE === 'SI'
            ? `🔍 ${section} කොටසෙන් යම් පශ්චාත් එකක් ලබාගන්න...`
            : `🔍 Fetching a random post from the ${section} section...`);

        // Create Scraper instance with section and posts limit
        const scraper = new Scraper(10, section, 0);
        const posts = await scraper.scrap();

        // Check if posts are undefined or empty
        if (!posts || posts.length === 0) {
            return reply(config.LANGUAGE === 'SI'
                ? "❗ පශ්චාත් සොයාගත නොහැක. කරුණාකර නැවත උත්සාහ කරන්න."
                : "❗ No posts found. Please try again.");
        }

        // Select random post
        const randomPost = posts[Math.floor(Math.random() * posts.length)];
        const captionSI = `*${randomPost.title}*\n👍 ආසාවෙන් හිමිවූ මනාප: ${randomPost.upVoteCount}\n💬 කුමන්ත්රණ: ${randomPost.commentsCount}\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`;
        const captionEN = `*${randomPost.title}*\n👍 Upvotes: ${randomPost.upVoteCount}\n💬 Comments: ${randomPost.commentsCount}\n\n> ${mono}ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ-ᴡᴀ-ʙᴏᴛ ㋛${mono}`;

        const caption = config.LANGUAGE === 'SI' ? captionSI : captionEN;

        // Sending the appropriate content based on post type
        try {
            const messageContent = { caption };
            switch (randomPost.type) {
                case 'Photo':
                case 'Animated':
                    messageContent.image = { url: randomPost.content };
                    break;
                case 'Video':
                    messageContent.video = { url: randomPost.content };
                    break;
                default:
                    messageContent.text = `${caption}\n\nContent: ${randomPost.content}`;
            }

            await conn.sendMessage(from, messageContent, { quoted: mek });
        } catch (postError) {
            console.error('Error sending post:', postError);
            await reply(config.LANGUAGE === 'SI'
                ? "❗ පශ්චාත් එක යැවීමට දෝෂයක් ඇති විය. නැවත උත්සාහ කරන්න."
                : "❗ Error sending post. Please try again.");
        }

    } catch (e) {
        console.error('Error in 9gag command:', e);
        reply(config.LANGUAGE === 'SI'
            ? "❗ 9GAG වෙතින් පශ්චාත් එකක් ලබා ගැනීමේ දෝෂයක් ඇතිවිය."
            : "❗ Error occurred while fetching post from 9GAG.");
    }
});
//==============================================================
cmd({
    pattern: "fb2",
    alias: "facebook2",
    desc: "Download videos from Facebook",
    category: "downloader",
    react: "📹",
    filename: __filename,
}, async (conn, mek, m, { args, reply, quoted }) => {
    try {
        const fbURL = args[0]; // URL passed by the user
        if (!fbURL) return reply("❌ Please provide a Facebook video link. Example: .fb2 <link>");

        reply("🔄 Fetching video links...");
        const apiUrl = `https://www.dark-yasiya-api.site/download/fbdl1?url=${encodeURIComponent(fbURL)}`;

        // Fetch video details
        const { data } = await axios.get(apiUrl);
        if (!data.status || !data.result) return reply("❌ Unable to fetch video links. Please check the URL or try again later.");

        const hdLink = data.result.hd || "Unavailable";
        const sdLink = data.result.sd || "Unavailable";

        // Prompt user for quality selection
        const qualityMessage = `📹 *Facebook Video Download*\n\n*1️⃣ HD Quality:* ${hdLink === "Unavailable" ? "Not available" : "Available"}\n*2️⃣ SD Quality:* ${sdLink === "Unavailable" ? "Not available" : "Available"}\n\n*Reply with 1 or 2 to choose the quality.*`;
        const menuMessage = await conn.sendMessage(m.chat, { text: qualityMessage }, { quoted: m });

        conn.ev.on("messages.upsert", async (msgUpsert) => {
            const msg = msgUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            // Check if the reply matches the menu message
            if (messageContext && messageContext.stanzaId === menuMessage.key.id) {
                if (userReply === "1" && hdLink !== "Unavailable") {
                    // React to user reply before sending the video
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(m.chat, { video: { url: hdLink }, caption: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`});
                    // React with success after sending video
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else if (userReply === "2" && sdLink !== "Unavailable") {
                    // React to user reply before sending the video
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(m.chat, { video: { url: sdLink }, caption: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2*| © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` });
                    // React with success after sending video
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else {
                    // React to invalid choice
                    await conn.sendMessage(m.chat, { react: { text: "❌", key: msg.key } });
                    return reply("❌ Invalid choice or the selected quality is unavailable.");
                }
            }
        });
    } catch (error) {
        console.error(error);
        reply("❌ An error occurred while processing your request. Please try again later.");
    }
});

//===============================================================
cmd({
    pattern: "fb",
    alias: "facebook",
    desc: "Download videos from Facebook",
    category: "Downloader",
    react: "📹",
    filename: __filename,
}, async (conn, mek, m, { args, reply, quoted }) => {
    try {
        const fbURL = args[0]; // URL passed by the user
        if (!fbURL) return reply("❌ Please provide a Facebook video link. Example: .fb <link>");

        reply("🔄 Fetching video links...");
        const apiUrl = `https://api.nyxs.pw/dl/fb?url=${encodeURIComponent(fbURL)}`;

        // Fetch video details
        const { data } = await axios.get(apiUrl);
        if (!data.status || !data.result) return reply("❌ Unable to fetch video links. Please check the URL or try again later.");

        const hdLink = data.result.hd || "Unavailable";
        const sdLink = data.result.sd || "Unavailable";

        // Prompt user for quality selection
        const qualityMessage = `📹 *Facebook Video Download*\n\n*1️⃣ HD Quality:* ${hdLink === "Unavailable" ? "Not available" : "Available"}\n*2️⃣ SD Quality:* ${sdLink === "Unavailable" ? "Not available" : "Available"}\n\n*Reply with 1 or 2 to choose the quality.*`;
        const menuMessage = await conn.sendMessage(m.chat, { text: qualityMessage }, { quoted: m });

        conn.ev.on("messages.upsert", async (msgUpsert) => {
            const msg = msgUpsert.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const userReply = msg.message.extendedTextMessage.text.trim();
            const messageContext = msg.message.extendedTextMessage.contextInfo;

            // Check if the reply matches the menu message
            if (messageContext && messageContext.stanzaId === menuMessage.key.id) {
                if (userReply === "1" && hdLink !== "Unavailable") {
                    // React to user reply before sending the video
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(m.chat, { video: { url: hdLink }, caption: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` });
                    // React with success after sending video
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else if (userReply === "2" && sdLink !== "Unavailable") {
                    // React to user reply before sending the video
                    await conn.sendMessage(m.chat, { react: { text: "🔽", key: msg.key } });
                    await conn.sendMessage(m.chat, { video: { url: sdLink }, caption: `> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ` });
                    // React with success after sending video
                    await conn.sendMessage(m.chat, { react: { text: "✅", key: msg.key } });
                } else {
                    // React to invalid choice
                    await conn.sendMessage(m.chat, { react: { text: "❌", key: msg.key } });
                    return reply("❌ Invalid choice or the selected quality is unavailable.");
                }
            }
        });
    } catch (error) {
        console.error(error);
        reply("❌ An error occurred while processing your request. Please try again later.");
    }
});

//=============================MAIN-COMMANDS========================
//=============================================================
cmd({
  pattern: "repo",
  desc: "Get the link to the official GitHub repository along with stats.",
  category: "main",
  react: "📂",
  filename: __filename
}, async (conn, mek, m, { reply }) => {
  const config = await readEnv();
  const repoUrl = 'https://api.github.com/repos/vishwamihiranga/BHASHI-MD'; 
  const language = config.LANGUAGE; 
  try {

      const response = await axios.get(repoUrl);
      const { stargazers_count, forks_count, open_issues_count, contributors_url } = response.data;

      const contributorsResponse = await axios.get(contributors_url);
      const contributors_count = contributorsResponse.data.length;

      const repoInfo = {
          SI: `
📂 *GitHub Repository* 📂
ඔබට මෙහි අභ්‍යන්තර සම්පාදක භාෂාව සහා සම්පත් කේතය සොයා ගත හැක:

- *🧾 GitHub Repository*: https://github.com/vishwamihiranga/BHASHI-MD
- ⭐ *තරු*: ${stargazers_count}
- 🍴 *හැරීම*: ${forks_count}
- 🛠 *විවෘත ගැටලු*: ${open_issues_count}
- 🚀 *සහය දායකයන්*: ${contributors_count}

ආරාධනා කරනවා ඔබ කේතයට තරු එකතු කරන ලෙස සහා සම්බන්ධ වන්න!
          `,
          EN: `
📂 *GitHub Repository* 📂
You can find the source code and contribute to the project here:

- *🧾 GitHub Repository*: https://github.com/vishwamihiranga/BHASHI-MD
- ⭐ *Stars*: ${stargazers_count}
- 🍴 *Forks*: ${forks_count}
- 🛠 *Open Issues*: ${open_issues_count}
- 🚀 *Contributors*: ${contributors_count}

Feel free to star the project and contribute!
          `
      };

      reply(repoInfo[language]);
  } catch (error) {
      const errorMessage = {
          SI: "❌ ගිටහබ් විස්තර ලබා ගැනීම අසාර්ථක විය. කරුණාකර පසුව නැවත උත්සාහ කරන්න.",
          EN: "❌ Failed to fetch repository data. Please try again later."
      };
      reply(errorMessage[language]);
  }
});
//=================================================================
cmd({
  pattern: "web",
  desc: "Get the official website link.",
  category: "main",
  react: "🌐",
  filename: __filename
}, async (conn, mek, m, { reply }) => {
  const config = await readEnv();
  const language = config.LANGUAGE; 

  const webInfo = {
      SI: `
🌐 *නිල වෙබ් අඩවිය* 🌐
වැඩි විස්තර සහ සම්පත් සඳහා අපගේ නිල වෙබ් අඩවියට පිවිසෙන්න:

- *🔗 වෙබ් අඩවිය*: https://bhashi-md-ofc.netlify.app/
      `,
      EN: `
🌐 *Official Website* 🌐
Visit our official website for more information and resources:

- *🔗 Website*: https://bhashi-md-ofc.netlify.app/
      `
  };

  reply(webInfo[language]); 
});
//==============================================================
cmd({
  pattern: "session",
  desc: "Get information about session management.",
  category: "main",
  react: "🔑",
  filename: __filename
}, async (conn, mek, m, { reply }) => {
  const config = await readEnv();
  const language = config.LANGUAGE; 

  // Session information in both languages
  const sessionInfo = {
      SI: `
🔑 *සෙෂන් කළමනාකරණය* 🔑
ඔබට පහත සම්පත් භාවිතා කරමින් ඔබගේ සෙෂන් කළමනාකරණය කළ හැක:

- *📑 Session ID*: https://pair-web-public.koyeb.app/
      `,
      EN: `
🔑 *Session Management* 🔑
You can manage your sessions using the following resources:

- *📑 Session ID*: https://pair-web-public.koyeb.app/
      `
  };

  reply(sessionInfo[language]); // Send the message based on language preference
});
//============================================================
cmd({
  pattern: "channel",
  desc: "Get information about the official channels.",
  category: "main",
  react: "📢",
  filename: __filename
}, async (conn, mek, m, { reply }) => {
  const config = await readEnv();
  const language = config.LANGUAGE; 
  const channelInfo = {
      SI: `
📢 *නිළ නාලිකා* 📢
අපගේ නවතම ප්‍රවෘත්ති සහ නිවේදන ලබාගැනීමට යාවත්කාලීනව සිටින්න:

- *📣 WhatsApp නාලිකාව*: https://whatsapp.com/channel/0029Vajj591JUM2RT8xtig2U
      `,
      EN: `
📢 *Official Channels* 📢
Stay updated with our latest news and announcements:

- *📣 WhatsApp Channel*: https://whatsapp.com/channel/0029Vajj591JUM2RT8xtig2U
      `
  };
  reply(channelInfo[language]); 
});
//======================================================
cmd({
  pattern: "system",
  alias: ["status", "botinfo"],
  desc: "Check uptime, RAM usage, CPU info, and more",
  category: "main",
  react: "🧬",
  filename: __filename,
}, async (conn, mek, m, { from, reply }) => {
  try {
    const uptimeInSeconds = process.uptime(); // Get system uptime in seconds
    const uptime = formatUptime(uptimeInSeconds);

    const memoryUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const totalMemory = Math.round(os.totalmem() / 1024 / 1024);

    // Status message to be sent
    const status = `*乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖲 𝖸 𝖲 𝖳 𝖤 𝖬  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭*

⏰ *𝖴𝗉𝗍𝗂𝗆𝖾* : ${uptime}
📻 *𝖯𝗅𝖺𝗍𝖿𝗈𝗋𝗆* : ${process.platform}
⚙️ *𝖱𝖺𝗆 𝖴𝗌𝖺𝗀𝖾* : ${memoryUsage} MB / ${totalMemory} MB

*乂  𝖱 𝖤 𝖯 𝖫 𝖸  𝖳 𝖧 𝖤  𝖨 𝖭 𝖥 𝖮  𝖮 𝖯 𝖢 𝖳 𝖨 𝖮 𝖭*

╭─────────────────────┈
│ 1️⃣  𝖡𝗁𝖺𝗌𝗁𝗂 : 𝖮𝗐𝗇𝖾𝗋 𝖨𝗇𝖿𝗈𝗋𝗆𝖺𝗍𝗂𝗈𝗇.
│ 2️⃣  𝖡𝗁𝖺𝗌𝗁𝗂 : 𝖱𝖾𝗉𝗈 𝖨𝗇𝖿𝗈𝗋𝗆𝖺𝗍𝗂𝗈𝗇.
│ 3️⃣  𝖡𝗁𝖺𝗌𝗁𝗂 : 𝖧𝖾𝗅𝗉. ( 𝖧𝗈𝗐 𝖳𝗈 𝖣𝖾𝗉𝗅𝗈𝗒 )
╰─────────────────────┈`;

    // Send audio message
    await conn.sendMessage(from, {
      audio: { url: "https://github.com/vishwamihiranga/BHASHI-PUBLIC/raw/main/ui%20(1).mp3" },
      mimetype: "audio/mpeg",
      ptt: true,
    }, { quoted: mek });

    // Send image with caption
    const sentMessage = await conn.sendMessage(from, {
          text: status,
          contextInfo: {
              forwardingScore: 999,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                  newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                  newsletterJid: "120363333519565664@newsletter",
              },
              externalAdReply: {
                  title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                  body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                  thumbnailUrl: botimg2,
                  sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                  mediaType: 1,
                  renderLargerThumbnail: false
              }
                  }
              }, { quoted: mek });

    // Event listener for user replies
    conn.ev.on("messages.upsert", async (messageUpsert) => {
      const msg = messageUpsert.messages[0];
      if (!msg.message || !msg.message.extendedTextMessage) return;

      const userReply = msg.message.extendedTextMessage.text.trim();
      const messageContext = msg.message.extendedTextMessage.contextInfo;

      if (messageContext && messageContext.stanzaId === sentMessage.key.id) {
        if (userReply === "1") {
            await conn.sendMessage(from, { react: { text: "⏳", key: mek.key } });
          reply(`*乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖮 𝖶 𝖭 𝖤 𝖱  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭*

🧑🏻‍💻 *𝖮𝗐𝗇𝖾𝗋* : 𝖡𝗁𝖺𝗌𝗁𝗂𝗍𝗁𝖺 𝖣𝗂𝗌𝗌𝖺𝗇𝖺𝗒𝖺𝗄𝖾
🧑🏻‍💻 *𝖢𝗈 𝖮𝗐𝗇𝖾𝗋* : 𝖵𝗂𝗌𝗁𝗐𝖺 𝖬𝗂𝗁𝗂𝗋𝖺𝗇𝗀𝖺 ( 𝖣𝖾𝗏𝖾𝗅𝗈𝗉𝖾𝗋 )
🧑🏻‍💻 *𝖧𝖾𝗅𝗉𝖾𝗋* : 𝖠𝗅𝖾𝗑 𝖨𝖣 ( 𝖳𝖾𝖺𝗆 𝖫𝖾𝖺𝖽𝖾𝗋 )`);
        } else if (userReply === "2") {
            await conn.sendMessage(from, { react: { text: "⏳", key: mek.key } });
          reply(`*乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖱 𝖤 𝖯 𝖮  𝖨 𝖭 𝖥 𝖮 𝖱 𝖬 𝖠 𝖳 𝖨 𝖮 𝖭*

⚙️ 𝖶𝖾𝖻 𝖲𝗂𝗍𝖾 : ( 𝖭𝗈𝗍 𝖱𝖾𝗅𝖾𝖺𝗌𝖾𝖽 )
⚙️ 𝖦𝗂𝗍𝗁𝗎𝖻 : ( 𝖭𝗈𝗍 𝖱𝖾𝗅𝖾𝖺𝗌𝖾𝖽 )
⚙️ 𝖢𝗁𝖺𝗇𝖾𝗅 : https://whatsapp.com/channel/0029Vajj591JUM2RT8xtig2U`);
        } else if (userReply === "3") {
            await conn.sendMessage(from, { react: { text: "⏳", key: mek.key } });
          reply(`乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖧 𝖤 𝖫 𝖯  𝖢 𝖤 𝖭 𝖳 𝖤 𝖱

📻 𝖮𝗐𝗇𝗇𝖾𝗋𝗌 𝖠𝗅𝗂𝗏𝖾 𝖮𝗇 𝖶𝗁𝖺𝗍𝗌𝖺𝗉𝗉`);
        } else {
          reply("Invalid option, please reply with 1, 2, or 3.");
        }
      }
    });
  } catch (e) {
    console.error(e);
    reply(`*Error:* ${e.message}`);
  }
});


//==============================================================
function detectPlatform() {
    if (process.env.REPL_ID) return 'Replit';
    if (process.env.HEROKU_APP_NAME) return 'Heroku';
    if (process.env.KOYEB_PROJECT_ID) return 'Koyeb';
    if (process.env.AWS_LAMBDA_FUNCTION_NAME) return 'AWS Lambda';
    if (process.env.VERCEL) return 'Vercel';
    if (process.env.NETLIFY) return 'Netlify';
    if (process.env.GITHUB_ACTIONS) return 'GitHub Actions (Workflow)';
    if (process.env.CODESPACES) return 'GitHub Codespaces';
    return 'Unknown Platform';
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatUptime(seconds) {
    if (isNaN(seconds) || seconds < 0) {
        return 'Invalid uptime';
    }
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

const PLATFORM = detectPlatform();

cmd({
    pattern: "alive",
    desc: "Check if the bot is online and send an 'alive' message with system info.",
    category: "main",
    react: "👋🏻",
    filename: __filename
}, async (conn, mek, m, { from, args, reply }) => {
    try {
        const systemInfo = `
> *Platform* : ${PLATFORM}
> *Uptime* : ${formatUptime(os.uptime())}
> *Total RAM* : ${formatFileSize(os.totalmem())}
> *Free RAM* : ${formatFileSize(os.freemem())}
        `.trim();

        // Send the audio message
        await conn.sendMessage(from, {
            audio: { url: 'https://github.com/vishwamihiranga/BHASHI-PUBLIC/raw/main/ui%20(1).mp3' },
            mimetype: 'audio/mpeg',
            ptt: true
        }, { quoted: mek });

        // Send the message with system info
        await conn.sendMessage(from, {
            image: { url: 'https://i.ibb.co/5rm6dLz/image.png' },
            caption: `
𝙃𝙀𝙇𝙇𝙊 𝙄 𝘼𝙈 𝙊𝙉𝙇𝙄𝙉𝙀

_A Bhashi Md Whatsapp Bot Based Third Party Application Providing Many Services With Real-Time Automated Conversational Experience. Enjoy._

${systemInfo}

> *ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ-ᴅᴇᴠɪᴄᴇ ᴡᴀ-ʙᴏᴛ*  
> © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
            `.trim(),
            footer: '*ʙʜᴀꜱʜɪ • ᴍᴜʟᴛɪ-ᴅᴇᴠɪᴄᴇ ᴡᴀ-ʙᴏᴛ*\n*ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴠɪꜱʜᴡᴀ ᴍɪʜɪʀᴀɴɢᴀ*',
              contextInfo: {
                  forwardingScore: 999,
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                      newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                      newsletterJid: "120363333519565664@newsletter",
                  },
                  externalAdReply: {
                      title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                      body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                      thumbnailUrl: botimg2,
                      sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                      mediaType: 1,
                      renderLargerThumbnail: false
                  }
            }
        });

    } catch (e) {
        console.error('🚫 Error:', e);
        await reply('🚫 Error: ' + e.message);
    }
});
//=============================================================
cmd({
  pattern: "support",
  desc: "Get information about support channels.",
  category: "main",
  react: "🆘",
  filename: __filename
}, async (conn, mek, m, { reply }) => {
  const config = await readEnv();
  const language = config.LANGUAGE; 
  const supportInfo = {
      SI: `
🆘 *උදව්ක් ඕනද?* 🆘
ඔබට සහය අවශ්‍ය නම් හෝ ප්‍රශ්න තිබේ නම්, පහත නාලිකා හරහා අපට පිවිසෙන්න:

🪀*සහය කණ්ඩායම*: https://whatsapp.com/channel/0029VaSaZd5CBtxGawmSph1k
      `,
      EN: `乂  𝖡 𝖧 𝖠 𝖲 𝖧 𝖨  𝖲 𝖴 𝖯 𝖯 𝖮 𝖱 𝖳  𝖢 𝖤 𝖭 𝖳 𝖤 𝖱

𝖨𝖿 𝖸𝗈𝗎 𝖭𝖾𝖾𝖽 𝖲𝗎𝗉𝗉𝗈𝗋𝗍 𝖮𝗋 𝖧𝖺𝗏𝖾 𝖠𝗇𝗒 𝖰𝗎𝖾𝗌𝗍𝗂𝗈𝗇𝗌. 𝖸𝗈𝗎 𝖢𝖺𝗇 𝖱𝖾𝖺𝖼𝗁 𝖴𝗌 𝖳𝗁𝗋𝗈𝗎𝗀𝗁 𝖳𝗁𝖾 𝖥𝗈𝗅𝗅𝗈𝗐𝗂𝗇𝗀 𝖢𝗁𝖺𝗇𝗇𝖾𝗅𝗌.

🪀 𝖲𝗎𝗉𝗉𝗈𝗋𝗍 𝖦𝗋𝗈𝗎𝗉 : https://whatsapp.com/channel/0029VaSaZd5CBtxGawmSph1k`
  };
  reply(supportInfo[language]);
});
//=================================================================
const startTime = Date.now();

// Function to calculate bot's runtime
function getRuntime() {
    const uptime = Date.now() - startTime;
    let seconds = Math.floor((uptime / 1000) % 60);
    let minutes = Math.floor((uptime / (1000 * 60)) % 60);
    let hours = Math.floor((uptime / (1000 * 60 * 60)) % 24);
    let days = Math.floor(uptime / (1000 * 60 * 60 * 24));

    return `${days} day(s), ${hours} hour(s), ${minutes} minute(s), ${seconds} second(s)`;
}

// Function to get the total number of plugins
function getTotalPlugins() {
    const pluginDirectory = path.join(__dirname, '../BHASHI-PLUGS');
    const files = fs.readdirSync(pluginDirectory);

    // Filter to count only JavaScript files (.js), you can modify this for your specific use case
    const pluginFiles = files.filter(file => file.endsWith('.js'));
    return pluginFiles.length;
}

cmd({
    pattern: "list",
    react: "📜",
    alias: ["panel",  "commands"],
    desc: "Get bot's command list.",
    category: "main",
    use: '.menu',
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, isoska, groupAdmins, isBotAdmins, isAdmins, reply }) => {

    try {
         const config = readEnv();
        let categories = {};
        for (let cmd of commands) {
            if (!cmd.dontAddCommandList && cmd.pattern) { // Add command only if pattern is defined
                if (!(cmd.category in categories)) {
                    categories[cmd.category] = {};
                }
                if (!(cmd.pattern in categories[cmd.category])) {
                    categories[cmd.category][cmd.pattern] = [];
                }
                categories[cmd.category][cmd.pattern].push(...(cmd.alias || []));
            }
        }
        const totalPlugins = getTotalPlugins();  // Dynamically get the total plugins
        const runtime = getRuntime();  // Dynamically calculate runtime
        const prefix = '.';
        let menu = `╭────✦ 𝗠𝗘𝗡𝗨 𝗟𝗜𝗦𝗧 ✦─────╮
Hello ${pushname} 👋,
A Bhashi MD Wa Bot Based On Baiyles

> *🪄 ➤ ᴘʀᴇꜰɪx :* ${prefix}
> *📈 ➤ ᴛᴏᴛᴀʟ ᴘʟᴜɢɪɴꜱ :* ${totalPlugins}
> *🧑‍💻 ➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *⏰ ➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime} 
╰─────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦─────╯
${readmore}
> ${mono}ʀᴇᴘʟʏ ᴡɪᴛʜ ɴᴜᴍʙᴇʀ ꜰᴏʀ ɢᴇᴛ ᴍᴇɴᴜ${mono}\n\n`;

        for (let category in categories) {
            menu += `*╭───────────●●►* \n*│* *「 ${category.toUpperCase()} COMMANDS 」*\n*│*   ───────\n`;
            for (let pattern in categories[category]) {
                menu += `*│* *"${prefix}${pattern}"*\n`;
                for (let alias of categories[category][pattern]) {
                    menu += `*│*   *| ${prefix}${alias}*\n`;
                }
                menu += '*│*\n';
            }
            menu += `*╰───────────●●►*\n`;
        }
        await conn.sendMessage(from, { image: { url: botimg }, caption: menu }, { quoted: mek });
    } catch (e) {
        reply('*Error !!*');
        console.error(e); // Replaced 'l(e)' with 'console.error(e)'
    }
});
//=============================================================================================================================
cmd({
    pattern: "menu",
    desc: "get menu list.",
    category: "main",
    react: "🔖",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        const config = readEnv();
        await conn.sendMessage(from, {
            audio: { url: 'https://github.com/vishwamihiranga/BHASHI-PUBLIC/raw/main/ui%20(1).mp3' },
            mimetype: 'audio/mpeg',
            ptt: true
        }, { quoted: mek });
const readmore = "\u200B".repeat(4000); 
        const thumbnailUrl = 'https://i.ibb.co/hRw1XK4/image.png'; // Direct URL to your image
           const prefix = ".";  // Replace with actual bot prefix if dynamic
            const totalPlugins = getTotalPlugins();  // Dynamically get the total plugins
            const runtime = getRuntime();  // Dynamically calculate runtime
        const menuMessage = await conn.sendMessage(from, {
            image: { url: 'https://i.ibb.co/hRw1XK4/image.png' },
            caption: `╭────✦ 𝗠𝗘𝗡𝗨 𝗟𝗜𝗦𝗧 ✦─────╮
    Hello ${pushname} 👋,
A Bhashi MD Wa Bot Based On Baiyles

> *🪄 ➤ ᴘʀᴇꜰɪx :* ${prefix}
> *📈 ➤ ᴛᴏᴛᴀʟ ᴘʟᴜɢɪɴꜱ :* ${totalPlugins}
> *🧑‍💻 ➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *⏰ ➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime} 
╰─────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦─────╯
${readmore}
> ${mono}ʀᴇᴘʟʏ ᴡɪᴛʜ ɴᴜᴍʙᴇʀ ꜰᴏʀ ɢᴇᴛ ᴍᴇɴᴜ${mono}

╭────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦───┈╮
│ *01 ❯* All Menu
│ *02 ❯* Main Menu
│ *03 ❯* Downloader Menu
│ *04 ❯* Converter Menu
│ *05 ❯* A.I. Menu
│ *06 ❯* Search Menu
│ *07 ❯* Fun Menu
│ *08 ❯* Nsfw Menu
│ *09 ❯* Useful Menu
│ *10 ❯* Logo Menu
│ *11 ❯* Movie Menu
│ *12 ❯* Anime Menu
│ *13 ❯* News Menu
│ *14 ❯* Group Menu
│ *15 ❯* Premium Menu
│ *16 ❯* Owner Menu
│ *17 ❯* Random Menu
╰──────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`,//ᴏᴡɴᴇʀ ᴄᴍᴅ ᴍᴇɴᴜ
              contextInfo: {
                  forwardingScore: 999,
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                      newsletterName: 'ʙʜᴀꜱʜɪ-ᴍᴅ ᴠ2 🚀​',
                      newsletterJid: "120363333519565664@newsletter",
                  },
                  externalAdReply: {
                      title: 'Bhashi - MD Version 2.0.0 🧚🏻‍♀️',
                      body: '© Presented By Bhashi Coders. Powerd By Dark Hackers Zone Team. Enjoi Now Bhashi Project.',
                      thumbnailUrl: botimg2,
                      sourceUrl: 'https://bhashi-md-ofc.netlify.app/',
                      mediaType: 1,
                      renderLargerThumbnail: false
                  }
            }
        });

        // Listen for replies to the menu message
                        conn.ev.on("messages.upsert", async (messageUpsert) => {
                            const msg = messageUpsert.messages[0];
                            if (!msg.message || !msg.message.extendedTextMessage) return;

                            const userReply = msg.message.extendedTextMessage.text.trim();
                            const messageContext = msg.message.extendedTextMessage.contextInfo;

                            // Check if the reply is to the menu message
                            if (messageContext && messageContext.stanzaId === menuMessage.key.id) {
                                switch (userReply) {
                                    case "01":
                                        reply(`╭───✦ 𝗠𝗘𝗡𝗨 𝗟𝗜𝗦𝗧 ✦──────╮
Hello ${pushname} 👋,
A Bhashi MD Wa Bot Simple List Menu Message , You can Get More Infomation About Commands use .list Command

> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴛᴏᴛᴀʟ ᴘʟᴜɢɪɴꜱ :* ${totalPlugins}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭─────✦ *ᴍᴀɪɴ ᴍᴇɴᴜ* ✦────┈╮
│  ▢  ${mono}Menu${mono}
│  ▢  ${mono}List${mono}
│  ▢  ${mono}Support${mono}
│  ▢  ${mono}Alive${mono}
│  ▢  ${mono}Ping${mono}
│  ▢  ${mono}System${mono}
│  ▢  ${mono}Channel${mono}
│  ▢  ${mono}web${mono}
│  ▢  ${mono}Session${mono}
│  ▢  ${mono}Repo${mono}
╰────────────────┈╯
╭──✦ *ᴅᴏᴡɴʟᴏᴀᴅᴇʀ ᴍᴇɴᴜ* ✦─┈╮
│  ▢  ${mono}fb${mono}
│  ▢  ${mono}fb2${mono}
│  ▢  ${mono}9gag${mono}
│  ▢  ${mono}tiktok${mono}
│  ▢  ${mono}gdrive${mono}
│  ▢  ${mono}mfire${mono}
│  ▢  ${mono}mega${mono}
│  ▢  ${mono}gitclone${mono}
│  ▢  ${mono}song${mono}
│  ▢  ${mono}video${mono}
│  ▢  ${mono}ytmp3${mono}
│  ▢  ${mono}ytmp4${mono}
│  ▢  ${mono}igdl${mono}
│  ▢  ${mono}soundcloud${mono}
│  ▢  ${mono}twitter${mono}
│  ▢  ${mono}gimg${mono}
│  ▢  ${mono}pinterest${mono}
│  ▢  ${mono}wallpaper${mono}
╰────────────────┈╯
╭───✦ *ᴄᴏɴᴠᴇʀᴛᴇʀ ᴍᴇɴᴜ* ✦─┈╮
│  ▢  ${mono}qr${mono}
│  ▢  ${mono}dbinary${mono}
│  ▢  ${mono}ebinary${mono}
│  ▢  ${mono}base64encode${mono}
│  ▢  ${mono}base64decode${mono}
│  ▢  ${mono}urlencode${mono}
│  ▢  ${mono}urldecode${mono}
│  ▢  ${mono}sticker${mono}
│  ▢  ${mono}convert${mono}
│  ▢  ${mono}morse${mono}
│  ▢  ${mono}demorse${mono}
│  ▢  ${mono}trt${mono}
│  ▢  ${mono}shorturl${mono}
│  ▢  ${mono}sha256encode${mono}
╰────────────────┈╯
╭──────✦ *ᴀɪ ᴍᴇɴᴜ* ✦────┈╮
│  ▢  ${mono}ai${mono}
│  ▢  ${mono}letmegpt${mono}
│  ▢  ${mono}gemini${mono}
│  ▢  ${mono}goodyai${mono}
│  ▢  ${mono}chatgpt${mono}
│  ▢  ${mono}mistral${mono}
│  ▢  ${mono}llama${mono}
│  ▢  ${mono}copilot${mono}
╰────────────────┈╯
╭────✦ *ꜱᴇᴀʀᴄʜ ᴍᴇɴᴜ* ✦───┈╮
│  ▢  ${mono}wiki${mono}
│  ▢  ${mono}tech${mono}
│  ▢  ${mono}srepo${mono}
│  ▢  ${mono}yts${mono}
│  ▢  ${mono}color${mono}
│  ▢  ${mono}githubstalk${mono}
│  ▢  ${mono}npm${mono}
│  ▢  ${mono}npms${mono}
│  ▢  ${mono}lyrics${mono}
│  ▢  ${mono}spotifys${mono}
│  ▢  ${mono}gits${mono}
│  ▢  ${mono}define${mono}
│  ▢  ${mono}cric${mono}
╰────────────────┈╯
╭──────✦ *ꜰᴜɴ ᴍᴇɴᴜ* ✦────┈╮
│  ▢  ${mono}gif${mono}
│  ▢  ${mono}joke${mono}
│  ▢  ${mono}mysterybox${mono}
│  ▢  ${mono}predict${mono}
│  ▢  ${mono}genderize${mono}
│  ▢  ${mono}nationalize${mono}
│  ▢  ${mono}fact${mono}
│  ▢  ${mono}hack${mono}
│  ▢  ${mono}studyhelper${mono}
╰────────────────┈╯
╭──────✦ *ɴꜱꜰᴡ ᴍᴇɴᴜ* ✦────┈╮
│  ▢  ${mono}nsfwloli${mono}
│  ▢  ${mono}nsfwfoot${mono}
│  ▢  ${mono}nsfwass${mono}
│  ▢  ${mono}tetas${mono}
│  ▢  ${mono}booty${mono}
│  ▢  ${mono}ecchi${mono}
│  ▢  ${mono}furro${mono}
│  ▢  ${mono}trapito${mono}
│  ▢  ${mono}imagenlesbians${mono}
│  ▢  ${mono}panties${mono}
│  ▢  ${mono}pene${mono}
│  ▢  ${mono}porno${mono}
│  ▢  ${mono}randomxxx${mono}
│  ▢  ${mono}yuri${mono}
│  ▢  ${mono}hentai2${mono}
│  ▢  ${mono}trap${mono}
│  ▢  ${mono}hneko${mono}
│  ▢  ${mono}belowjob${mono}
│  ▢  ${mono}hentaivid${mono}
│  ▢  ${mono}customnafw${mono}
│  ▢  ${mono}xnxx${mono}
│  ▢  ${mono}xnxxdl${mono}
│  ▢  ${mono}xvideo${mono}
│  ▢  ${mono}xvideodl${mono}
╰────────────────┈╯
╭─────✦ *ᴜꜱᴇꜰᴜʟ ᴍᴇɴᴜ* ✦───┈╮
│  ▢  ${mono}binance${mono}
│  ▢  ${mono}readmore${mono}
│  ▢  ${mono}affirmation${mono}
│  ▢  ${mono}recipe${mono}
│  ▢  ${mono}holidays${mono}
│  ▢  ${mono}wordoftheday${mono}
│  ▢  ${mono}randomuser${mono}
│  ▢  ${mono}wa${mono}
│  ▢  ${mono}apod${mono}
│  ▢  ${mono}solve${mono}
│  ▢  ${mono}send${mono}
│  ▢  ${mono}jid${mono}
│  ▢  ${mono}dnslookup${mono}
│  ▢  ${mono}countdown${mono}
│  ▢  ${mono}checkpw${mono}
│  ▢  ${mono}userinfo${mono}
│  ▢  ${mono}ipgeo${mono}
│  ▢  ${mono}whois${mono}
│  ▢  ${mono}headers${mono}
│  ▢  ${mono}weather${mono}
│  ▢  ${mono}tempmail${mono}
│  ▢  ${mono}checkmail${mono}
│  ▢  ${mono}gpass${mono}
│  ▢  ${mono}cybertips${mono}
│  ▢  ${mono}newpaste${mono}
│  ▢  ${mono}getpaste${mono}
╰────────────────┈╯
╭─────✦ *ʟᴏɢᴏ ᴍᴇɴᴜ* ✦──┈╮
│  ▢  ${mono}firelogo${mono}
│  ▢  ${mono}glowlogo${mono}
│  ▢  ${mono}neonlogo${mono}
│  ▢  ${mono}comicslogo${mono}
│  ▢  ${mono}smurflogo${mono}
│  ▢  ${mono}fluffylogo${mono}
│  ▢  ${mono}blackbirdlogo${mono}
│  ▢  ${mono}runnerlogo${mono}
│  ▢  ${mono}ampedlogo${mono}
│  ▢  ${mono}craftslogo${mono}
│  ▢  ${mono}romanlogo${mono}
│  ▢  ${mono}silverlogo${mono}
│  ▢  ${mono}popsiclelogo${mono}
│  ▢  ${mono}wildlogo${mono}
│  ▢  ${mono}funplaylogo${mono}
│  ▢  ${mono}alert${mono}
│  ▢  ${mono}unforgivable${mono}
│  ▢  ${mono}pikachu${mono}
│  ▢  ${mono}caution${mono}
│  ▢  ${mono}drake${mono}
│  ▢  ${mono}pooh${mono}
│  ▢  ${mono}sadcat${mono}
│  ▢  ${mono}oogway${mono}
╰────────────────┈╯
╭────✦ *ᴍᴏᴠɪᴇ ᴍᴇɴᴜ* ✦──┈╮
│  ▢  ${mono}movie${mono}
│  ▢  ${mono}upcomingmovie${mono}
│  ▢  ${mono}randommovie${mono}
│  ▢  ${mono}popularmovies${mono}
│  ▢  ${mono}trending${mono}
│  ▢  ${mono}genres${mono}
│  ▢  ${mono}nowplaying${mono}
│  ▢  ${mono}toprated${mono}
│  ▢  ${mono}newreleases${mono}
│  ▢  ${mono}dl${mono}
│  ▢  ${mono}dl2${mono}
╰────────────────┈╯
╭────✦ *ᴀɴɪᴍᴇ ᴍᴇɴᴜ* ✦─┈╮
│  ▢  ${mono}anime${mono}
│  ▢  ${mono}upcominganime${mono}
│  ▢  ${mono}topanime${mono}
│  ▢  ${mono}topanimechar${mono}
│  ▢  ${mono}topmanga${mono}
│  ▢  ${mono}topvoiceactors${mono}
╰────────────────┈╯
╭────✦ *ɴᴇᴡꜱ ᴍᴇɴᴜ* ✦──┈╮
│  ▢  ${mono}ada${mono}
│  ▢  ${mono}lankadeepa${mono}
│  ▢  ${mono}dailymirror${mono}
│  ▢  ${mono}gagana${mono}
│  ▢  ${mono}animenews${mono}
│  ▢  ${mono}news${mono}
│  ▢  ${mono}news2${mono}
│  ▢  ${mono}esana${mono}
│  ▢  ${mono}hn${mono}
╰────────────────┈╯
╭───✦ *ɢʀᴏᴜᴘ ᴍᴇɴᴜ* ✦──┈╮
│  ▢  ${mono}promote${mono}
│  ▢  ${mono}demote${mono}
│  ▢  ${mono}tagall${mono}
│  ▢  ${mono}seticon${mono}
│  ▢  ${mono}setsubject${mono}
│  ▢  ${mono}removeall${mono}
│  ▢  ${mono}setdecs${mono}
│  ▢  ${mono}hidetag${mono}
│  ▢  ${mono}mute${mono}
│  ▢  ${mono}lock${mono}
│  ▢  ${mono}unlock${mono}
│  ▢  ${mono}request${mono}
│  ▢  ${mono}revoke${mono}
│  ▢  ${mono}aproveall${mono}
│  ▢  ${mono}unmute${mono}
│  ▢  ${mono}kick${mono}
│  ▢  ${mono}groupinfo${mono}
│  ▢  ${mono}setgoodbye${mono}
│  ▢  ${mono}setwelcome${mono}
│  ▢  ${mono}add${mono}
╰────────────────┈╯
╭──✦ *ᴘʀᴇᴍɪᴜᴍ ᴍᴇɴᴜ* ✦─┈╮
│  ▢  ${mono}virtext1${mono}
│  ▢  ${mono}virtext2${mono}
│  ▢  ${mono}virtext3${mono}
│  ▢  ${mono}virtext4${mono}
│  ▢  ${mono}bug${mono}
│  ▢  ${mono}bug1${mono}
│  ▢  ${mono}bug2${mono}
│  ▢  ${mono}binario${mono}
╰────────────────┈╯
╭──✦ *ʀᴀɴᴅᴏᴍ ᴄᴏᴍᴍᴀɴᴅꜱ* ✦─╮
│  ▢  ${mono}dog${mono}
│  ▢  ${mono}rcolor${mono}
│  ▢  ${mono}randommeme${mono}
│  ▢  ${mono}rimgs${mono}
│  ▢  ${mono}cocktail${mono}
│  ▢  ${mono}dogbreed${mono}
│  ▢  ${mono}rvideo${mono}
╰────────────────┈╯
╭──✦ *ᴏᴡɴᴇʀ ᴍᴇɴᴜ* ✦─┈╮
│  ▢  ${mono}upgrade${mono}
│  ▢  ${mono}setvar${mono}
│  ▢  ${mono}settings${mono}
│  ▢  ${mono}getvars${mono}
│  ▢  ${mono}removevar${mono}
│  ▢  ${mono}getabout${mono}
│  ▢  ${mono}getbusiness${mono}
│  ▢  ${mono}restart${mono}
│  ▢  ${mono}ban${mono}
│  ▢  ${mono}unban${mono}
│  ▢  ${mono}setbotname${mono}
│  ▢  ${mono}setbotbio${mono}
│  ▢  ${mono}block${mono}
│  ▢  ${mono}setpp${mono}
│  ▢  ${mono}setautobio${mono}
│  ▢  ${mono}unblock${mono}
│  ▢  ${mono}broadcast${mono}
│  ▢  ${mono}join${mono}
│  ▢  ${mono}left${mono}
╰────────────────┈╯
> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
`);

                    break;
                    case "02":
                        reply(`╭─────✦ *ᴍᴀɪɴ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮
│  ▢  ${mono}Menu${mono}
│  ▢  ${mono}List${mono}
│  ▢  ${mono}Support${mono}
│  ▢  ${mono}Alive${mono}
│  ▢  ${mono}Ping${mono}
│  ▢  ${mono}System${mono}
│  ▢  ${mono}Channel${mono}
│  ▢  ${mono}web${mono}
│  ▢  ${mono}Session${mono}
│  ▢  ${mono}Repo${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "03":
                        reply(`╭─────✦ *ᴅᴏᴡɴʟᴏᴀᴅᴇʀ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭──✦ *ᴅᴏᴡɴʟᴏᴀᴅᴇʀ ᴍᴇɴᴜ* ✦─┈╮
│  ▢  ${mono}fb${mono}
│  ▢  ${mono}fb2${mono}
│  ▢  ${mono}9gag${mono}
│  ▢  ${mono}tiktok${mono}
│  ▢  ${mono}gdrive${mono}
│  ▢  ${mono}mfire${mono}
│  ▢  ${mono}mega${mono}
│  ▢  ${mono}gitclone${mono}
│  ▢  ${mono}song${mono}
│  ▢  ${mono}video${mono}
│  ▢  ${mono}ytmp3${mono}
│  ▢  ${mono}ytmp4${mono}
│  ▢  ${mono}igdl${mono}
│  ▢  ${mono}soundcloud${mono}
│  ▢  ${mono}twitter${mono}
│  ▢  ${mono}gimg${mono}
│  ▢  ${mono}pinterest${mono}
│  ▢  ${mono}wallpaper${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "04":
                        reply(`╭─────✦ *ᴄᴏɴᴠᴇʀᴛᴇʀ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}qr${mono}
│  ▢  ${mono}dbinary${mono}
│  ▢  ${mono}ebinary${mono}
│  ▢  ${mono}base64encode${mono}
│  ▢  ${mono}base64decode${mono}
│  ▢  ${mono}urlencode${mono}
│  ▢  ${mono}urldecode${mono}
│  ▢  ${mono}sticker${mono}
│  ▢  ${mono}convert${mono}
│  ▢  ${mono}morse${mono}
│  ▢  ${mono}demorse${mono}
│  ▢  ${mono}trt${mono}
│  ▢  ${mono}shorturl${mono}
│  ▢  ${mono}sha256encode${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "05":
                        reply(`╭─────✦ *ᴀɪ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}ai${mono}
│  ▢  ${mono}letmegpt${mono}
│  ▢  ${mono}gemini${mono}
│  ▢  ${mono}goodyai${mono}
│  ▢  ${mono}chatgpt${mono}
│  ▢  ${mono}mistral${mono}
│  ▢  ${mono}llama${mono}
│  ▢  ${mono}copilot${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "06":
                        reply(`╭─────✦ *ꜱᴇᴀʀᴄʜ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}wiki${mono}
│  ▢  ${mono}tech${mono}
│  ▢  ${mono}srepo${mono}
│  ▢  ${mono}yts${mono}
│  ▢  ${mono}color${mono}
│  ▢  ${mono}githubstalk${mono}
│  ▢  ${mono}npm${mono}
│  ▢  ${mono}npms${mono}
│  ▢  ${mono}lyrics${mono}
│  ▢  ${mono}spotifys${mono}
│  ▢  ${mono}gits${mono}
│  ▢  ${mono}define${mono}
│  ▢  ${mono}cric${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "07":
                        reply(`╭─────✦ *ꜰᴜɴ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}gif${mono}
│  ▢  ${mono}joke${mono}
│  ▢  ${mono}mysterybox${mono}
│  ▢  ${mono}predict${mono}
│  ▢  ${mono}genderize${mono}
│  ▢  ${mono}nationalize${mono}
│  ▢  ${mono}fact${mono}
│  ▢  ${mono}hack${mono}
│  ▢  ${mono}studyhelper${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "08":
                        reply(`╭─────✦ *ɴꜱꜰᴡ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}nsfwloli${mono}
│  ▢  ${mono}nsfwfoot${mono}
│  ▢  ${mono}nsfwass${mono}
│  ▢  ${mono}tetas${mono}
│  ▢  ${mono}booty${mono}
│  ▢  ${mono}ecchi${mono}
│  ▢  ${mono}furro${mono}
│  ▢  ${mono}trapito${mono}
│  ▢  ${mono}imagenlesbians${mono}
│  ▢  ${mono}panties${mono}
│  ▢  ${mono}pene${mono}
│  ▢  ${mono}porno${mono}
│  ▢  ${mono}randomxxx${mono}
│  ▢  ${mono}yuri${mono}
│  ▢  ${mono}hentai2${mono}
│  ▢  ${mono}trap${mono}
│  ▢  ${mono}hneko${mono}
│  ▢  ${mono}belowjob${mono}
│  ▢  ${mono}hentaivid${mono}
│  ▢  ${mono}customnafw${mono}
│  ▢  ${mono}xnxx${mono}
│  ▢  ${mono}xnxxdl${mono}
│  ▢  ${mono}xvideo${mono}
│  ▢  ${mono}xvideodl${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "09":
                        reply(`╭─────✦ *ᴜꜱᴇꜰᴜʟ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}binance${mono}
│  ▢  ${mono}readmore${mono}
│  ▢  ${mono}affirmation${mono}
│  ▢  ${mono}recipe${mono}
│  ▢  ${mono}holidays${mono}
│  ▢  ${mono}wordoftheday${mono}
│  ▢  ${mono}randomuser${mono}
│  ▢  ${mono}wa${mono}
│  ▢  ${mono}apod${mono}
│  ▢  ${mono}solve${mono}
│  ▢  ${mono}send${mono}
│  ▢  ${mono}jid${mono}
│  ▢  ${mono}dnslookup${mono}
│  ▢  ${mono}countdown${mono}
│  ▢  ${mono}checkpw${mono}
│  ▢  ${mono}userinfo${mono}
│  ▢  ${mono}ipgeo${mono}
│  ▢  ${mono}whois${mono}
│  ▢  ${mono}headers${mono}
│  ▢  ${mono}weather${mono}
│  ▢  ${mono}tempmail${mono}
│  ▢  ${mono}checkmail${mono}
│  ▢  ${mono}gpass${mono}
│  ▢  ${mono}cybertips${mono}
│  ▢  ${mono}newpaste${mono}
│  ▢  ${mono}getpaste${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "10":
                        reply(`╭─────✦ *ʟᴏɢᴏ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}firelogo${mono}
│  ▢  ${mono}glowlogo${mono}
│  ▢  ${mono}neonlogo${mono}
│  ▢  ${mono}comicslogo${mono}
│  ▢  ${mono}smurflogo${mono}
│  ▢  ${mono}fluffylogo${mono}
│  ▢  ${mono}blackbirdlogo${mono}
│  ▢  ${mono}runnerlogo${mono}
│  ▢  ${mono}ampedlogo${mono}
│  ▢  ${mono}craftslogo${mono}
│  ▢  ${mono}romanlogo${mono}
│  ▢  ${mono}silverlogo${mono}
│  ▢  ${mono}popsiclelogo${mono}
│  ▢  ${mono}wildlogo${mono}
│  ▢  ${mono}funplaylogo${mono}
│  ▢  ${mono}alert${mono}
│  ▢  ${mono}unforgivable${mono}
│  ▢  ${mono}pikachu${mono}
│  ▢  ${mono}caution${mono}
│  ▢  ${mono}drake${mono}
│  ▢  ${mono}pooh${mono}
│  ▢  ${mono}sadcat${mono}
│  ▢  ${mono}oogway${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "11":
                        reply(`╭─────✦ *ᴍᴏᴠɪᴇ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}movie${mono}
│  ▢  ${mono}upcomingmovie${mono}
│  ▢  ${mono}randommovie${mono}
│  ▢  ${mono}popularmovies${mono}
│  ▢  ${mono}trending${mono}
│  ▢  ${mono}genres${mono}
│  ▢  ${mono}nowplaying${mono}
│  ▢  ${mono}toprated${mono}
│  ▢  ${mono}newreleases${mono}
│  ▢  ${mono}dl${mono}
│  ▢  ${mono}dl2${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "12":
                        reply(`╭─────✦ *ᴀɴɪᴍᴇ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}anime${mono}
│  ▢  ${mono}upcominganime${mono}
│  ▢  ${mono}topanime${mono}
│  ▢  ${mono}topanimechar${mono}
│  ▢  ${mono}topmanga${mono}
│  ▢  ${mono}topvoiceactors${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "13":
                        reply(`╭─────✦ *ɴᴇᴡꜱ ᴍᴇɴᴜ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮ 
│  ▢  ${mono}ada${mono}
│  ▢  ${mono}lankadeepa${mono}
│  ▢  ${mono}dailymirror${mono}
│  ▢  ${mono}gagana${mono}
│  ▢  ${mono}animenews${mono}
│  ▢  ${mono}news${mono}
│  ▢  ${mono}news2${mono}
│  ▢  ${mono}esana${mono}
│  ▢  ${mono}hn${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "14":
                        reply(`╭─────✦ *ɢʀᴏᴜᴘ ᴄᴏᴍᴍᴀɴᴅꜱ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮
│  ▢  ${mono}promote${mono}
│  ▢  ${mono}demote${mono}
│  ▢  ${mono}tagall${mono}
│  ▢  ${mono}seticon${mono}
│  ▢  ${mono}setsubject${mono}
│  ▢  ${mono}removeall${mono}
│  ▢  ${mono}setdecs${mono}
│  ▢  ${mono}hidetag${mono}
│  ▢  ${mono}mute${mono}
│  ▢  ${mono}lock${mono}
│  ▢  ${mono}unlock${mono}
│  ▢  ${mono}request${mono}
│  ▢  ${mono}revoke${mono}
│  ▢  ${mono}aproveall${mono}
│  ▢  ${mono}unmute${mono}
│  ▢  ${mono}kick${mono}
│  ▢  ${mono}groupinfo${mono}
│  ▢  ${mono}setgoodbye${mono}
│  ▢  ${mono}setwelcome${mono}
│  ▢  ${mono}add${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "15":
                        reply(`╭─────✦ *ᴘʀᴇᴍɪᴜᴍ ᴄᴏᴍᴍᴀɴᴅꜱ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮
│  ▢  ${mono}virtext1${mono}
│  ▢  ${mono}virtext2${mono}
│  ▢  ${mono}virtext3${mono}
│  ▢  ${mono}virtext4${mono}
│  ▢  ${mono}bug${mono}
│  ▢  ${mono}bug1${mono}
│  ▢  ${mono}bug2${mono}
│  ▢  ${mono}binario${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
`);
                        break;
                    case "16":
                        reply(`╭─────✦ *ᴏᴡɴᴇʀ ᴄᴏᴍᴍᴀɴᴅꜱ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮
│  ▢  ${mono}upgrade${mono}
│  ▢  ${mono}setvar${mono}
│  ▢  ${mono}settings${mono}
│  ▢  ${mono}getvars${mono}
│  ▢  ${mono}removevar${mono}
│  ▢  ${mono}getabout${mono}
│  ▢  ${mono}getbusiness${mono}
│  ▢  ${mono}restart${mono}
│  ▢  ${mono}ban${mono}
│  ▢  ${mono}unban${mono}
│  ▢  ${mono}setbotname${mono}
│  ▢  ${mono}setbotbio${mono}
│  ▢  ${mono}block${mono}
│  ▢  ${mono}setpp${mono}
│  ▢  ${mono}setautobio${mono}
│  ▢  ${mono}unblock${mono}
│  ▢  ${mono}broadcast${mono}
│  ▢  ${mono}join${mono}
│  ▢  ${mono}left${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ`);
                        break;
                    case "17":
                        reply(`╭─────✦ *ʀᴀɴᴅᴏᴍ ᴄᴏᴍᴍᴀɴᴅꜱ* ✦──────╮   
Hello *${pushname}* 👋
> *➤ ᴘʀᴇꜰɪx :* ${prefix}
> *➤ ᴀᴜᴛʜᴏʀ :* Vishwa & Bhashitha
> *➤ ʀᴜɴᴛɪᴍᴇ :* ${runtime}
╰──────✦ ʙʜᴀꜱʜɪ ᴍᴅ ✦──────╯
╭────────────────┈╮
│  ▢  ${mono}dog${mono}
│  ▢  ${mono}rcolor${mono}
│  ▢  ${mono}rimgs${mono}
│  ▢  ${mono}cocktail${mono}
│  ▢  ${mono}dogbreed${mono}
│  ▢  ${mono}rvideo${mono}
╰────────────────┈╯

> *ʙʜᴀꜱʜɪ • ᴍᴅ ᴠ2* | © ᴘʀᴇꜱᴇɴᴛ ʙʏ ʙʜᴀꜱʜɪ ᴛᴇᴀᴍ
`);
                        break;
                    default:
                        reply("*Please reply with a valid number from the menu!*");
                        break;
                }
            }
        });

    } catch (e) {
        console.log(e);
        reply(`${e}`);
    }
});
//================================================================
cmd({
  pattern: "ping",
  desc: "Check bot's response time.",
  category: "main",
  react: "🪄",
  filename: __filename
}, async (conn, mek, m, { from, quoted, reply }) => {
  try {
      const config = await readEnv();
      const langMessages = {
          SI: {
              pinging: 'පිංගින්...',
              responseTime: (ping) => `⏰  ප්‍රතිචාර කාලය: ${ping} ms`,
              error: (error) => `දෝෂයක්: ${error}`
          },
          EN: {
              pinging: 'Pinging...',
              responseTime: (ping) => `⏰  Response Time: ${ping} ms`,
              error: (error) => `Error: ${error}`
          }
      };

      // Set default language to English if not found
      const language = config.LANGUAGE || 'EN';
      const messages = langMessages[language] || langMessages.EN;

      // Start timing the ping response
      const startTime = Date.now();

      // Wait briefly to simulate latency
      await new Promise(resolve => setTimeout(resolve, 400));

      // End timing the response
      const endTime = Date.now();
      const ping = endTime - startTime;

      // Prepare response time message based on language
      const responseTimeMessage = messages.responseTime(ping);
     reply(responseTimeMessage)
  } catch (e) {
      // Log the full error to console
      console.error('Error during ping operation:', e);

      // Send an error message back to the user in the appropriate language
      const language = (await readEnv()).LANGUAGE || 'EN';
      const messages = langMessages[language] || langMessages.EN;
      reply(messages.error(e.message));
  }
});


//==================================================================
